// ── 正規化 ──
function normalize(s) {
  return s.toLowerCase()
    .replace(/[\u3041-\u3096]/g, c => String.fromCharCode(c.charCodeAt(0) + 0x60))
    .replace(/[Ａ-Ｚａ-ｚ０-９]/g, c => String.fromCharCode(c.charCodeAt(0) - 0xFEE0));
}

// ── ミクロ栄養素目標 ──
// goal: 推奨量/目安量（RDA/AI）　ul: 耐容上限量（日本人の食事摂取基準 2020年版、成人の目安値）
// ビタミンKはUL未設定（高摂取での健康被害の報告が無いため、日本人の食事摂取基準でも上限は定められていない）
const MICRO_GOALS = {
  fiber:   { label:'食物繊維', unit:'g',  goal:21,   color:'#8bc34a' },
  iron:    { label:'鉄',       unit:'mg', goal:7,    color:'#e91e63' },
  calcium: { label:'Ca',       unit:'mg', goal:700,  color:'#03a9f4' },
  vitc:    { label:'VitC',     unit:'mg', goal:100,  color:'#ff9800' },
  vitd:    { label:'VitD',     unit:'μg', goal:8.5,  color:'#ffd600', ul:100 },
  vita:    { label:'VitA',     unit:'μg', goal:850,  color:'#ff7043', ul:2700 },
  vite:    { label:'VitE',     unit:'mg', goal:6.5,  color:'#ab47bc', ul:800 },
  vitk:    { label:'VitK',     unit:'μg', goal:150,  color:'#26a69a' },
  iodine:  { label:'ヨウ素',   unit:'μg', goal:130,  color:'#5c6bc0', ul:3000 },
  salt:    { label:'塩分',     unit:'g',  goal:7.5,  color:'#9e9e9e', reverse:true },
};
// 食物繊維の内訳（水溶性 fibS / 不溶性 fibI, g）。目標値(MICRO_GOALS)は持たないが、記録・複合食品・AI入力では他のミクロ栄養素と同じ経路で扱う
const FIBER_SUB_KEYS = ['fibS','fibI'];
const MICRO_GOAL_KEYS = Object.keys(MICRO_GOALS);
const MICRO_KEYS = [...MICRO_GOAL_KEYS, ...FIBER_SUB_KEYS];
// ミクロ栄養素の丸め桁（鉄・VitD・VitE・塩分は2桁、それ以外は1桁）
function microRound(k, v) { const d = (k==='iron'||k==='vitd'||k==='vite'||k==='salt') ? 100 : 10; return Math.round((v||0)*d)/d; }
// AI・インポート等の外部入力から、ミクロ栄養素(MICRO_KEYS)を数値として取り出す（不正値・負数は0）
function pickMicros(obj) {
  const o = {};
  MICRO_KEYS.forEach(k => { const v = parseFloat(obj && obj[k]); o[k] = (isFinite(v) && v > 0) ? v : 0; });
  return o;
}
// ── 食物繊維の水溶性/不溶性の内訳 ──
// 食品DB(foods-db.js)の fibS/fibI は日本食品標準成分表(八訂)の実測値、またはカテゴリからの推定比率(fibEst:1)。
// 藻類・寒天など、成分表自体が内訳を収載していない食品は fibS/fibI を持たない（→「区分不明」として集計）。
let _fibRatioMap = null;
function fibSolRatioByName(name) {
  if (!_fibRatioMap) {
    _fibRatioMap = new Map();
    LOCAL_DB.forEach(f => { if (f.fiber > 0 && typeof f.fibS === 'number') _fibRatioMap.set(f.name, f.fibS / f.fiber); });
  }
  if (_fibRatioMap.has(name)) return _fibRatioMap.get(name);
  const c = [...customFoods, ...comboFoods].find(x => x.name === name && x.fiber > 0 && (x.fibS || 0) + (x.fibI || 0) > 0);
  return c ? (c.fibS || 0) / ((c.fibS || 0) + (c.fibI || 0)) : null;
}
// 食品名から水溶性の割合(0〜1)を推定する（成分表に内訳が無い・AIが内訳を返さなかった・手入力で空欄、の場合の最終手段）。
// 先勝ち。海藻類は成分表(八訂)にも内訳の収載が無いため、文献的な傾向（水溶性が比較的多い）にもとづく粗い目安。
const FIB_SOL_RULES = [
  [/昆布|こんぶ|もずく|めかぶ|寒天|かんてん/, 0.7], [/わかめ|ワカメ|ひじき|あおさ|海苔|焼きのり|海藻|スピルリナ|クロレラ/, 0.35],
  [/サイリウム/, 0.7], [/亜麻仁|フラックス/, 0.3], [/チアシード/, 0.2],
  [/納豆/, 0.34], [/おから/, 0.04], [/豆乳/, 0.4], [/豆腐|湯葉|高野豆腐/, 0.25], [/きな粉/, 0.15],
  [/大豆|ひよこ|レンズ|ダール|小豆|いんげん|インゲン|えんどう|エンドウ|そら豆|黒豆|豆|ミート|テンペ/, 0.1],
  [/こんにゃく|しらたき/, 0.05], [/玄米/, 0.23], [/オート|オーツ|グラノーラ|ミューズリー/, 0.32],
  [/白米|ご飯|ごはん|おにぎり|赤飯|餅|もち|白玉|米粉|ビーフン|春雨|せんべい|煎餅/, 0.02],
  [/ライ麦|全粒粉|ふすま/, 0.25], [/そば|蕎麦/, 0.25],
  [/うどん|そうめん|パスタ|スパゲ|マカロニ|麺|ラーメン|ヌードル|ピザ|ナン|餃子|パン粉|小麦粉|薄力|中力|強力/, 0.35],
  [/パン|ベーグル|クロワッサン|クラッカー|ビスケット|クッキー|ケーキ|ドーナツ|ワッフル|カステラ|月餅|八ツ橋/, 0.25],
  [/ごま|ゴマ/, 0.13], [/アーモンド|ナッツ|くるみ|ピーナッツ|ピスタチオ|カシュー|マカダミア/, 0.1],
  [/しいたけ|シイタケ|椎茸|えのき|しめじ|まいたけ|エリンギ|なめこ|きのこ|キノコ/, 0.08],
  [/じゃがいも|ポテト|ポテチ/, 0.35], [/さつまいも|焼き芋|山芋|ながいも|里芋|さといも/, 0.3],
  [/バナナ/, 0.1], [/みかん|オレンジ|グレープフルーツ|柑|レモン/, 0.5], [/りんご|リンゴ|キウイ|アボカド/, 0.28],
  [/いちご|ベリー|ぶどう|ブドウ|もも|桃|梨|柿|さくらんぼ|マンゴー|パイン|メロン|すいか|プルーン|レーズン|デーツ/, 0.3],
  [/にんにく|ガーリック/, 0.6], [/ごぼう/, 0.4], [/玉ねぎ|たまねぎ|ねぎ|ネギ/, 0.27],
  [/チョコ|ココア/, 0.15], [/ジュース|スムージー|青汁/, 0.25],
];
function estimateSolRatio(name) {
  const n = String(name || '');
  for (const [re, r] of FIB_SOL_RULES) if (re.test(n)) return r;
  return 0.28; // 野菜・混合料理などの一般的な目安
}
// AI入力の内訳を検証し、無い/不正なら食品名から推定して必ず {fibS, fibI} を返す（fiber>0のとき）
function aiFiberSplit(o) {
  const fiber = parseFloat(o && o.fiber) || 0;
  if (!(fiber > 0)) return { fibS: 0, fibI: 0 };
  const v = normFibSplit(o);
  if (v.fibS + v.fibI > 0) return v;
  const s = r1(fiber * estimateSolRatio(o && o.name));
  return { fibS: s, fibI: r1(fiber - s) };
}
// 既存の食品オブジェクトの内訳を fiber と整合させる（無ければ名前から推定）
function reconcileFiberSplit(o) {
  const t = o.fiber || 0;
  if (!(t > 0)) { o.fibS = 0; o.fibI = 0; return o; }
  const k = (o.fibS || 0) + (o.fibI || 0);
  const s = r1(k > 0 ? t * (o.fibS || 0) / k : t * estimateSolRatio(o.name));
  o.fibS = s; o.fibI = r1(t - s);
  return o;
}
// 記録1件の食物繊維を {s:水溶性, i:不溶性, u:区分不明} に分ける（過去の記録は食品名からDBの比率で補完）
function getFiberSplit(e) {
  const t = e.fiber || 0;
  if (t <= 0) return { s: 0, i: 0, u: 0 };
  const known = (e.fibS || 0) + (e.fibI || 0);
  if (known > 0) {
    if (known >= t * 0.95) { const k = t / known; return { s: (e.fibS || 0) * k, i: (e.fibI || 0) * k, u: 0 }; }
    return { s: e.fibS || 0, i: e.fibI || 0, u: t - known }; // 一部だけ判明（複合食品で内訳不明の材料を含む場合など）
  }
  const r = fibSolRatioByName(e.name);
  if (r != null) return { s: t * r, i: t * (1 - r), u: 0 };
  const er = estimateSolRatio(e.name); // DBに無い食品も、名前からの推定で水溶性/不溶性に振り分ける
  return { s: t * er, i: t * (1 - er), u: 0 };
}
// 入力欄に出す水溶性(g)。内訳が全く分からない場合は空欄（＝食品名から自動推定／区分不明のまま）
function fibSInputVal(o) { const sp = getFiberSplit(o); return (sp.s + sp.i) > 0 ? r1(sp.s) : ''; }
// 入力欄の水溶性(g)から {fibS, fibI} を作る。空欄なら {}（自動）。fiberを超える値は丸める
function fibSplitFromInput(rawS, fiber) {
  const raw = String(rawS == null ? '' : rawS).trim();
  const t = parseFloat(fiber) || 0;
  if (raw === '' || !(t > 0)) return {};
  const v = parseFloat(raw);
  if (!isFinite(v) || v < 0) return {};
  const s = r1(Math.min(v, t));
  return { fibS: s, fibI: r1(t - s) };
}
// 記録に内訳(fibS/fibI)を確定して持たせる（合算時など）。fibS+fibI = fiber になるよう丸める
function materializeFiberSplit(e) {
  const t = e.fiber || 0;
  if (t <= 0) { e.fibS = 0; e.fibI = 0; return; }
  const sp = getFiberSplit(e);
  e.fibS = r1(sp.s);
  e.fibI = sp.u > 0 ? r1(sp.i) : r1(t - r1(sp.s));
}
// DB食品(per基準)を実量(倍率r)にしたときの内訳。fiberScaled は丸め済みの食物繊維量
function fibSplitScaled(f, r, fiberScaled) {
  const known = (f.fibS || 0) + (f.fibI || 0);
  if (!(fiberScaled > 0) || known <= 0) return { fibS: 0, fibI: 0 };
  const s = r1(fiberScaled * (f.fibS || 0) / known);
  return { fibS: s, fibI: r1(fiberScaled - s) };
}
// 外部入力(AI等)の内訳を検証。fiberと大きく食い違う場合は信用せず未設定にする
function normFibSplit(o) {
  const fiber = parseFloat(o && o.fiber) || 0, a = parseFloat(o && o.fibS), b = parseFloat(o && o.fibI);
  if (!(fiber > 0) || !isFinite(a) || !isFinite(b) || a < 0 || b < 0 || a + b <= 0) return { fibS: 0, fibI: 0 };
  const k = fiber / (a + b);
  if (k < 0.7 || k > 1.4) return { fibS: 0, fibI: 0 };
  const s = r1(a * k); return { fibS: s, fibI: r1(fiber - s) };
}
// 記録編集で食物繊維の量が変わったとき、内訳を同じ比率でスケールする（不明分は不明のまま）
function syncFiberSplit(oldE, newE) {
  const t = newE.fiber || 0;
  if (t <= 0) { newE.fibS = 0; newE.fibI = 0; return; }
  const sp = getFiberSplit(oldE), oldT = oldE.fiber || 0;
  if (sp.s + sp.i <= 0 || oldT <= 0) { newE.fibS = 0; newE.fibI = 0; return; }
  const k = t / oldT;
  newE.fibS = r1(sp.s * k);
  newE.fibI = sp.u > 0 ? r1(sp.i * k) : r1(t - newE.fibS);
}
// 表示用: 水溶性/不溶性/区分不明のスタックバー（目標値に対する割合ではなく内訳の割合）
function fiberSplitBlock(s) {
  const a = s.fibS || 0, b = s.fibI || 0, u = s.fibU || 0, tot = a + b + u;
  if (tot <= 0) return '';
  const pc = v => Math.round(v / tot * 100);
  const strong = v => `<b style="color:var(--text)">${r1(v)}g</b>`;
  return `<div style="margin:-2px 0 10px;padding:8px 10px;background:var(--surface2);border-radius:var(--radius-sm);font-size:11px">
    <div style="display:flex;height:6px;border-radius:3px;overflow:hidden;background:var(--border);margin-bottom:6px">
      <div style="width:${pc(a)}%;background:#4fc3f7"></div><div style="width:${pc(b)}%;background:#8bc34a"></div>${u > 0 ? `<div style="width:${pc(u)}%;background:#bdbdbd"></div>` : ''}
    </div>
    <div style="display:flex;justify-content:space-between;gap:8px;color:var(--text-sub)"><span>🔵 水溶性 ${strong(a)}（${pc(a)}%）</span><span>🟢 不溶性 ${strong(b)}（${pc(b)}%）</span></div>
    ${u > 0 ? `<div style="margin-top:3px;color:var(--text-sub)">⚪ 区分不明 ${strong(u)}（${pc(u)}%）… 内訳を判定できなかった分</div>` : ''}
    <div style="margin-top:4px;font-size:9px;color:var(--text-sub)">※内訳は食品成分表(八訂)の値、または食品名・カテゴリからの推定比率です（記録の編集で「うち水溶性」を直せます）</div>
  </div>`;
}
// 脂肪酸比率(fa)・アミノ酸プロファイル(aa)の検証。不正・不自然な値は null（→ 名前からの自動推定に任せる）
function sanitizeFa(fa) {
  if (!fa || typeof fa !== 'object') return null;
  const o = {}; let sum = 0;
  for (const k of ['sat','mufa','n3','n6','trans']) {
    const v = parseFloat(fa[k]); if (!isFinite(v) || v < 0 || v > 1) return null;
    o[k] = Math.round(v*1000)/1000; sum += v;
  }
  return (sum >= 0.5 && sum <= 1.2) ? o : null;
}
function sanitizeAa(aa) {
  if (!aa || typeof aa !== 'object') return null;
  const o = {};
  for (const k of ['leu','ile','val','lys','met','thr','trp','his']) {
    const v = parseFloat(aa[k]); if (!isFinite(v) || v < 0 || v > 0.3) return null;
    o[k] = Math.round(v*1000)/1000;
  }
  const sc = parseFloat(aa.score); if (!isFinite(sc) || sc < 0 || sc > 1.5) return null;
  o.score = Math.round(sc*100)/100;
  return o;
}

const MEAL_META = {
  朝食:{ icon:'🌅', bg:'#fff8e6' },
  昼食:{ icon:'☀️', bg:'#e6f1fb' },
  夕食:{ icon:'🌙', bg:'#ede9ff' },
  間食:{ icon:'🍎', bg:'#e8f5e9' },
};
const MEALS_ORDER = ['朝食','昼食','夕食','間食'];

// ── タンパク質吸収率 ──
// ① 食品カテゴリ別の消化率（真の消化率に近い値。豆類は十分な加熱・水さらし等で
//    トリプシンインヒビター等の抗栄養素がほぼ失活している前提で高めの値を採用）
const DIGEST_ISOLATE = 0.98; // プロテインパウダー等の分離・精製タンパク質（消化性が最も高い）
const DIGEST_ANIMAL  = 0.97; // 肉・魚・卵・乳
const DIGEST_MIXED   = 0.90; // 複数食材からなる合わせ料理・加工食品・外食メニュー（内訳は不明だが、
                              // 多くは動物性+穀物が主体のため、野菜単品(DIGEST_OTHER)より高めに見積もる）
const DIGEST_LEGUME  = 0.90; // 豆類・大豆製品（十分に加熱・下処理された前提）
const DIGEST_GRAIN   = 0.87; // 穀物
const DIGEST_NUT     = 0.80; // ナッツ・種子（脂質・食物繊維に囲まれ消化率がやや低め）
const DIGEST_OTHER   = 0.78; // 野菜など、上記に当てはまらないもの
const DIGEST_BY_CATEGORY = {
  isolate: DIGEST_ISOLATE, animal: DIGEST_ANIMAL, mixed: DIGEST_MIXED,
  legume: DIGEST_LEGUME, grain: DIGEST_GRAIN, nut: DIGEST_NUT, other: DIGEST_OTHER,
};

const P_ABS_ISOLATE_PATTERN = /プロテイン|ホエイ|カゼイン|ソイプロテイン|WPI|WPC|EAA|BCAA|アミノ酸パウダー|コラーゲンペプチド|SOYLENT/i;
const P_ABS_ANIMAL_PATTERN = /鶏|豚|牛|羊|ラム|合いびき|ひき肉|ミンチ|ベーコン|ハム|ソーセージ|ウインナー|サラミ|チャーシュー|ローストビーフ|ステーキ|ロース|バラ肉|もも肉|むね肉|ささみ|ヒレ|ひれ|レバー|ハツ|軟骨|ホルモン|つくね|ミートボール|ハンバーグ|しゃぶしゃぶ|焼肉|生姜焼き|唐揚げ|から揚げ|竜田揚げ|とんかつ|カツ丼|カツサンド|チキン|ポーク|ビーフ|マトン|フランクフルト|ジャーキー|コンビーフ|スパム|チョリソー|鴨|馬肉|鹿肉|いわし|マイワシ|さば|マサバ|さんま|あじ|マアジ|さけ|鮭|サーモン|まぐろ|マグロ|ツナ|かつお|カツオ|ぶり|ブリ|たい|鯛|たら|タラ|さわら|ひらめ|かれい|うなぎ|穴子|あなご|しらす|ししゃも|ほっけ|ホッケ|はまち|メカジキ|すずき|メバル|しじみ|あさり|はまぐり|かき|カキ|牡蠣|えび|海老|エビ|いか|イカ|たこ|タコ|ほたて|ホタテ|かに|カニ|さざえ|うに|明太子|たらこ|いくら|魚肉ソーセージ|さつま揚げ|ちくわ|かまぼこ|はんぺん|卵|たまご|タマゴ|ゆで卵|目玉焼き|スクランブル|オムレツ|温泉卵|チーズ|ヨーグルト|牛乳|ミルク|生クリーム|カッテージ|モッツァレラ|クリームチーズ|だし|ほんだし|ラテ|ケフィア|ホットチョコレート|seafood|chicken|pork|beef|fish|salmon|tuna|egg|shrimp|cheese|milk|yogurt|steak/i;
const P_ABS_LEGUME_PATTERN = /豆腐|冷奴|納豆|豆乳|大豆|えだまめ|枝豆|きな粉|小豆|ひよこ豆|レンズ豆|黒豆|そら豆|いんげん豆|インゲン豆|ミックスビーンズ|油揚げ|厚揚げ|がんもどき|湯葉|テンペ|白和え|けんちん|えんどう豆|ダール|ダル|ひら豆/i;
const P_ABS_GRAIN_PATTERN  = /米|ごはん|ご飯|パン|うどん|パスタ|そば|ラーメン|マカロニ|ビーフン|そうめん|ひやむぎ|中華麺|オートミール|小麦粉|強力粉|薄力粉|とうもろこし|コーン|キヌア|もち|餅|シリアル|ミューズリー|グラノーラ|白玉粉|上新粉|麩/i;
const P_ABS_NUT_PATTERN    = /アーモンド|くるみ|カシューナッツ|ピーナッツ|ナッツ|ごま|松の実|ひまわりの種|かぼちゃの種|フラックスシード|チアシード|ピーナッツバター|マカダミア|ピスタチオ|ヘーゼルナッツ|ペカン/i;

// 食品名からタンパク質消化率カテゴリを推定する（digestフィールドが無い食品向けのフォールバック）
// DB(foods-db.js)側は全件digestフィールドを持たせているのでこの推定は基本的に不要だが、
// カスタム食品・複合食品など、DB外の食品には引き続き使われる
function classifyDigestCategory(name, proteinG) {
  if (P_ABS_ISOLATE_PATTERN.test(name)) return 'isolate';
  if (P_ABS_ANIMAL_PATTERN.test(name))  return 'animal';
  if (P_ABS_LEGUME_PATTERN.test(name))  return 'legume';
  if (P_ABS_GRAIN_PATTERN.test(name))   return 'grain';
  if (P_ABS_NUT_PATTERN.test(name))     return 'nut';
  // どのパターンにも一致しないが、タンパク質量がそれなりにある（8g以上）場合は
  // 単品というより複数食材からなる合わせ料理・加工食品である可能性が高いと推定する
  if ((proteinG || 0) >= 8) return 'mixed';
  return 'other';
}

function foodDigestibility(e) {
  if (e.digest && DIGEST_BY_CATEGORY[e.digest] != null) return DIGEST_BY_CATEGORY[e.digest];
  return DIGEST_BY_CATEGORY[classifyDigestCategory(e.name, e.p)];
}

// ② WHO/FAO/UNU(2007) 成人必須アミノ酸参照パターン（gアミノ酸 / gたんぱく質）
//    食事全体で消化されたアミノ酸をプールし、このパターンと比較して制限アミノ酸を判定する
const AA_REFERENCE = { his:0.015, ile:0.030, leu:0.059, lys:0.045, met:0.022, thr:0.023, trp:0.006, val:0.039 };

function parseTimeToMinutes(hhmm) {
  if (!hhmm || typeof hhmm !== 'string') return null;
  const m = hhmm.match(/^(\d{1,2}):(\d{2})$/);
  if (!m) return null;
  const h = parseInt(m[1], 10), min = parseInt(m[2], 10);
  if (isNaN(h) || isNaN(min) || h > 24 || min > 59) return null;
  return h * 60 + min;
}
// アミノ酸補完が起こりうる「同じ食事機会」とみなす時間の幅（分）。
// 消化管内でアミノ酸プールが実際に混ざり合うのはこの程度の時間スケールという大まかな目安で、
// 生理学的に厳密な値ではない
const AA_POOLING_WINDOW_MIN = 180;

// ③ アミノ酸を合算する単位（＝食べ合わせによる補完効果を反映する範囲）を決める。
//    摂取時刻が記録されている項目は、時刻が近い（AA_POOLING_WINDOW_MIN以内）もの同士をまとめる
//    （mealのラベルが違っても、例えば夕食直後の間食は夕食と補完し合う）。
//    時刻が未記録の古い記録は、従来通りmeal区分でグループ化する（後方互換）。
function groupForAaPooling(list) {
  const withTime = [], withoutTime = [];
  list.forEach(e => (parseTimeToMinutes(e.time) != null ? withTime : withoutTime).push(e));

  const groups = [];
  withTime
    .slice()
    .sort((a, b) => parseTimeToMinutes(a.time) - parseTimeToMinutes(b.time))
    .forEach(e => {
      const t = parseTimeToMinutes(e.time);
      const last = groups[groups.length - 1];
      if (last && t - last._lastT <= AA_POOLING_WINDOW_MIN) {
        last.push(e); last._lastT = t;
      } else {
        const g = [e]; g._lastT = t; groups.push(g);
      }
    });

  const byMeal = {};
  withoutTime.forEach(e => { (byMeal[e.meal || '_'] = byMeal[e.meal || '_'] || []).push(e); });
  return groups.concat(Object.values(byMeal));
}

// ④ 食事（アミノ酸補完の単位）ごとにアミノ酸を合算し、食べ合わせによる補完効果を反映する
//    例: 白米（リジンが制限）＋ 豆類（メチオニンが制限だがリジンは豊富）を同じ食事で摂ると、
//        単品ごとのスコアより食事全体のスコアが上がる（アミノ酸補完効果）
function calcAbsorbedProtein(list) {
  const groups = groupForAaPooling(list);

  let totalAbsorbed = 0;
  groups.forEach(mealList => {
    let digestedProtein = 0;
    let hasAaData = false;
    const aaSum = { his:0, ile:0, leu:0, lys:0, met:0, thr:0, trp:0, val:0 };

    mealList.forEach(e => {
      const p = e.p || 0;
      if (p <= 0) return;
      const digestedP = p * foodDigestibility(e);
      digestedProtein += digestedP;
      if (e.aa) {
        hasAaData = true;
        Object.keys(aaSum).forEach(k => { aaSum[k] += (e.aa[k] || 0) * digestedP; });
      }
    });

    if (digestedProtein <= 0) return;

    if (hasAaData) {
      // 消化後アミノ酸プールを参照パターンと比較し、食事全体の制限アミノ酸スコアを算出
      let mealScore = 1.0;
      Object.keys(AA_REFERENCE).forEach(k => {
        const supplyRatio = (aaSum[k] / digestedProtein) / AA_REFERENCE[k];
        mealScore = Math.min(mealScore, supplyRatio);
      });
      totalAbsorbed += digestedProtein * Math.min(mealScore, 1.0);
    } else {
      // アミノ酸データが無い食品のみの食事は消化率のみ反映
      totalAbsorbed += digestedProtein;
    }
  });

  return totalAbsorbed;
}

// ── 内蔵DB ──
// 食品データ本体は foods-db.js に分離（index.htmlでこのファイルより先に読み込む）
// ── 読み仮名・ローマ字検索 ──
// 検索は「表記(name)」「カタカナ読み(yomi)」「ローマ字→カナ変換」の3経路で行う。
//   ひらがな入力 : normalize() でカタカナ化して name / yomi / tags と照合
//   ローマ字入力 : romajiToKana() でカタカナ化し、_kana（ゆるく正規化した読み）と照合
//   読みが無い食品(カスタム/複合): 手入力の yomi があればそれを、無ければ内蔵DBの読みから guessYomi() で推定
const KANJI_CH = '\\u4E00-\\u9FFF\\u3400-\\u4DBF\\u3005\\u3006';
const KANJI_RUN_RE = new RegExp('([' + KANJI_CH + ']+)|([^' + KANJI_CH + ']+)', 'g');
function toKata(s) { return String(s || '').replace(/[\u3041-\u3096]/g, c => String.fromCharCode(c.charCodeAt(0) + 0x60)); }
// 読みとして有効な文字（カタカナ・長音・空白）だけを残す
function sanitizeYomi(s) { return toKata(s).replace(/[^\u30A1-\u30FA\u30FC\s]/g, '').replace(/\s+/g, ' ').trim(); }

// ローマ字→カタカナ（ヘボン式・訓令式・IME入力の混在を許容）。ローマ字として解釈できなければ null
const ROMAJI_TABLE = (() => {
  const T = {};
  const rows = { '':'アイウエオ', k:'カキクケコ', g:'ガギグゲゴ', s:'サシスセソ', z:'ザジズゼゾ', t:'タチツテト', d:'ダヂヅデド',
    n:'ナニヌネノ', h:'ハヒフヘホ', b:'バビブベボ', p:'パピプペポ', m:'マミムメモ', r:'ラリルレロ', l:'ラリルレロ', v:'バビブベボ' };
  Object.keys(rows).forEach(c => 'aiueo'.split('').forEach((v, i) => { T[c + v] = rows[c][i]; }));
  Object.assign(T, { ya:'ヤ', yu:'ユ', yo:'ヨ', wa:'ワ', wi:'ウィ', wu:'ウ', we:'ウェ', wo:'ヲ',
    ca:'カ', ci:'シ', cu:'ク', ce:'セ', co:'コ',
    sha:'シャ', shi:'シ', shu:'シュ', she:'シェ', sho:'ショ', cha:'チャ', chi:'チ', chu:'チュ', che:'チェ', cho:'チョ',
    ja:'ジャ', ji:'ジ', ju:'ジュ', je:'ジェ', jo:'ジョ', tsu:'ツ', tsa:'ツァ', tsi:'ツィ', tse:'ツェ', tso:'ツォ',
    fa:'ファ', fi:'フィ', fu:'フ', fe:'フェ', fo:'フォ', thi:'ティ', dhi:'ディ', twu:'トゥ', dwu:'ドゥ' });
  ['k','g','s','z','t','d','n','h','b','p','m','r','l'].forEach(c => {
    const base = rows[c][1];
    T[c + 'ya'] = base + 'ャ'; T[c + 'yu'] = base + 'ュ'; T[c + 'yo'] = base + 'ョ';
  });
  return T;
})();
function romajiToKana(input) {
  let s = String(input || '').toLowerCase().replace(/ā/g,'aa').replace(/ī/g,'ii').replace(/ū/g,'uu').replace(/ē/g,'ee').replace(/ō/g,'ou');
  s = s.replace(/[\s_]+/g, '');
  if (!s || !/^[a-z'\-]+$/.test(s)) return null;
  const CONS = /[bcdfghjklmpqrstvwxyz]/;
  let out = '', i = 0;
  while (i < s.length) {
    const c = s[i];
    if (c === "'") { i++; continue; }
    if (c === '-') { out += 'ー'; i++; continue; }
    if (c === 'n') {
      const nx = s[i + 1];
      if (nx === undefined) { out += 'ン'; i++; continue; }
      if (nx === "'") { out += 'ン'; i += 2; continue; }
      if (nx === 'n') { out += 'ン'; i += /[aiueoy]/.test(s[i + 2] || '') ? 1 : 2; continue; }
      if (!/[aiueoy]/.test(nx)) { out += 'ン'; i++; continue; }
    }
    let hit = false;
    for (let L = 3; L >= 1; L--) {
      const k = s.substr(i, L);
      if (k.length === L && ROMAJI_TABLE[k]) { out += ROMAJI_TABLE[k]; i += L; hit = true; break; }
    }
    if (hit) continue;
    // 促音（kk, tt, ss…／tch）。語尾で子音が重なっているだけなら入力途中とみなす
    if (CONS.test(c) && c !== 'n' && ((c === s[i + 1] && i + 2 < s.length) || (c === 't' && s.substr(i + 1, 2) === 'ch'))) { out += 'ッ'; i++; continue; }
    // 入力途中の末尾の子音（sh, ky など）は無視
    if (/^[bcdfghjklmpqrstvwxyz]{1,2}$/.test(s.slice(i))) break;
    return null;
  }
  return out;
}
// 読みのゆらぎを吸収した比較用の形：長音/母音の連続・濁点半濁点・ヲ/ヂ/ヅなどを丸める
// （tofu / toufu / とうふ・ドウフ のどれでも同じ形になる）
function looseKana(s, unvoice) {
  const UNV = { ガ:'カ',ギ:'キ',グ:'ク',ゲ:'ケ',ゴ:'コ',ザ:'サ',ジ:'シ',ズ:'ス',ゼ:'セ',ゾ:'ソ',ダ:'タ',ヂ:'チ',ヅ:'ツ',デ:'テ',ド:'ト',
    バ:'ハ',ビ:'ヒ',ブ:'フ',ベ:'ヘ',ボ:'ホ',パ:'ハ',ピ:'ヒ',プ:'フ',ペ:'ヘ',ポ:'ホ',ヴ:'ウ',ヲ:'オ',ヰ:'イ',ヱ:'エ' };
  return String(s || '').replace(/ー/g, '')
    .replace(/([アカサタナハマヤラワガザダバパャ])ア/g, '$1').replace(/([イキシチニヒミリギジヂビピ])イ/g, '$1')
    .replace(/([ウクスツヌフムユルグズヅブプュ])ウ/g, '$1').replace(/([エケセテネヘメレゲゼデベペ])[イエ]/g, '$1')
    .replace(/([オコソトノホモヨロゴゾドボポョヲ])[ウオ]/g, '$1')
    .replace(/[ヲヰヱ]/g, c => UNV[c])
    .replace(/[ガ-ヂヅ-ヴ]/g, c => (unvoice ? UNV[c] : null) || c);
}
function kanaOnly(s) { return String(s || '').replace(/[^\u30A1-\u30FA\u30FC ]+/g, ' '); }

// よく使う食品用の漢字→読み（内蔵DBから学習できない語を補う。同じ語がDBにもある場合はこちらを優先）
const YOMI_SEED = {
  鶏:'トリ', 鳥:'トリ', 豚:'ブタ', 牛:'ギュウ', 羊:'ヒツジ', 肉:'ニク', 挽肉:'ヒキニク', 卵:'タマゴ', 玉子:'タマゴ', 米:'コメ', 飯:'メシ', 麺:'メン', 麦:'ムギ',
  魚:'サカナ', 鮭:'サケ', 鯖:'サバ', 鰯:'イワシ', 鮪:'マグロ', 鰹:'カツオ', 鯵:'アジ', 鱈:'タラ', 鰻:'ウナギ', 海老:'エビ', 蟹:'カニ', 貝:'カイ', 烏賊:'イカ', 蛸:'タコ', 帆立:'ホタテ',
  野菜:'ヤサイ', 果物:'クダモノ', 豆:'マメ', 大豆:'ダイズ', 納豆:'ナットウ', 豆腐:'トウフ', 乳:'ニュウ', 牛乳:'ギュウニュウ', 豆乳:'トウニュウ', 味噌:'ミソ', 醤油:'ショウユ',
  塩:'シオ', 砂糖:'サトウ', 酢:'ス', 油:'アブラ', 胡麻:'ゴマ', 蜂蜜:'ハチミツ', 生姜:'ショウガ', 葱:'ネギ', 玉葱:'タマネギ', 人参:'ニンジン', 大根:'ダイコン', 薯:'イモ', 芋:'イモ',
  南瓜:'カボチャ', 茄子:'ナス', 胡瓜:'キュウリ', 白菜:'ハクサイ', 蒟蒻:'コンニャク', 海苔:'ノリ', 昆布:'コンブ', 若布:'ワカメ', 椎茸:'シイタケ', 茸:'キノコ', 林檎:'リンゴ', 蜜柑:'ミカン', 苺:'イチゴ', 檸檬:'レモン',
  焼:'ヤ', 炒:'イタ', 煮:'ニ', 揚:'ア', 茹:'ユ', 蒸:'ム', 生:'ナマ', 冷:'ヒ', 冷凍:'レイトウ', 缶:'カン', 干:'ホ', 漬:'ツ', 粉:'コナ', 粉末:'フンマツ', 高野豆腐:'コウヤドウフ', 粥:'カユ', 汁:'シル', 鍋:'ナベ', 丼:'ドン',
  定食:'テイショク', 弁当:'ベントウ', 寿司:'スシ', 蕎麦:'ソバ', 饂飩:'ウドン', 餃子:'ギョウザ', 焼売:'シュウマイ', 唐揚:'カラアゲ', 天麩羅:'テンプラ', 味醂:'ミリン', 出汁:'ダシ',
  胸:'ムネ', 腿:'モモ', 皮:'カワ', 身:'ミ', 白:'シロ', 黒:'クロ', 赤:'アカ', 青:'アオ', 茶:'チャ', 緑茶:'リョクチャ', 紅茶:'コウチャ', 麦茶:'ムギチャ', 珈琲:'コーヒー', 水:'ミズ', 酒:'サケ',
  自家製:'ジカセイ', 手作:'テヅク', 半熟:'ハンジュク', 無糖:'ムトウ', 無塩:'ムエン', 低脂肪:'テイシボウ', 無脂肪:'ムシボウ', 高:'コウ', 低:'テイ', 糖質:'トウシツ', 盛:'モ', 全粒粉:'ゼンリュウフン',
  和:'ワ', 洋:'ヨウ', 中華:'チュウカ', 特製:'トクセイ', 濃厚:'ノウコウ', 新:'シン', 具:'グ', 入:'イ', 抜:'ヌ', 風:'フウ', 味:'アジ', 甘:'アマ', 辛:'カラ', 大:'オオ', 小:'コ', 中:'チュウ',
  朝:'アサ', 昼:'ヒル', 夜:'ヨル', 夕:'ユウ', 食:'ショク', 間食:'カンショク', 菓子:'カシ', 飴:'アメ', 餅:'モチ', 団子:'ダンゴ', 饅頭:'マンジュウ', 麹:'コウジ', 酵素:'コウソ',
};
// 内蔵DBの「表記→読み」から、漢字連続部分ごとの読み辞書を作る（例: 鶏むね肉/トリムネニク → 鶏=トリ, 肉=ニク）
const YOMI_LEX = (() => {
  const counts = new Map();
  const ONLY_JP = new RegExp('^[' + KANJI_CH + '\\u3040-\\u309F\\u30A0-\\u30FF\\u30FC]+$');
  const IS_KANJI = new RegExp('^[' + KANJI_CH + ']+$');
  const add = (run, reading) => {
    if (!run || !reading) return;
    const m = counts.get(run) || new Map();
    m.set(reading, (m.get(reading) || 0) + 1); counts.set(run, m);
  };
  LOCAL_DB.forEach(f => {
    const yomi = f.yomi;
    if (!f.name || !yomi || !/^[\u30A0-\u30FF\u30FC]+$/.test(yomi)) return;
    // （…）の補足は読みに含まれないことが多いので落として照合する
    const hadParen = /[（(]/.test(f.name);
    const name = f.name.replace(/[（(][^）)]*[）)]/g, '').replace(/[\s\u3000・]+/g, '');
    if (!name || !ONLY_JP.test(name)) return;
    const toks = name.match(KANJI_RUN_RE) || [];
    if (hadParen && toks.length === 1) return; // 手掛かり(かな)が無く、補足の読みが混ざっている可能性が高い
    let pos = 0, prevKanji = false, ok = true;
    const found = [];
    for (let t = 0; t < toks.length && ok; t++) {
      const tok = toks[t];
      if (IS_KANJI.test(tok)) {
        if (t === toks.length - 1) {
          const r = yomi.slice(pos);
          if (!r || r.length > (tok.length === 1 ? 4 : 3.2 * tok.length)) ok = false; else found.push([tok, r]);
        }
        prevKanji = true; continue;
      }
      const k = toKata(tok);
      const idx = yomi.indexOf(k, pos + (prevKanji ? 1 : 0));
      if (idx < 0 || (!prevKanji && idx !== pos)) { ok = false; break; }
      if (prevKanji) found.push([toks[t - 1], yomi.slice(pos, idx)]);
      pos = idx + k.length; prevKanji = false;
    }
    if (ok) found.forEach(([run, r]) => add(run, r));
  });
  const lex = new Map();
  counts.forEach((m, run) => {
    let best = '', n = 0;
    m.forEach((c, r) => { if (c > n || (c === n && r.length < best.length)) { n = c; best = r; } });
    lex.set(run, best);
  });
  Object.keys(YOMI_SEED).forEach(k => lex.set(k, YOMI_SEED[k]));
  return lex;
})();
function readKanjiRun(run) {
  let i = 0, res = '';
  while (i < run.length) {
    let hit = false;
    for (let L = Math.min(8, run.length - i); L >= 1; L--) {
      const r = YOMI_LEX.get(run.substr(i, L));
      if (r) { res += r; i += L; hit = true; break; }
    }
    if (!hit) i++; // 辞書に無い漢字は読みなし（残りの部分で検索できるようにする）
  }
  return res;
}
const _yomiCache = new Map();
// 食品名からカタカナの読みを推定する（かな・カタカナ部分はそのまま、漢字は内蔵DB由来の辞書で補う）
function guessYomi(name) {
  name = String(name || '');
  if (_yomiCache.has(name)) return _yomiCache.get(name);
  let out = '';
  (name.match(KANJI_RUN_RE) || []).forEach(tok => {
    out += new RegExp('^[' + KANJI_CH + ']').test(tok) ? readKanjiRun(tok) : toKata(tok).replace(/[^\u30A1-\u30FA\u30FC]/g, '');
  });
  _yomiCache.set(name, out);
  return out;
}
// 検索用フィールド（_search / _kana）を付与する。yomi 未設定のカスタム/複合食品は推定読みを使う
function withSearchFields(f, src) {
  const yomi = normalize(f.yomi || guessYomi(f.name));
  const nameN = normalize(f.name);
  f._search = nameN + ' ' + yomi + ' ' + normalize(f.tags || '') + ' ' + (f.en || '').toLowerCase();
  const kana = kanaOnly(yomi + ' ' + nameN + ' ' + normalize(f.tags || '')); // 読みを先頭に置く（前方一致の判定用）
  f._kana = looseKana(kana);          // 長音・ウ/オ・ヲなどのゆらぎだけ吸収
  f._kanaU = looseKana(kana, true);   // さらに濁点・半濁点も無視（rendaku: 豆腐=トウフ/ドウフ 等）
  if (src) f._src = src;
  return f;
}

LOCAL_DB.forEach(f => withSearchFields(f, 'local'));

// ── State ──
let entries = [], customFoods = [], comboFoods = [], exercises = [];
let errorLog = []; // AI操作や通信の失敗を記録する永続ログ（設定タブから閲覧・書き出しできる）
let userWeight = 65, statsPeriod = 'today', chartMode = 'raw';
let calChart = null, pfcChart = null, vitdStockChart = null;
let comboIngredients = [], editingId = null, activeAddMeal = null, exPanelOpen = false;
let calViewYear = new Date().getFullYear(), calViewMonth = new Date().getMonth();
let currentDate = toDateStr(new Date());
let ghToken = null, ghData = {}; // Google Health API
// Google Health の日別データから、必要な数値だけを残す。APIの返答に含まれる updatedToken（認証トークン）は端末にもクラウドにも保存しない
const GH_DAY_KEYS = ['date', 'steps', 'activeCalories', 'totalCalories', 'restingHeartRate', 'weight'];
function sanitizeGhData(obj) {
  const out = {};
  Object.keys(obj || {}).forEach(d => { const v = obj[d]; if (!v || typeof v !== 'object') return; const o = {}; GH_DAY_KEYS.forEach(k => { if (v[k] !== undefined) o[k] = v[k]; }); out[d] = o; });
  return out;
}
let dailyActivity = {}; // Garmin/Google Health未連携ユーザー向け：日別の手動歩数入力
let deferredPrompt = null;
let profile = { sex:'male', age:30, height:170, weight:65, bf:null, activityFactor:1.2, temp:22, neatPct:20 };

// 旧バージョン(座り仕事中心/立ち仕事が多い/肉体労働の3択)からの移行
// neatTier文字列が残っていて、まだneatPct(数値%)が無いプロフィールを変換する
function migrateNeatTier(p) {
  if (p && p.neatPct == null && p.neatTier) {
    p.neatPct = ({ low: 10, mid: 20, high: 30 })[p.neatTier] ?? 20;
  }
  return p;
}

// Firebase state
let fbUser = null;   // 現在ログイン中のユーザー
let fbDb  = null;    // Firestore インスタンス
let fbAuth = null;   // Auth インスタンス
let fbSyncing = false;

// localStorage からローカルキャッシュ読み込み（オフライン時のフォールバック）
try { entries     = JSON.parse(localStorage.getItem('pfcEntries')    || '[]'); } catch(e) {}
try { customFoods = JSON.parse(localStorage.getItem('pfcCustomFoods')|| '[]'); } catch(e) {}
try { comboFoods  = JSON.parse(localStorage.getItem('pfcComboFoods') || '[]'); } catch(e) {}
try { exercises   = JSON.parse(localStorage.getItem('pfcExercises')  || '[]'); } catch(e) {}
try { userWeight  = parseFloat(localStorage.getItem('pfcWeight') || '65'); } catch(e) {}
try { ghToken     = localStorage.getItem('ghToken') || null; } catch(e) {}
try { ghData      = JSON.parse(localStorage.getItem('ghData') || '{}'); } catch(e) {}
{ const raw = JSON.stringify(ghData); ghData = sanitizeGhData(ghData); if (JSON.stringify(ghData) !== raw) { try { localStorage.setItem('ghData', JSON.stringify(ghData)); } catch(e) {} } } // 過去に保存された認証トークンを取り除く
try { dailyActivity = JSON.parse(localStorage.getItem('pfcDailyActivity') || '{}'); } catch(e) {}
try { const p = JSON.parse(localStorage.getItem('pfcProfile') || 'null'); if(p) profile = migrateNeatTier({...profile, ...p}); } catch(e) {}
try { errorLog = JSON.parse(localStorage.getItem('pfcErrorLog') || '[]'); } catch(e) {}

// ── エラーログ ──
// AIへの操作依頼が失敗した時に「理由が何も表示されない」ことがある問題への対応。
// チャット欄への一時的な表示だけでなく、後から見返せる・書き出せる形で永続化しておく。
function logError(context, message, detail) {
  errorLog.push({ id: Date.now() + Math.random(), time: new Date().toISOString(), context, message: String(message || ''), detail: detail ? String(detail).slice(0, 1000) : '' });
  if (errorLog.length > 200) errorLog = errorLog.slice(-200); // 肥大化対策
  try { localStorage.setItem('pfcErrorLog', JSON.stringify(errorLog)); } catch (e) {}
  renderErrorLogPanel();
}
function clearErrorLog() {
  errorLog = [];
  try { localStorage.setItem('pfcErrorLog', JSON.stringify(errorLog)); } catch (e) {}
  renderErrorLogPanel();
}
function exportErrorLog() {
  const lines = errorLog.slice().reverse().map(e => `[${e.time}] ${e.context}: ${e.message}${e.detail ? '\n  詳細: ' + e.detail : ''}`);
  const blob = new Blob([lines.length ? lines.join('\n\n') : 'エラーログはありません'], { type: 'text/plain' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url; a.download = `pfc_errorlog_${toDateStr(new Date())}.txt`; a.click();
  URL.revokeObjectURL(url);
}
function renderErrorLogPanel() {
  const countEl = document.getElementById('errorLogCount'); if (countEl) countEl.textContent = errorLog.length;
  const box = document.getElementById('errorLogPreview'); if (!box) return;
  if (!errorLog.length) { box.innerHTML = '<div style="font-size:12px;color:var(--text-sub)">記録されたエラーはありません</div>'; return; }
  box.innerHTML = errorLog.slice(-5).reverse().map(e =>
    `<div style="font-size:11px;padding:6px 2px;border-bottom:1px solid var(--border)">
      <div style="color:var(--text-sub)">${e.time.replace('T',' ').slice(0,16)}・${e.context}</div>
      <div>${e.message}</div>
    </div>`
  ).join('');
}

function toDateStr(d) {
  // ローカルの年月日で組み立てる（toISOString()はUTC変換されるため、
  // 日本のような正のUTCオフセットのタイムゾーンでは日付が1日ずれるバグの原因になっていた）
  const y = d.getFullYear();
  const m = String(d.getMonth() + 1).padStart(2, '0');
  const day = String(d.getDate()).padStart(2, '0');
  return `${y}-${m}-${day}`;
}
function fmtDate(s) { const d = new Date(s+'T00:00:00'); return d.toLocaleDateString('ja-JP',{month:'long',day:'numeric',weekday:'short'}); }
function isToday(s) { return s === toDateStr(new Date()); }
function r1(n) { return Math.round(n*10)/10; }
function r2(n) { return Math.round(n*100)/100; }
function ri(n) { return Math.round(n); }

// ローカル保存（常に実行 — オフライン時のキャッシュ）
function saveLocal() {
  try { localStorage.setItem('pfcEntries',     JSON.stringify(entries));     } catch(e) {}
  try { localStorage.setItem('pfcExercises',   JSON.stringify(exercises));   } catch(e) {}
  try { localStorage.setItem('pfcCustomFoods', JSON.stringify(customFoods)); } catch(e) {}
  try { localStorage.setItem('pfcComboFoods',  JSON.stringify(comboFoods));  } catch(e) {}
}

// Firestore への保存（ログイン済みの場合）
// 全データを1ドキュメントにまとめて保存（シンプル設計）
// ── 保存の仕組み ──
//  ・変更があるたびに cloudDirty を立て、送信に成功したら下げる（未送信の変更が残っているかを常に把握する）
//  ・送信中にさらに変更があれば、送信が終わった直後にもう一度送る（直列化。古い内容で上書きしない）
//  ・失敗したら再試行（5秒→15秒→60秒→3分…）。オンライン復帰・アプリが前面に戻ったときにも再試行する
//  ・失敗はエラーログに記録し、ヘッダーの同期ドット（●）で状態を表示する
let cloudDirty = false, cloudStatus = 'idle', _cloudInFlight = false, _cloudRequeue = false, _cloudRetryTimer = null, _cloudRetryCount = 0, _cloudLastError = '';
let CLOUD_RETRY_MS = [5000, 15000, 60000, 180000];
let _lastCloudStamp = '', _lastForegroundPull = 0;   // クラウド上のデータの updatedAt（最後に確認した値）と、前面復帰時の読み込み時刻
const CLOUD_DOC_WARN_BYTES = 800000, CLOUD_DOC_MAX_BYTES = 1000000;   // Firestoreの1ドキュメントは1MiBまで
let _fsMod = null, _cloudWarnedSize = false, _cloudLastLogged = { msg: '', t: 0 };
async function fsApi() {
  if (window.__fsApi) return window.__fsApi;   // テスト用の差し替え口
  if (!_fsMod) _fsMod = await import('https://www.gstatic.com/firebasejs/10.12.0/firebase-firestore.js');
  return _fsMod;
}
function setCloudStatus(st, detail) {
  cloudStatus = st;
  const el = document.getElementById('cloudDot'); if (!el) return;
  const map = { synced: ['#34c759', '同期済み'], syncing: ['#3a8ee6', '同期中…'], pending: ['#ff9f0a', '未送信の変更があります（再試行します）'], error: ['#ff3b30', '同期に失敗しました'], offline: ['#ff9f0a', 'オフライン（接続後に同期します）'], idle: ['', ''] };
  const [color, label] = map[st] || map.idle;
  el.style.display = (fbUser && color) ? 'inline-block' : 'none'; el.style.background = color;
  el.title = label + (detail ? `：${detail}` : ''); el.dataset.state = st;
}
function cloudDotTap() {
  const label = { synced: '同期済みです', syncing: '同期中です…', pending: '未送信の変更があります。再試行します', error: '同期に失敗しています。再試行します' + (_cloudLastError ? `（${_cloudLastError}）` : ''), offline: 'オフラインです。接続後に同期します' }[cloudStatus] || '';
  if (cloudDirty && !_cloudInFlight) saveToCloud();
  if (label && typeof showToast === 'function') showToast(label);
}
function scheduleCloudRetry() {
  clearTimeout(_cloudRetryTimer);
  const ms = CLOUD_RETRY_MS[Math.min(_cloudRetryCount, CLOUD_RETRY_MS.length - 1)]; _cloudRetryCount++;
  _cloudRetryTimer = setTimeout(() => { if (cloudDirty && !_cloudInFlight) saveToCloud(); }, ms);
}
function logCloudError(msg, detail) {   // 同じ内容のエラーは10分に1回だけ記録する（再試行で履歴が埋まらないように）
  const now = Date.now(); if (_cloudLastLogged.msg === msg && now - _cloudLastLogged.t < 600000) return;
  _cloudLastLogged = { msg, t: now }; logError('クラウド保存', msg, detail || '');
}
async function saveToCloud() {
  if (!fbDb || !fbUser) return;
  cloudDirty = true;
  if (_cloudInFlight) { _cloudRequeue = true; return; }
  _cloudInFlight = true; clearTimeout(_cloudRetryTimer); setCloudStatus('syncing');
  let retry = false;
  try {
    const { doc, setDoc } = await fsApi();
    const payload = { entries, exercises, customFoods, comboFoods, quickSeasonings, profile, dailyActivity, ghData: sanitizeGhData(ghData), promptTemplates, updatedAt: new Date().toISOString() };
    const bytes = new TextEncoder().encode(JSON.stringify(payload)).length;
    if (bytes > CLOUD_DOC_MAX_BYTES) { // 1MiBを超えると保存できない。以前は黙って失敗していた
      _cloudLastError = `データが大きすぎます（${Math.round(bytes / 1024)}KB / 上限1024KB）`;
      logCloudError(_cloudLastError, '古い記録を整理するか、データの分割保存が必要です'); setCloudStatus('error', _cloudLastError); return;
    }
    if (bytes > CLOUD_DOC_WARN_BYTES && !_cloudWarnedSize) { _cloudWarnedSize = true; logError('クラウド保存', `クラウドのデータが上限に近づいています（${Math.round(bytes / 1024)}KB / 上限1024KB）`, ''); }
    await setDoc(doc(fbDb, 'users', fbUser.uid), payload);
    _cloudRetryCount = 0; _cloudLastError = ''; _lastCloudStamp = payload.updatedAt;
    if (!_cloudRequeue) cloudDirty = false;
  } catch (e) {
    _cloudLastError = (e && (e.code || e.message)) ? String(e.code || e.message).slice(0, 120) : String(e);
    console.warn('Cloud save failed:', e); logCloudError(`クラウドへの保存に失敗しました（${_cloudLastError}）`, (e && e.stack) || '');
    retry = true;
  } finally {
    _cloudInFlight = false;
    if (retry) { setCloudStatus(navigator.onLine === false ? 'offline' : 'error', _cloudLastError); scheduleCloudRetry(); }
    else if (cloudDirty) { setCloudStatus('syncing'); }
    else setCloudStatus('synced');
    if (_cloudRequeue && !retry) { _cloudRequeue = false; saveToCloud(); }
    else _cloudRequeue = false;
  }
}
// 入力中の保存待ちを即時に送る／未送信の変更があれば再送する（画面が隠れた・閉じられる・オンライン復帰・前面に戻ったとき）
function flushCloudSave() {
  if (_cloudSaveTimer) { clearTimeout(_cloudSaveTimer); _cloudSaveTimer = null; queueCloudSave(); }
  else if (cloudDirty && !_cloudInFlight) saveToCloud();
}
window.addEventListener('online', () => { if (cloudDirty) flushCloudSave(); });
window.addEventListener('pagehide', flushCloudSave);
document.addEventListener('visibilitychange', () => { flushCloudSave(); if (document.visibilityState === 'visible') pullOnForeground(); });

// ── 初回クラウド同期ゲート ──
// 起動直後、ローカルキャッシュがクラウドの最新状態を反映しているとは限らない
// （別デバイスでの変更が未反映の可能性がある）。この確認が終わるまでは
// クラウドへの保存を行わない（＝古いローカル状態でクラウドを上書きしてしまう事故を防ぐ）。
let initialSyncDone = false;
let pendingCloudSave = false;
function queueCloudSave() {
  cloudDirty = true;
  if (!initialSyncDone) { pendingCloudSave = true; return; }
  saveToCloud();
}
function markInitialSyncDone() {
  if (initialSyncDone) return;
  initialSyncDone = true;
  const gate = document.getElementById('syncGate');
  if (gate) gate.style.display = 'none';
  if (pendingCloudSave) { pendingCloudSave = false; saveToCloud(); }
}
// 万一 onAuthStateChanged が発火しない等の異常時でも、画面が固まったままにならないための保険
setTimeout(() => { if (!initialSyncDone) { console.warn('Sync gate timeout — releasing'); markInitialSyncDone(); } }, 8000);

// ローカル＋クラウドへ同時保存
function save() { saveLocal(); queueCloudSave(); }
// 入力中の連続オートセーブ用：ローカルは即時、クラウドは間引いて送信
var _cloudSaveTimer = null;
function saveDebounced() {
  saveLocal();
  clearTimeout(_cloudSaveTimer);
  cloudDirty = true;
  _cloudSaveTimer = setTimeout(() => { _cloudSaveTimer = null; queueCloudSave(); }, 800);
}
function saveCustom() { saveLocal(); queueCloudSave(); }
function saveExercises() { saveLocal(); queueCloudSave(); }
// 手入力の歩数・Google Healthの日別データも、他の記録と同じようにクラウドへ同期する（入力中の連続保存に備えて少し待ってから送る）
function queueCloudSaveSoon() {
  clearTimeout(_cloudSaveTimer); cloudDirty = true;
  _cloudSaveTimer = setTimeout(() => { _cloudSaveTimer = null; queueCloudSave(); }, 800);
}
function saveGhData() { try { localStorage.setItem('ghData', JSON.stringify(ghData)); } catch(e) {} queueCloudSaveSoon(); }
function saveDailyActivity() { try { localStorage.setItem('pfcDailyActivity', JSON.stringify(dailyActivity)); } catch(e) {} queueCloudSaveSoon(); }
function saveProfile() {
  const oldWeight = profile.weight;
  profile.sex    = document.getElementById('pSex').value;
  profile.age    = parseInt(document.getElementById('pAge').value)    || 30;
  profile.height = parseFloat(document.getElementById('pHeight').value) || 170;
  profile.weight = parseFloat(document.getElementById('pWeight').value) || 65;
  // 体重が実際に変わった時だけ、その日の実測値として体重ログに記録する
  // （「体重をあまり量らない」利用を前提に、設定画面の体重欄を更新したタイミング＝実測、として
  //  裏で自動的に履歴を貯める。専用の入力UIを増やさずに済む）
  if (profile.weight !== oldWeight) recordWeightLogEntry(toDateStr(new Date()), profile.weight);
  const bf = parseFloat(document.getElementById('pBF').value);
  profile.bf   = isNaN(bf) ? null : bf;
  profile.temp = parseFloat(document.getElementById('pTemp').value) || 22;
  try { localStorage.setItem('pfcProfile', JSON.stringify(profile)); } catch(e) {}
  queueCloudSave();
  renderBmrFormulaDesc();
  renderBmrPreview();
}
function setGoalMode(mode) {
  profile.goalMode = mode;
  document.querySelectorAll('.goal-mode-btn').forEach(b => b.classList.toggle('active', b.dataset.mode === mode));
  const customPanel = document.getElementById('customGoalPanel');
  if (customPanel) customPanel.style.display = mode === 'custom' ? 'block' : 'none';
  if (mode !== 'custom') {
    // プリセット時は自動計算値でプレビュー更新
    const g = goals();
    ['Cal','P','F','C'].forEach(k => {
      const el = document.getElementById('pGoal'+k);
      if (el) el.value = g[k.toLowerCase()];
    });
  }
  saveGoalSettings();
  renderBmrPreview();
}
function saveGoalSettings() {
  const mode = profile.goalMode || 'normal';
  if (mode === 'custom') {
    profile.customGoal = {
      cal: parseFloat(document.getElementById('pGoalCal').value) || calcTDEE(),
      p:   parseFloat(document.getElementById('pGoalP').value)   || 100,
      f:   parseFloat(document.getElementById('pGoalF').value)   || 60,
      c:   parseFloat(document.getElementById('pGoalC').value)   || 200,
    };
  }
  try { localStorage.setItem('pfcProfile', JSON.stringify(profile)); } catch(e) {}
  queueCloudSave();
  renderBmrPreview();
}
function setActivity(el) {
  document.querySelectorAll('#activityToggle .toggle-btn').forEach(b => b.classList.remove('active'));
  el.classList.add('active');
  profile.activityFactor = parseFloat(el.dataset.val);
  saveProfile();
}
function setBmrFormula(el) {
  document.querySelectorAll('#bmrFormulaToggle .toggle-btn').forEach(b => b.classList.remove('active'));
  el.classList.add('active');
  profile.bmrFormula = el.dataset.formula;
  saveProfile();
  renderBmrFormulaDesc();
}
function renderBmrFormulaDesc() {
  const el = document.getElementById('bmrFormulaDesc');
  if (!el) return;
  if (profile.bmrFormula === 'katch') {
    el.textContent = usingKatchFallback()
      ? 'Katch-McArdle式：体脂肪率が未設定のため、算出できずMifflin-St Jeor式にフォールバック中です。上の「体脂肪率」を入力すると切り替わります。'
      : 'Katch-McArdle式：除脂肪体重(体重×(1−体脂肪率))から算出する式です。体脂肪率の実測値があるほど精度が上がります。';
  } else {
    el.textContent = 'Mifflin-St Jeor式：体重・身長・年齢・性別から算出する一般的な式です。';
  }
}
function setNeatPct(val) {
  profile.neatPct = Math.max(5, Math.min(35, Math.round(Number(val))));
  const slider = document.getElementById('neatSlider');
  if (slider) slider.value = profile.neatPct;
  renderNeatSliderInfo();
  saveProfile();
}
function renderNeatSliderInfo() {
  const pct = getNeatPct();
  const bmr = calcBMR();
  const addedKcal = Math.round(bmr * pct / 100);
  const labelEl = document.getElementById('neatSliderLabel');
  if (labelEl) labelEl.textContent = `+${pct}%（${getNeatLabel(pct)}）・目安 約+${addedKcal}kcal/日`;
}

function initGoalUI() {
  const mode = profile.goalMode || 'normal';
  document.querySelectorAll('.goal-mode-btn').forEach(b => b.classList.toggle('active', b.dataset.mode === mode));
  const customPanel = document.getElementById('customGoalPanel');
  if (customPanel) customPanel.style.display = mode === 'custom' ? 'block' : 'none';
  const g = goals();
  ['Cal','P','F','C'].forEach(k => {
    const el = document.getElementById('pGoal'+k);
    if (el) el.value = (profile.customGoal && mode === 'custom') ? profile.customGoal[k.toLowerCase()] : g[k.toLowerCase()];
  });
  updateGoalModeDesc(mode);
  updateGoalPreview();
}
function updateGoalModeDesc(mode) {
  ['normal','recomp','custom'].forEach(m => {
    const el = document.querySelector('.goal-desc-'+m);
    if (el) el.style.display = m === mode ? '' : 'none';
  });
}
function updateGoalPreview() {
  const g = goals();
  const setEl = (id, val) => { const el = document.getElementById(id); if (el) el.textContent = val; };
  setEl('goalPreviewCal', g.cal);
  setEl('goalPreviewP',   g.p);
  setEl('goalPreviewF',   g.f);
  setEl('goalPreviewC',   g.c);
}
function initProfile() {
  const set = (id, val) => { const el = document.getElementById(id); if (el && val !== undefined) el.value = val; };
  set('pSex',    profile.sex);
  set('pAge',    profile.age);
  set('pHeight', profile.height);
  set('pWeight', profile.weight);
  set('pBF',     profile.bf ?? '');
  set('pTemp',   profile.temp);
  document.querySelectorAll('#bmrFormulaToggle .toggle-btn[data-formula]').forEach(b => {
    b.classList.toggle('active', b.dataset.formula === (profile.bmrFormula || 'mifflin'));
  });
  renderBmrFormulaDesc();
  document.querySelectorAll('#activityToggle .toggle-btn[data-val]').forEach(b => {
    b.classList.toggle('active', parseFloat(b.dataset.val) === profile.activityFactor);
  });
  const slider = document.getElementById('neatSlider');
  if (slider) slider.value = getNeatPct();
  renderNeatSliderInfo();
  renderBmrPreview();
}
function renderBmrPreview() {
  const el = document.getElementById('bmrPreview');
  if (!el) return;
  const tdee = calcTDEE();
  const bmr  = Math.round(calcBMR());
  const g    = goals();
  const modeLabel = { normal:'通常', recomp:'低脂質リコンプ', custom:'カスタム' }[profile.goalMode || 'normal'];
  const modeDesc = describeActivity(getTdeeBreakdown(currentDate));
  el.innerHTML = `
    <div style="display:grid;grid-template-columns:1fr 1fr;gap:6px;font-size:12px;margin-bottom:6px">
      <div style="background:var(--bg);border-radius:8px;padding:8px 10px">
        <div style="color:var(--text-sub);font-size:10px">基礎代謝 (BMR)</div>
        <div style="font-weight:700;font-size:16px">${bmr} <span style="font-size:10px;font-weight:400">kcal</span></div>
      </div>
      <div style="background:var(--bg);border-radius:8px;padding:8px 10px">
        <div style="color:var(--text-sub);font-size:10px">推定TDEE（本日）</div>
        <div style="font-weight:700;font-size:16px">${tdee} <span style="font-size:10px;font-weight:400">kcal</span></div>
      </div>
    </div>
    <div style="font-size:10px;color:var(--text-sub);margin-bottom:10px">今日の算出方法: ${modeDesc}</div>
    <div style="font-size:11px;color:var(--text-sub);margin-bottom:4px">現在の目標（${modeLabel}プリセット）</div>
    <div style="display:grid;grid-template-columns:repeat(4,1fr);gap:4px;text-align:center;font-size:11px">
      <div style="background:var(--bg);border-radius:6px;padding:5px 2px"><div style="color:var(--text-sub);font-size:9px">kcal</div><div style="font-weight:600">${g.cal}</div></div>
      <div style="background:#e3f0ff;border-radius:6px;padding:5px 2px"><div style="color:#3266ad;font-size:9px">P(g)</div><div style="font-weight:600;color:#1a1d23">${g.p}</div></div>
      <div style="background:#fff3e0;border-radius:6px;padding:5px 2px"><div style="color:#a06a1a;font-size:9px">F(g)</div><div style="font-weight:600;color:#1a1d23">${g.f}</div></div>
      <div style="background:#e8f5e9;border-radius:6px;padding:5px 2px"><div style="color:#2f7d3a;font-size:9px">C(g)</div><div style="font-weight:600;color:#1a1d23">${g.c}</div></div>
    </div>`;
  updateGoalPreview();
}

// ── PWA ──
window.addEventListener('beforeinstallprompt', e => {
  e.preventDefault(); deferredPrompt = e;
  document.getElementById('install-banner').style.display = 'flex';
});
document.getElementById('install-btn').addEventListener('click', async () => {
  if (!deferredPrompt) return;
  deferredPrompt.prompt();
  await deferredPrompt.userChoice;
  deferredPrompt = null;
  document.getElementById('install-banner').style.display = 'none';
});
if ('serviceWorker' in navigator) {
  navigator.serviceWorker.register('sw.js').catch(() => {});
}

// ── Header ──
function updateHeader() {
  const d = new Date();
  document.getElementById('headerDate').textContent = d.toLocaleDateString('ja-JP',{month:'long',day:'numeric',weekday:'long'});
}
updateHeader();

// ── Helpers ──
function getAllFoods() {
  return [
    ...LOCAL_DB,
    ...customFoods.map(f => withSearchFields({...f}, 'custom')),
    ...comboFoods.map(f => withSearchFields({...f}, 'combo')),
  ];
}
// エントリ名から食品DBを引いて密度(g/ml)を取得する。見つからない/未設定の場合は
// 水とほぼ同じ1.0g/mlとして概算する（小さじ・大さじでのざっくり換算用）
function getFoodDensity(name) {
  const f = getAllFoods().find(x => x.name === name);
  return (f && f.density) || 1.0;
}
// ── 活動量の精緻化：NEAT（運動以外の日常活動）レベル ──
// 職種・生活スタイルによる基礎的な活動量の差をBMRへの倍率(%)として表現。
// 3択ではなく5%刻みのスライダーで連続的に指定できる（目安として下の3点を表示）
const NEAT_TIERS = {
  low:  { label: '座り仕事中心', mult: 1.10 },
  mid:  { label: '立ち仕事が多い', mult: 1.20 },
  high: { label: '肉体労働・重作業', mult: 1.30 },
};
function getNeatPct() { return profile.neatPct ?? 20; }
function getNeatMult() { return 1 + getNeatPct() / 100; }
// 現在の%に最も近い目安ラベルを返す（境界の解釈に幅を持たせるため「寄り」を付ける）
function getNeatLabel(pct) {
  const p = pct ?? getNeatPct();
  if (p <= 7)  return '座り仕事中心（ほぼ動かない）';
  if (p <= 13) return '座り仕事中心';
  if (p <= 17) return '座り仕事寄り';
  if (p <= 23) return '立ち仕事が多い';
  if (p <= 27) return '立ち仕事寄り〜やや肉体労働';
  if (p <= 33) return '肉体労働・重作業';
  return '肉体労働・重作業（かなり多い）';
}
// 歩数→消費カロリー推定（体重比例、約35kcal/1000歩@70kgが目安）
function stepsToCal(steps, weightKg) {
  return Math.round((steps || 0) * (weightKg || 65) * 0.0005);
}
// 指定日の「実測 or 手入力による活動カロリー」を解決する
// ① Google Health連携で実測値が取れていればそれを最優先
// ② 手動入力した歩数があればそこから推定
// ③ どちらも無ければnullを返し、呼び出し側で従来の活動係数にフォールバックする
function getDetailedActivity(date) {
  const gh = ghData[date];
  if (gh && gh.activeCalories > 0) {
    return { activeCal: gh.activeCalories, steps: gh.steps || 0, source: 'google_health' };
  }
  const manual = dailyActivity[date];
  if (manual && manual.steps > 0) {
    const w = profile.weight || userWeight || 65;
    return { activeCal: stepsToCal(manual.steps, w), steps: manual.steps, source: 'manual_steps' };
  }
  return null;
}
// BMRを「値＋計算式（数値を代入した形）」で返す。CSV出力などで根拠を示すために使う
function getBmrDetail() {
  const w = profile.weight || userWeight || 65;
  const h = profile.height || 170;
  const age = profile.age || 30;
  const isMale = profile.sex !== 'female';
  let raw, name, expr;
  if (profile.bmrFormula === 'katch' && profile.bf != null && profile.bf > 0) {
    // Katch-McArdle式：除脂肪体重(LBM)ベース。性別・年齢を使わず、体組成のみで算出する
    const lbm = w * (1 - profile.bf / 100);
    raw = 370 + 21.6 * lbm;
    name = 'Katch-McArdle';
    expr = `370 + 21.6 × LBM(${r1(lbm)}kg = ${w}kg × (1 − ${profile.bf}%))`;
  } else {
    // Mifflin-St Jeor式（体脂肪率が未設定/0の場合はこちらにフォールバック）
    raw = isMale ? 10*w + 6.25*h - 5*age + 5 : 10*w + 6.25*h - 5*age - 161;
    name = 'Mifflin-St Jeor' + (usingKatchFallback() ? '（体脂肪率未設定のためKatchから切替）' : '');
    expr = `10×${w} + 6.25×${h} − 5×${age} ${isMale ? '+ 5' : '− 161'}`;
  }
  const temp = profile.temp ?? 22;
  const tempMult = temp < 10 ? 1.06 : (temp >= 30 ? 1.025 : 1);
  return { bmr: raw * tempMult, raw, name, expr, temp, tempMult, w, h, age, sex: isMale ? '男性' : '女性', bf: profile.bf };
}
function calcBMR() { return getBmrDetail().bmr; }
function usingKatchFallback() {
  return profile.bmrFormula === 'katch' && !(profile.bf != null && profile.bf > 0);
}
// 食事誘発熱産生（TEF/DIT）: 食事の消化・吸収・代謝で消費されるエネルギー。総消費の約10%（混合食）。
// 「BMR×NEAT＋活動カロリー」にはTEFが含まれないため、NEAT方式では最後に上乗せする。
// （従来の活動係数方式の 1.2〜1.9 は、もともとTEFを含んだ係数なので上乗せしない）
const TEF_RATIO = 0.10;
// 歩数などの活動データが全く無い日に仮定する歩数（国民健康・栄養調査の成人男性平均 約7,000〜8,000歩のうち、
// NEAT倍率に職場での動きが既に含まれることを考慮して控えめにした値）
const DEFAULT_DAILY_STEPS = 6000;
// 直近14日の実測/手入力から活動カロリーの平均を求める（3日分以上あるときだけ。入力の手間をかけずに本人の実態へ寄せる）
function recentAvgActiveCal(date) {
  const base = new Date(date + 'T00:00:00');
  let sum = 0, n = 0;
  for (let i = 1; i <= 14; i++) {
    const d = new Date(base); d.setDate(d.getDate() - i);
    const det = getDetailedActivity(toDateStr(d));
    if (det && det.activeCal > 0) { sum += det.activeCal; n++; }
  }
  return n >= 3 ? Math.round(sum / n) : null;
}
function getTdeeBreakdown(date) {
  date = date || currentDate;
  const bmr = calcBMR();
  const detail = getDetailedActivity(date);

  // ざっくり設定（座位中心=1.2 以外の活動係数）を本人が明示的に選んでいて、その日の活動データも無い場合のみ従来方式
  const simple = !detail && (profile.activityFactor || 1.2) !== 1.2;
  if (simple) {
    const base = bmr * profile.activityFactor;
    return { bmr, detail, base, tdee: Math.round(base), tef: 0, activeCal: 0, assumed: null, simple: true };
  }

  // NEAT方式: BMR×NEAT倍率 ＋ 活動カロリー ＋ TEF
  // 活動カロリーは、その日の実測/手入力 → 直近平均 → 標準歩数 の順で解決する（データが無い日でもNEAT設定が効く）
  let activeCal, assumed = null;
  if (detail) {
    activeCal = detail.activeCal;
  } else {
    const avg = recentAvgActiveCal(date);
    if (avg != null) { activeCal = avg; assumed = 'recent_avg'; }
    else { activeCal = stepsToCal(DEFAULT_DAILY_STEPS, profile.weight || userWeight || 65); assumed = 'default_steps'; }
  }
  const pre = bmr * getNeatMult() + activeCal;
  const tef = pre * TEF_RATIO;
  const base = pre + tef;
  return { bmr, detail, base, tdee: Math.round(base), tef: Math.round(tef), activeCal, assumed, simple: false };
}
// TDEEの計算式を、数値を代入した形で返す（CSVなど根拠の記録用）
function describeTdeeFormula(tb) {
  const b = ri(tb.bmr);
  if (tb.simple) return `BMR ${b} × 活動係数 ${profile.activityFactor} = ${tb.tdee}`;
  const mult = getNeatMult();
  return `(BMR ${b} × NEAT ${mult.toFixed(2)} + 活動 ${ri(tb.activeCal)}) × (1 + TEF ${Math.round(TEF_RATIO*100)}%) = ${tb.tdee}`;
}
function tdeeActivitySource(tb) {
  if (tb.simple) return 'simple_factor';
  if (tb.detail) return tb.detail.source === 'google_health' ? 'google_health' : 'manual_steps';
  return tb.assumed === 'recent_avg' ? 'recent_14d_avg' : 'default_steps';
}
// 画面・CSV・AI向けの「活動分の説明」（実測か、仮定かを区別して表示する）
function describeActivity(tb) {
  if (tb.simple) return `活動係数 ${profile.activityFactor || 1.2}（ざっくり設定）`;
  const neat = `NEAT「${getNeatLabel()}」+${getNeatPct()}%`;
  let act;
  if (tb.detail) act = `活動 ${tb.activeCal}kcal（${tb.detail.source==='google_health'?'Google Health実測':'歩数入力'} ${(tb.detail.steps||0).toLocaleString()}歩）`;
  else if (tb.assumed === 'recent_avg') act = `想定活動 ${tb.activeCal}kcal（直近の記録の平均）`;
  else act = `想定活動 ${tb.activeCal}kcal（標準${DEFAULT_DAILY_STEPS.toLocaleString()}歩相当・活動データなし）`;
  return `${neat} + ${act} + 食事誘発熱産生 ${tb.tef}kcal（+${Math.round(TEF_RATIO*100)}%）`;
}
function calcTDEE(date) {
  return getTdeeBreakdown(date).tdee;
}
function goals() {
  // カスタム目標が有効な場合はそちらを優先
  if (profile.goalMode === 'custom' && profile.customGoal) {
    return { ...profile.customGoal };
  }
  const tdee = calcTDEE();
  const w = profile.weight || userWeight || 65;
  if (profile.goalMode === 'recomp') {
    // 低脂質リコンププリセット: 通常タンパク・低脂質・カロリー維持
    const p = r1(w * 1.6);
    const f = r1(tdee * 0.15 / 9);
    const c = r1((tdee - p*4 - f*9) / 4);
    return { cal: tdee, p, f, c };
  }
  // 通常プリセット (デフォルト)
  const p = r1(w * 1.6);
  const f = r1(tdee * 0.25 / 9);
  const c = r1((tdee - p*4 - f*9) / 4);
  return { cal: tdee, p, f, c };
}
function sumEntries(list) {
  const t = list.reduce((a,e) => ({
    cal:a.cal+e.cal, p:a.p+e.p, f:a.f+e.f, c:a.c+e.c,
    fiber:a.fiber+(e.fiber||0), iron:a.iron+(e.iron||0), calcium:a.calcium+(e.calcium||0),
    vitc:a.vitc+(e.vitc||0), vitd:a.vitd+(e.vitd||0), salt:a.salt+(e.salt||0),
    vita:a.vita+(e.vita||0), vite:a.vite+(e.vite||0), vitk:a.vitk+(e.vitk||0), iodine:a.iodine+(e.iodine||0),
  }), {cal:0,p:0,f:0,c:0,fiber:0,iron:0,calcium:0,vitc:0,vitd:0,salt:0,vita:0,vite:0,vitk:0,iodine:0});
  // 食物繊維の内訳（水溶性/不溶性/区分不明）。過去の記録も食品名からDBの比率で補完して集計する
  t.fibS = 0; t.fibI = 0; t.fibU = 0;
  list.forEach(e => { const sp = getFiberSplit(e); t.fibS += sp.s; t.fibI += sp.i; t.fibU += sp.u; });
  return t;
}
function getDayEntries(d) { return entries.filter(e => e.date === d); }

// ── Date ──
function updateDateHeader() {
  document.getElementById('dateLabel').textContent = fmtDate(currentDate);
  const tod = isToday(currentDate);
  document.getElementById('todayBadge').style.display = tod ? 'inline' : 'none';
  document.getElementById('todayBtn').style.display = tod ? 'none' : 'block';
}
function changeDate(d) {
  const dt = new Date(currentDate+'T00:00:00'); dt.setDate(dt.getDate()+d);
  currentDate = toDateStr(dt); activeAddMeal = null; editingId = null; exPanelOpen = false;
  const panel = document.getElementById('exerciseAddPanel'); if(panel) panel.style.display='none';
  const btn   = document.getElementById('exAddBtn');          if(btn)   btn.textContent='＋ 追加';
  updateDateHeader(); renderRecord(); renderCalendar();
}
function goToday() {
  currentDate = toDateStr(new Date()); calViewYear = new Date().getFullYear(); calViewMonth = new Date().getMonth();
  activeAddMeal = null; editingId = null; exPanelOpen = false;
  const panel = document.getElementById('exerciseAddPanel'); if(panel) panel.style.display='none';
  const btn   = document.getElementById('exAddBtn');          if(btn)   btn.textContent='＋ 追加';
  updateDateHeader(); renderRecord(); renderCalendar();
}
function jumpToDate(d) {
  currentDate = d; calViewYear = parseInt(d.split('-')[0]); calViewMonth = parseInt(d.split('-')[1])-1;
  activeAddMeal = null; editingId = null; updateDateHeader(); renderRecord(); closeCalendar();
}

// ── Calendar ──
function toggleCalendar(e) {
  e.stopPropagation();
  const ol = document.getElementById('calOverlay');
  if (ol.classList.contains('open')) { closeCalendar(); return; }
  const rect = document.getElementById('dateDisplay').getBoundingClientRect();
  const popup = document.getElementById('calPopup');
  popup.style.top = (rect.bottom+4)+'px';
  popup.style.left = Math.max(4, rect.left)+'px';
  calViewYear = parseInt(currentDate.split('-')[0]); calViewMonth = parseInt(currentDate.split('-')[1])-1;
  renderCalendar(); ol.classList.add('open');
}
function closeCalendar() { document.getElementById('calOverlay').classList.remove('open'); }
function closeCalIfOutside(e) { if (e.target === document.getElementById('calOverlay')) closeCalendar(); }
function calPrev() { calViewMonth--; if (calViewMonth<0){calViewMonth=11;calViewYear--;} renderCalendar(); }
function calNext() { calViewMonth++; if (calViewMonth>11){calViewMonth=0;calViewYear++;} renderCalendar(); }
const CAL_MEALS = ['朝食','昼食','夕食'];
function renderCalendar() {
  const y=calViewYear, m=calViewMonth, fd=new Date(y,m,1).getDay(), dim=new Date(y,m+1,0).getDate(), tod=toDateStr(new Date());
  document.getElementById('calMonth').textContent = `${y}年${m+1}月`;
  let html = '';
  ['日','月','火','水','木','金','土'].forEach(d => { html += `<div class="cal-dow">${d}</div>`; });
  for (let i=0; i<fd; i++) { const dd=new Date(y,m,-(fd-1-i)); html += `<div class="cal-day other-month"><div class="cal-num">${dd.getDate()}</div></div>`; }
  for (let d=1; d<=dim; d++) {
    const ds=`${y}-${String(m+1).padStart(2,'0')}-${String(d).padStart(2,'0')}`;
    const de=getDayEntries(ds), ms=CAL_MEALS.map(m=>de.some(e=>e.meal===m)), cnt=ms.filter(Boolean).length;
    const sel=ds===currentDate, t=ds===tod;
    const fill=cnt>0?`<div class="cal-fill" style="height:${Math.round(cnt/3*100)}%;background:#3266ad;opacity:.2"></div>`:'';
    const dots=`<div class="cal-dots">${ms.map((f,i)=>`<div class="cal-dot${f?' filled':''}" title="${CAL_MEALS[i]}"></div>`).join('')}</div>`;
    html += `<div class="cal-day${sel?' selected':''}${t?' today-day':''}" onclick="jumpToDate('${ds}')">${fill}<div class="cal-num">${d}</div>${dots}</div>`;
  }
  document.getElementById('calGrid').innerHTML = html;
}

// ── 実質栄養価計算 ──
// 食物繊維NET補正: 食物繊維は消化吸収されないため実質カロリー = fiber * 2kcal/g（大腸発酵分）として扱い
//                  通常計算されている炭水化物 * 4kcal から fiber * 4kcal を引いて fiber * 2kcal を足す
//                  → 実質 fiber * 2kcal の節約
const FIBER_NET_KCAL_PER_G = 2;   // 食物繊維1gあたりの補正（成分表では炭水化物として4kcal/gで計算されているが、実際は約2kcal/gとして差し引く）
function calcNetCalories(s) {
  // 食物繊維NETカロリー補正
  // 食物繊維は不溶性は0kcal、可溶性は約2kcal/gで大腸で発酵
  // 標準成分表では炭水化物に含めて4kcal/gで計算されているため差分を補正
  const fiberAdj = (s.fiber || 0) * FIBER_NET_KCAL_PER_G; // 4kcal→2kcalへの補正分（差引き2kcal節約/g）

  const grossCal  = s.cal;
  const netCal    = Math.round(grossCal - fiberAdj);
  const reduction = Math.round(fiberAdj);

  return {
    grossCal,
    netCal,
    fiberAdj: Math.round(fiberAdj),
    reduction,
  };
}

function renderNetCard(s) {
  const badge = document.getElementById('netCalBadge');
  const card  = document.getElementById('netCard');
  if (!card) return;

  if (s.cal <= 0) {
    if (badge) badge.textContent = '';
    card.innerHTML = '';
    return;
  }

  const n = calcNetCalories(s);
  if (badge) badge.textContent = `→ 実質 ${n.netCal} kcal`;

  card.innerHTML = `
    <div class="card" style="padding:10px 12px;font-size:12px">
      <div style="display:flex;align-items:baseline;gap:8px;margin-bottom:8px;flex-wrap:wrap">
        <span style="color:var(--text-sub)">表示カロリー</span>
        <span style="font-size:16px;font-weight:700">${n.grossCal}</span>
        <span style="color:var(--text-sub)">kcal</span>
        <span style="color:var(--text-sub)">→</span>
        <span style="color:var(--text-sub)">実質カロリー</span>
        <span style="font-size:20px;font-weight:700;color:var(--accent)">${n.netCal}</span>
        <span style="color:var(--text-sub)">kcal</span>
        <span style="background:#e8f5e9;color:#2e7d32;border-radius:6px;padding:2px 7px;font-size:11px;font-weight:600">▼ ${n.reduction} kcal 節約</span>
      </div>
      <div style="background:var(--bg);border-radius:8px;padding:7px 10px;margin-bottom:8px;max-width:220px">
        <div style="color:var(--text-sub);font-size:10px;margin-bottom:3px">食物繊維NET補正</div>
        <div style="font-weight:700;font-size:14px">▼ ${n.fiberAdj} kcal</div>
        <div style="font-size:10px;color:var(--text-sub);margin-top:3px;line-height:1.6">
          繊維 ${r1(s.fiber||0)}g × 2 kcal節約/g
        </div>
      </div>
      <div style="font-size:10px;color:var(--text-sub);line-height:1.6;border-top:1px solid var(--border);padding-top:6px">
        食物繊維は腸内発酵で約2kcal/g（表示値4kcal/gとの差を補正）。あくまで推定値です。
      </div>
    </div>`;
}


// ── Toast & Ripple ──
function showToast(msg, duration = 2000) {
  let el = document.getElementById('toast');
  if (!el) { el = document.createElement('div'); el.id = 'toast'; document.body.appendChild(el); }
  el.classList.remove('toast-action');
  el.textContent = msg;
  el.classList.add('show');
  clearTimeout(el._timer);
  el._timer = setTimeout(() => el.classList.remove('show'), duration);
}
// 削除操作など、取り消し可能にしたい通知用（「元に戻す」ボタン付き）
function showActionToast(msg, actions, duration = 6000) {   // actions: [{label, fn}]。「元に戻す」のボタンには toast-undo-btn を付ける
  let el = document.getElementById('toast');
  if (!el) { el = document.createElement('div'); el.id = 'toast'; document.body.appendChild(el); }
  clearTimeout(el._timer);
  el.innerHTML = `<span>${msg}</span>` + actions.map((a, i) => `<button type="button" class="${a.label === '元に戻す' ? 'toast-undo-btn' : 'toast-act-btn'}" data-i="${i}">${a.label}</button>`).join('');
  el.classList.add('show', 'toast-action');
  const finish = () => { el.classList.remove('show', 'toast-action'); };
  el.querySelectorAll('button').forEach(btn => { btn.onclick = ev => { ev.stopPropagation(); clearTimeout(el._timer); finish(); actions[Number(btn.dataset.i)].fn(); }; });
  el._timer = setTimeout(finish, duration);
}
function showUndoToast(msg, onUndo, duration = 5000) { showActionToast(msg, [{ label: '元に戻す', fn: onUndo }], duration); }
document.addEventListener('click', e => {
  const btn = e.target.closest('.btn, .meal-add-btn, .nav-btn, .seasoning-btn, .toggle-btn, .period-tab, .chart-tab, .ri');
  if (!btn) return;
  const ripple = document.createElement('span');
  ripple.className = 'ripple';
  const rect = btn.getBoundingClientRect();
  const size = Math.max(rect.width, rect.height) * 2;
  ripple.style.cssText = `width:${size}px;height:${size}px;left:${e.clientX-rect.left-size/2}px;top:${e.clientY-rect.top-size/2}px`;
  btn.appendChild(ripple);
  setTimeout(() => ripple.remove(), 600);
}, true);

// ── Record ──
// ── 記録の異常値チェック（1日を見返す際にまとめて表示） ──
function levenshtein(a, b) {
  const dp = [];
  for (let i = 0; i <= a.length; i++) dp.push([i]);
  for (let j = 1; j <= b.length; j++) dp[0][j] = j;
  for (let i = 1; i <= a.length; i++) {
    for (let j = 1; j <= b.length; j++) {
      dp[i][j] = a[i-1] === b[j-1] ? dp[i-1][j-1] : 1 + Math.min(dp[i-1][j-1], dp[i-1][j], dp[i][j-1]);
    }
  }
  return dp[a.length][b.length];
}

function detectAnomalies(date) {
  const list = getDayEntries(date);
  const issues = [];

  list.forEach(e => {
    const amt = e.amount || 0;
    const cal = e.cal || 0;
    if (amt <= 0) {
      issues.push({ sev: 'high', msg: `「${e.name}」の量が0以下になっています` });
      return;
    }
    // 物理的に不可能なカロリー密度（純脂質でも約9kcal/g）
    const density = cal / amt;
    if (density > 9.5) {
      issues.push({ sev: 'high', msg: `「${e.name}」: ${r1(amt)}gで${ri(cal)}kcalは密度が高すぎます（${density.toFixed(1)}kcal/g）。桁や単位の入力ミスの可能性があります` });
    }
    // カロリーとPFCから逆算した値の整合性
    // ※ P/F/Cだけで説明しきれない分（記録カロリー > 計算値）はアルコール・糖アルコール・
    //    有機酸など正当な理由がありうるため許容する。逆に計算値が記録カロリーを大きく超える
    //    のは物理的にありえない（入力ミスの可能性が高い）ため、その方向のみ検出する。
    // ※ 野菜など低カロリー食品は、成分表の丸め等による数kcalの差でも%では大きく出てしまうため、
    //    相対的な閾値（15%超）に加えて絶対値の閾値（20kcal超）も満たす場合のみ検出する。
    // ※ 食物繊維は炭水化物(c)の内数だが、単純に4kcal/gでは計算しない（日本食品標準成分表の
    //    八訂以降のエネルギー算出も同様の考え方）。海藻・きのこ・ふすま等、食物繊維が多い食品では
    //    炭水化物を4kcal/gそのまま使うと実際のカロリーを大きく超えてしまい、正しい値でも
    //    「入力ミスの可能性」と誤検出してしまうため、炭水化物から食物繊維分を除いてから計算する
    const calcCal = (e.p||0)*4 + (e.f||0)*9 + Math.max(0, (e.c||0) - (e.fiber||0))*4;
    if (cal > 50 && calcCal > cal * 1.15 && (calcCal - cal) > 20) {
      issues.push({ sev: 'mid', msg: `「${e.name}」: P・F・Cから計算した値(${ri(calcCal)}kcal)が記録カロリー(${ri(cal)}kcal)を超えています。数値の入力ミスの可能性があります` });
    }
    // 単品として極端な量
    if (cal > 2500) issues.push({ sev: 'mid', msg: `「${e.name}」が${ri(cal)}kcalと、1品にしては非常に多い量です` });
    if ((e.p||0) > 150) issues.push({ sev: 'mid', msg: `「${e.name}」のタンパク質が${r1(e.p)}gと非常に多い量です` });
    if ((e.salt||0) > 15) issues.push({ sev: 'mid', msg: `「${e.name}」の食塩相当量が${r1(e.salt)}gと非常に多い量です` });
  });

  // 同じ食事内で、名前が酷似した別記録（合算されなかった重複の可能性）
  const mealGroups = {};
  list.forEach(e => { (mealGroups[e.meal] = mealGroups[e.meal] || []).push(e); });
  Object.values(mealGroups).forEach(group => {
    for (let i = 0; i < group.length; i++) {
      for (let j = i+1; j < group.length; j++) {
        const a = normFoodName(group[i].name), b = normFoodName(group[j].name);
        if (!a || !b || a === b) continue;
        const longer = Math.max(a.length, b.length);
        if (longer < 3) continue;
        const similarity = 1 - levenshtein(a, b) / longer;
        const isSubstr = a.includes(b) || b.includes(a);
        if (similarity > 0.7 || isSubstr) {
          issues.push({ sev: 'low', msg: `「${group[i].name}」と「${group[j].name}」は似た名前で別々に記録されています（重複の可能性）` });
        }
      }
    }
  });

  return issues;
}

function renderAnomalyCard(date) {
  const el = document.getElementById('anomalyCard');
  if (!el) return;
  const issues = detectAnomalies(date);
  if (!issues.length) { el.innerHTML = ''; return; }
  const sevOrder = { high: 0, mid: 1, low: 2 };
  issues.sort((a, b) => sevOrder[a.sev] - sevOrder[b.sev]);
  const sevIcon = { high: '🔴', mid: '🟠', low: '🟡' };
  el.innerHTML = `
    <div class="card" style="padding:11px 13px;margin-bottom:8px;border:1.5px solid #f0ad4e55;background:linear-gradient(135deg,#fff8ec,#fffdf9)">
      <div style="display:flex;align-items:center;gap:6px;margin-bottom:8px;font-weight:700;font-size:13px;color:#a06a1a">
        ⚠️ 記録の確認事項（${issues.length}件）
      </div>
      <div style="display:flex;flex-direction:column;gap:6px">
        ${issues.map(i => `
          <div style="display:flex;gap:6px;align-items:flex-start;font-size:12px;line-height:1.5;color:#4b3a1a">
            <span>${sevIcon[i.sev]}</span><span style="flex:1">${i.msg}</span>
          </div>`).join('')}
      </div>
    </div>`;
}

function setDailySteps(date, val) {
  const steps = parseFloat(val) || 0;
  dailyActivity[date] = { ...(dailyActivity[date]||{}), steps };
  saveDailyActivity();
  renderRecord();
  renderBmrPreview();
}
let activityCardExpanded = false;
function toggleActivityCard() {
  activityCardExpanded = !activityCardExpanded;
  renderActivityCard();
}
function renderActivityCard() {
  const el = document.getElementById('activityCard');
  if (!el) return;
  const gh = ghData[currentDate];
  const neatLabel = getNeatLabel();
  const manualSteps = (dailyActivity[currentDate] && dailyActivity[currentDate].steps) || '';

  const summaryParts = [];
  if (gh && gh.activeCalories > 0) summaryParts.push(`Google Health実測 ${(gh.steps||0).toLocaleString()}歩`);
  else if (manualSteps) summaryParts.push(`歩数 ${manualSteps}歩`);
  else summaryParts.push('歩数未入力');

  const headerRow = `
    <div style="display:flex;justify-content:space-between;align-items:center;cursor:pointer" onclick="toggleActivityCard()">
      <div style="font-size:12px;font-weight:700">🚶 本日の活動量</div>
      <div style="display:flex;align-items:center;gap:6px">
        <span style="font-size:10px;color:var(--text-sub)">${summaryParts.join(' ・ ')}</span>
        <span style="font-size:11px;color:var(--text-sub)">${activityCardExpanded ? '▲' : '▼'}</span>
      </div>
    </div>`;

  if (!activityCardExpanded) {
    el.innerHTML = `<div class="card" style="padding:9px 13px;margin-bottom:8px">${headerRow}</div>`;
    return;
  }

  if (gh && gh.activeCalories > 0) {
    // Garmin/Google Health連携で実測データがある日はそちらを優先表示（編集不可）
    el.innerHTML = `
      <div class="card" style="padding:10px 13px;margin-bottom:8px">
        ${headerRow}
        <div style="display:flex;justify-content:flex-end;margin-top:2px">
          <span style="font-size:10px;color:var(--green);font-weight:600">✓ 連携中</span>
        </div>
        <div style="font-size:11px;color:var(--text-sub);margin-top:4px">
          歩数 ${(gh.steps||0).toLocaleString()}歩　活動カロリー ${gh.activeCalories}kcal　NEAT「${neatLabel}」を適用
        </div>
      </div>`;
    return;
  }

  el.innerHTML = `
    <div class="card" style="padding:10px 13px;margin-bottom:8px">
      ${headerRow}
      <div class="row" style="align-items:flex-end;gap:8px;margin-top:8px">
        <div class="field" style="flex:1"><label>歩数</label><input type="number" min="0" step="100" placeholder="例: 8000" value="${manualSteps}" onchange="setDailySteps('${currentDate}', this.value)"></div>
        <div style="font-size:10px;color:var(--text-sub);padding-bottom:9px;flex:1.4">NEAT「${neatLabel}」で計算（設定タブで変更可）</div>
      </div>
      <div style="font-size:10px;color:var(--text-sub);margin-top:6px">
        Garmin/Google Health連携が無い日でも、歩数を入れるだけでその日のTDEEがより正確になります。未入力の場合は活動係数（ざっくり設定）が使われます。
      </div>
    </div>`;
}

// 検索欄へのフォーカスは「＋追加」を押して開いた直後の1回だけ行う。
// 以前は、追加パネルが開いている間、再描画のたびに検索欄へフォーカスしていた（記録の追加・量の変更・複製・削除・
// スワイプ・タブ切替・クラウド読み込み・Google Health同期などあらゆる再描画で、キーボードと「最近使った食品」が勝手に出ていた）。
let _focusAddSearchMeal = null;   // 「＋追加」で開いた食事。描画後に1回だけフォーカスして消す
function captureAddSearchState() {  // 再描画前の検索欄の状態（入力途中の文字・フォーカス）を覚えておく
  if (!activeAddMeal) return null;
  const el = document.getElementById('addSearch_' + activeAddMeal); if (!el) return null;
  return { meal: activeAddMeal, value: el.value, focused: document.activeElement === el, start: el.selectionStart, end: el.selectionEnd };
}
function restoreAddSearchAfterRender(before) {
  const meal = activeAddMeal; if (!meal) { _focusAddSearchMeal = null; return; }
  const el = document.getElementById('addSearch_' + meal); if (!el) return;
  const recordVisible = !!(document.getElementById('panel-record') && document.getElementById('panel-record').classList.contains('active'));
  // ① 入力途中の文字は、フォーカスの有無にかかわらず残す（再描画で消えない）。入力済みなら候補も復元する
  if (before && before.meal === meal && before.value) { el.value = before.value; if (typeof onAddSearch === 'function') onAddSearch(before.value, meal); }
  // ② フォーカス: 開いた直後の1回、または再描画の直前に検索欄を操作していたとき（入力を続けられるように）だけ。他の入力欄・数量シートを操作中は奪わない
  const wantOpenFocus = _focusAddSearchMeal === meal, wantKeep = !!(before && before.meal === meal && before.focused);
  _focusAddSearchMeal = null;
  if (!recordVisible || !(wantOpenFocus || wantKeep)) return;
  setTimeout(() => {
    const cur = document.getElementById('addSearch_' + meal); if (!cur || activeAddMeal !== meal) return;
    const ae = document.activeElement, other = ae && ae !== cur && /^(INPUT|TEXTAREA|SELECT)$/.test(ae.tagName) && ae.type !== 'checkbox';
    if (other || (typeof AS !== 'undefined' && AS.open)) return;
    cur.focus();
    if (wantKeep && before.start != null) { try { cur.setSelectionRange(before.start, before.end); } catch (e) {} }
  }, 30);
}
function renderRecord() {
  const searchBefore = captureAddSearchState();
  const list = getDayEntries(currentDate);
  const s = sumEntries(list);
  const g = goals();
  const exToday = exercises.filter(e => e.date === currentDate);
  const exCal = exToday.reduce((a, e) => a + (e.cal || 0), 0);
  const remain = g.cal - s.cal + exCal;
  const remainColor = remain >= 0 ? 'var(--accent)' : '#c0392b';

  // ── タンパク質吸収補正 ──
  const absP = r1(calcAbsorbedProtein(list));

  // ── 活動量（歩数・NEAT） ──
  renderActivityCard();

  // ── 異常値チェック ──
  renderAnomalyCard(currentDate);

  // ── 実質栄養価 ──
  renderNetCard(s);
  // ── 脂肪酸プロファイル ──
  renderFattyAcidPanel(list);

  // ── エネルギー収支カード ──
  document.getElementById('balanceCard').innerHTML = `
    <div class="card" style="padding:10px 12px;margin-bottom:8px">
      <div style="display:flex;align-items:center;gap:0;margin-bottom:7px">
        <div style="flex:1;min-width:0">
          <div style="font-size:10px;color:var(--text-sub)">摂取</div>
          <div style="font-size:20px;font-weight:700;letter-spacing:-.5px">${ri(s.cal)}<span style="font-size:11px;font-weight:400;color:var(--text-sub);margin-left:2px">kcal</span></div>
        </div>
        ${exCal > 0 ? `<div style="font-size:11px;color:var(--text-sub);padding:0 6px">+🏃${ri(exCal)}</div>` : ''}
        <div style="font-size:18px;color:var(--text-sub);padding:0 6px">/</div>
        <div style="flex:1;min-width:0;text-align:right">
          <div style="font-size:10px;color:var(--text-sub)">${profile.goalMode === 'custom' ? '目標' : '維持カロリー'}</div>
          <div style="font-size:20px;font-weight:700;letter-spacing:-.5px">${ri(g.cal)}<span style="font-size:11px;font-weight:400;color:var(--text-sub);margin-left:2px">kcal</span></div>
        </div>
        <div style="padding-left:10px;text-align:right;min-width:64px">
          <div style="font-size:10px;color:var(--text-sub)">${remain >= 0 ? 'あと' : '超過'}</div>
          <div style="font-size:18px;font-weight:700;color:${remainColor};letter-spacing:-.5px">${ri(Math.abs(remain))}<span style="font-size:10px;font-weight:400;margin-left:1px">kcal</span></div>
        </div>
      </div>
      <div style="height:6px;border-radius:3px;background:var(--border);overflow:hidden">
        <div style="height:100%;border-radius:3px;background:${s.cal > g.cal ? 'var(--red)' : 'var(--accent)'};width:${Math.min((s.cal+exCal)/g.cal*100,100).toFixed(1)}%;transition:width .4s cubic-bezier(.4,0,.2,1)"></div>
      </div>
    </div>`;

  // ── エネルギー内訳 ──
  const tb = getTdeeBreakdown();
  const bmr_disp = ri(tb.bmr);
  const actDetail = tb.detail;
  const bmrFormulaDesc = usingKatchFallback()
    ? 'Mifflin-St Jeor式・体脂肪率未設定のためKatch-McArdleから自動フォールバック'
    : (profile.bmrFormula === 'katch' ? 'Katch-McArdle式（除脂肪体重ベース）' : 'Mifflin-St Jeor式');
  const actDesc = `× ${describeActivity(tb)}`;
  const pCalPct = s.cal > 0 ? ri(s.p*4/s.cal*100) : 0;
  const fCalPct = s.cal > 0 ? ri(s.f*9/s.cal*100) : 0;
  const cCalPct = s.cal > 0 ? ri(s.c*4/s.cal*100) : 0;
  document.getElementById('energyBreakdown').innerHTML = `
    <div style="font-size:11px;color:var(--text-sub);margin-bottom:6px">
      推定TDEE ${ri(tb.tdee)} kcal（BMR ${bmr_disp} kcal・${bmrFormulaDesc} ${actDesc}）
    </div>
    <div style="display:grid;grid-template-columns:1fr 1fr 1fr;gap:6px;text-align:center">
      <div style="background:#e3f0ff;border-radius:8px;padding:7px 4px">
        <div style="font-size:10px;color:#3266ad;font-weight:600">タンパク質</div>
        <div style="font-weight:700;color:#1a1d23">${r1(s.p)}g</div>
        <div style="font-size:10px;color:#2a6f4f;font-weight:600">吸収量 ${absP}g</div>
        <div style="font-size:10px;color:#4b5568">${ri(s.p*4)} kcal (${pCalPct}%)</div>
        <div style="font-size:10px;color:#4b5568">目標 ${g.p}g</div>
      </div>
      <div style="background:#fff3e0;border-radius:8px;padding:7px 4px">
        <div style="font-size:10px;color:#a06a1a;font-weight:600">脂質</div>
        <div style="font-weight:700;color:#1a1d23">${r1(s.f)}g</div>
        <div style="font-size:10px;color:#4b5568">${ri(s.f*9)} kcal (${fCalPct}%)</div>
        <div style="font-size:10px;color:#4b5568">目標 ${g.f}g</div>
      </div>
      <div style="background:#e8f5e9;border-radius:8px;padding:7px 4px">
        <div style="font-size:10px;color:#2f7d3a;font-weight:600">炭水化物</div>
        <div style="font-weight:700;color:#1a1d23">${r1(s.c)}g</div>
        <div style="font-size:10px;color:#4b5568">${ri(s.c*4)} kcal (${cCalPct}%)</div>
        <div style="font-size:10px;color:#4b5568">目標 ${g.c}g</div>
      </div>
    </div>`;

  document.getElementById('recMetrics').innerHTML = `
    <div class="mc"><div class="mc-label">カロリー</div><div class="mc-value">${ri(s.cal)}</div><div class="mc-unit">kcal</div></div>
    <div class="mc" style="position:relative"><div class="mc-label">タンパク質</div><div class="mc-value">${r1(s.p)}</div><div class="mc-unit">g</div><div style="font-size:9px;color:var(--accent);font-weight:600;margin-top:1px">吸収 ${absP}g</div></div>
    <div class="mc"><div class="mc-label">脂質</div><div class="mc-value">${r1(s.f)}</div><div class="mc-unit">g</div></div>
    <div class="mc"><div class="mc-label">炭水化物</div><div class="mc-value">${r1(s.c)}</div><div class="mc-unit">g</div></div>`;
  const pcal=s.p*4, fcal=s.f*9, ccal=s.c*4, tot=pcal+fcal+ccal||1;
  document.getElementById('recBarP').style.width=(pcal/tot*100)+'%';
  document.getElementById('recBarF').style.width=(fcal/tot*100)+'%';
  document.getElementById('recBarC').style.width=(ccal/tot*100)+'%';

  let microHtml = '';
  MICRO_GOAL_KEYS.forEach(k => {
    const g=MICRO_GOALS[k], val=r1(s[k]||0);
    const pct=Math.min(val/g.goal*100,100);
    const over=!g.reverse&&val>g.goal;
    const color=g.reverse?(val>g.goal?'#c0392b':g.color):(over?'#c0392b':g.color);
    let barHtml = `<div class="micro-bar-fill" style="width:${pct}%;background:${color}"></div>`;
    let subHtml = '';
    if (k === 'fiber' && val > 0 && ((s.fibS||0) + (s.fibI||0) + (s.fibU||0)) > 0) {
      // 食物繊維は水溶性/不溶性/区分不明で色分けしたバーにし、内訳を数値でも添える
      const tot = (s.fibS||0) + (s.fibI||0) + (s.fibU||0), scale = Math.min(pct, 100) / tot;
      const seg = (v, col) => `<div style="width:${v*scale}%;background:${col};height:100%"></div>`;
      barHtml = `<div style="display:flex;height:100%;width:100%">${seg(s.fibS||0,'#4fc3f7')}${seg(s.fibI||0,color)}${seg(s.fibU||0,'#bdbdbd')}</div>`;
      subHtml = `<div style="font-size:9px;color:var(--text-sub);margin-top:2px;line-height:1.35">水溶${r1(s.fibS||0)} / 不溶${r1(s.fibI||0)}${(s.fibU||0) > 0.04 ? ' / 不明'+r1(s.fibU) : ''}</div>`;
    }
    microHtml += `<div class="micro-item"><div class="micro-label">${g.label}</div>
      <div class="micro-bar-track">${barHtml}</div>
      <div class="micro-val">${val}<span class="micro-unit"> ${g.unit}/${g.goal}</span></div>${subHtml}</div>`;
  });
  document.getElementById('microGrid').innerHTML = microHtml;

  const grouped = {}; MEALS_ORDER.forEach(m=>{grouped[m]=[]});
  list.forEach(e=>{(grouped[e.meal]||grouped['間食']).push(e)});
  let html = '';
  MEALS_ORDER.forEach(meal => {
    const items=grouped[meal]||[], ms=sumEntries(items), meta=MEAL_META[meal], isAdding=activeAddMeal===meal;
    html += `<div class="meal-block"><div class="meal-block-header">
      <div class="meal-block-left">
        <div class="meal-icon" style="background:${meta.bg}">${meta.icon}</div>
        <div><div class="meal-name">${meal}</div><div class="meal-sub">${items.length?ri(ms.cal)+' kcal / P'+r1(ms.p)+' F'+r1(ms.f)+' C'+r1(ms.c):'未記録'}</div></div>
      </div>
      <button class="meal-add-btn${isAdding?' active-add':''}" onclick="toggleAddPanel('${meal}')">${isAdding?'✕ 閉じる':'＋ 追加'}</button>
    </div>`;
    if (items.length) {
      html += `<div style="display:flex;align-items:center;gap:6px;padding:0 12px 8px;font-size:11px">
        <span style="color:var(--text-sub)">⏱ 摂取時刻を一括設定</span>
        <input type="time" id="mealTimeSet_${meal}" style="padding:3px 6px;font-size:11px;border:1px solid var(--border);border-radius:6px;background:var(--surface);color:var(--text)">
        <button type="button" class="btn btn-sm" style="padding:3px 10px;font-size:11px" onclick="setMealTime('${meal}', document.getElementById('mealTimeSet_${meal}').value)">反映</button>
      </div>`;
      html += `<div class="meal-items">`;
      items.forEach(e => {
        if (editingId === e.id) {
          // 編集フォーム用に100g基準値をstoreする
          window._editBase = window._editBase || {};
          window._editBase[e.id] = {cal:e.cal,p:e.p,f:e.f,c:e.c,fiber:e.fiber||0,fibS:fibSInputVal(e),iron:e.iron||0,calcium:e.calcium||0,vitc:e.vitc||0,vitd:e.vitd||0,salt:e.salt||0,per:e.amount,
            ingredients: (e.ingredients||[]).map(ing=>({...ing}))};
          html += `<div class="edit-form" id="editForm_${e.id}">
            <div class="row" style="margin-bottom:5px"><div class="field" style="flex:3"><label>食品名</label><input type="text" id="en${e.id}" value="${e.name}" onchange="autoSaveEdit(${e.id})"></div><div class="field" style="flex:1.2"><label>量(g)</label><input type="number" id="ea${e.id}" value="${e.amount}" min="0.1" step="0.1" oninput="recalcEdit(${e.id})"></div></div>
            ${e.ingredients && e.ingredients.length ? `<div style="margin-bottom:8px">
              <div style="font-size:11px;color:var(--text-sub);margin-bottom:4px">構成食品の分量</div>
              ${e.ingredients.map((ing,idx)=>`<div class="combo-ingredient"><span style="font-weight:500;flex:1;overflow:hidden;text-overflow:ellipsis;white-space:nowrap">${ing.name}</span><input type="number" id="eIng${e.id}_${idx}" value="${ing.amount}" min="0" step="1" inputmode="decimal" style="width:50px;font-size:12px;padding:2px 5px;border:1px solid var(--border);border-radius:7px;background:var(--surface);color:var(--text);margin:0 6px" oninput="updateEditIngredientAmt(${e.id},${idx},this.value)"><span style="font-size:10px;color:var(--text-sub)">g</span></div>`).join('')}
              <div id="editIngTotal${e.id}" style="font-size:11px;color:var(--text-sub);margin-top:2px">合計 ${ri(e.cal)}kcal P${r1(e.p)} F${r1(e.f)} C${r1(e.c)}${e.fiber?' 繊'+r1(e.fiber)+'g':''}</div>
            </div>` : ''}
            <div class="row" style="margin-bottom:8px;gap:4px">
              <button class="btn btn-primary btn-sm" onclick="saveEdit(${e.id})" style="flex:1;height:32px">保存</button>
              <button class="btn btn-sm" onclick="cancelEdit(${e.id})" style="flex:1;height:32px">取消</button>
            </div>
            <div class="row" style="margin-bottom:8px;gap:4px">
              <button type="button" class="btn btn-sm" onclick="duplicateEntry(${e.id})" style="flex:1;height:32px">複製</button>
              <button type="button" class="btn btn-sm btn-danger" onclick="deleteEntry(${e.id})" style="flex:1;height:32px">削除</button>
            </div>
            <div class="row" style="margin-bottom:6px"><button type="button" class="btn btn-sm" style="flex:1;height:40px;font-size:13px" onclick="openAmountSheetForEntry(${e.id})">📏 量を変更（倍率・単位・数字キー）</button></div>
            <div class="row" style="margin-bottom:5px;gap:8px;align-items:center">
              <div class="field" style="flex:1"><label>目標カロリーで調整（PFC比を維持）</label><input type="number" placeholder="例: 100" step="1" onchange="recalcEditByCal(${e.id}, this.value)"></div>
            </div>
            <div class="row" style="margin-bottom:5px"><div class="field"><label>kcal</label><input type="number" id="ec${e.id}" value="${r1(e.cal)}" step="0.1" onchange="autoSaveEdit(${e.id})"></div><div class="field"><label>P</label><input type="number" id="ep${e.id}" value="${r1(e.p)}" step="0.1" onchange="autoSaveEdit(${e.id})"></div><div class="field"><label>F</label><input type="number" id="ef${e.id}" value="${r1(e.f)}" step="0.1" onchange="autoSaveEdit(${e.id})"></div><div class="field"><label>C</label><input type="number" id="ecc${e.id}" value="${r1(e.c)}" step="0.1" onchange="autoSaveEdit(${e.id})"></div></div>
            <div class="row" style="margin-bottom:5px"><div class="field"><label>食物繊維</label><input type="number" id="efib${e.id}" value="${r1(e.fiber||0)}" step="0.1" data-prev="${r1(e.fiber||0)}" onchange="fiberEdited(${e.id})"></div><div class="field"><label>うち水溶性</label><input type="number" id="efibs${e.id}" value="${fibSInputVal(e)}" placeholder="自動" step="0.1" onchange="autoSaveEdit(${e.id})"></div><div class="field"><label>鉄(mg)</label><input type="number" id="efe${e.id}" value="${r1(e.iron||0)}" step="0.1" onchange="autoSaveEdit(${e.id})"></div><div class="field"><label>Ca(mg)</label><input type="number" id="eca${e.id}" value="${r1(e.calcium||0)}" step="0.1" onchange="autoSaveEdit(${e.id})"></div></div>
            <div class="row" style="margin-bottom:5px"><div class="field"><label>VitC</label><input type="number" id="evc${e.id}" value="${r1(e.vitc||0)}" step="0.1" onchange="autoSaveEdit(${e.id})"></div><div class="field"><label>VitD</label><input type="number" id="evd${e.id}" value="${r1(e.vitd||0)}" step="0.1" onchange="autoSaveEdit(${e.id})"></div><div class="field"><label>塩分</label><input type="number" id="esl${e.id}" value="${r2(e.salt||0)}" step="0.01" onchange="autoSaveEdit(${e.id})"></div></div>
            <div class="row" style="margin-bottom:0"><div class="field"><label>タイミング</label><select id="em${e.id}" onchange="autoSaveEdit(${e.id})">${MEALS_ORDER.map(m=>`<option${e.meal===m?' selected':''}>${m}</option>`).join('')}</select></div><div class="field" style="flex:1"><label>摂取時刻</label><input type="time" id="et${e.id}" value="${e.time||''}" onchange="autoSaveEdit(${e.id})"></div>
            <button class="btn btn-primary btn-sm" onclick="saveEdit(${e.id})" style="height:32px;margin-top:auto">保存</button>
            <button class="btn btn-sm" onclick="cancelEdit(${e.id})" style="height:32px;margin-top:auto">取消</button></div>
          </div>`;
        } else {
          const isGrp = Array.isArray(e.ingredients) && e.ingredients.length > 1, open = isGrp && _grpOpen.has(e.id);
          html += `<div class="log-item${isGrp ? ' grp' : ''}" data-eid="${e.id}"><div${isGrp ? ` onclick="toggleGroupOpen(${e.id})" style="cursor:pointer"` : ''}><div class="li-name">${isGrp ? '🗂 ' : ''}${fdEsc(e.name)}${isGrp ? ` <span class="fd-badge">${e.ingredients.length}品 ${open ? '▾' : '▸'}</span>` : ''}</div><div class="li-detail"><span class="amt-pill" onclick="event.stopPropagation();openAmountSheetForEntry(${e.id})" role="button" aria-label="量を変更">${fmtAmt(e.amount)}g</span>｜P${r1(e.p)} F${r1(e.f)} C${r1(e.c)}${e.fiber?'｜繊'+r1(e.fiber):''}${e.vitd?'｜D'+r1(e.vitd)+'μg':''}</div></div>
          <div class="li-right"><div class="li-cal">${ri(e.cal)}</div>
          <button class="btn btn-sm btn-ghost li-edit" onclick="startEdit(${e.id})" aria-label="編集">✏️</button></div>${open ? groupMembersHtml(e) : ''}
          <div class="sw-actions"><button type="button" class="btn btn-sm" onclick="duplicateEntry(${e.id})">複製</button><button type="button" class="btn btn-sm btn-danger" onclick="deleteEntry(${e.id})">削除</button></div></div>`;
        }
      });
      html += `</div>`;
    }
    if (isAdding) {
      html += `<div class="add-panel" id="addPanel_${meal}">
        <div style="display:flex;gap:6px;align-items:flex-start;margin-bottom:9px">
          <div class="search-wrap" style="flex:1;margin-bottom:0">
            <input type="text" id="addSearch_${meal}" placeholder="いわし、chicken, egg…" oninput="onAddSearch(this.value,'${meal}')" onfocus="onAddSearchFocus('${meal}')" autocomplete="off">
            <div class="search-icon-box" id="addSearchIcon_${meal}"><svg viewBox="0 0 16 16"><circle cx="6.5" cy="6.5" r="4"/><line x1="10" y1="10" x2="14" y2="14"/></svg></div>
          </div>
          <button type="button" class="btn btn-sm" onclick="toggleAddPanel('${meal}')" aria-label="閉じる" style="height:38px;padding:0 13px;flex-shrink:0">✕</button>
        </div>
        <div class="results-box" id="addResultsBox_${meal}"></div>
        <details style="margin-top:2px">
          <summary style="font-size:12px;color:var(--text-sub);cursor:pointer;padding:4px 0">見つからない場合は手入力で追加</summary>
          <div style="padding-top:8px">
            <div class="row" style="margin-bottom:6px"><div class="field" style="flex:3"><label>食品名（手入力）</label><input type="text" id="addName_${meal}" placeholder="食品名"></div><div class="field" style="flex:1.4"><label style="display:flex;align-items:center;justify-content:space-between">量 <span style="display:flex;gap:2px" id="unitToggle_${meal}"><button type="button" onclick="setAmtUnit('${meal}','g')" id="unitG_${meal}" style="font-size:9px;padding:1px 5px;border-radius:3px;border:1px solid var(--accent);background:var(--accent);color:#fff;cursor:pointer">g</button><button type="button" onclick="setAmtUnit('${meal}','serving')" id="unitS_${meal}" style="font-size:9px;padding:1px 5px;border-radius:3px;border:1px solid var(--border);background:var(--bg);color:var(--text-sub);cursor:pointer">人前</button></span></label><input type="number" id="addAmt_${meal}" value="100" min="0.1" step="0.1" oninput="recalcAdd('${meal}')" style="width:100%"></div></div>
            <div id="amtQuickPick_${meal}" style="display:none;flex-wrap:wrap;gap:4px;margin-bottom:6px"></div>
            <div class="macro-row">
              <div class="field"><label>kcal</label><input type="number" id="addCal_${meal}" placeholder="0" step="0.1"></div>
              <div class="field"><label>P(g)</label><input type="number" id="addP_${meal}" placeholder="0" step="0.1"></div>
              <div class="field"><label>F(g)</label><input type="number" id="addF_${meal}" placeholder="0" step="0.1"></div>
              <div class="field"><label>C(g)</label><input type="number" id="addC_${meal}" placeholder="0" step="0.1"></div>
            </div>
            <div class="macro-row">
              <div class="field"><label>食物繊維(g)</label><input type="number" id="addFib_${meal}" placeholder="0" step="0.1"></div>
              <div class="field"><label>うち水溶性(g)</label><input type="number" id="addFibS_${meal}" placeholder="自動" step="0.1"></div>
              <div class="field"><label>鉄(mg)</label><input type="number" id="addFe_${meal}" placeholder="0" step="0.1"></div>
              <div class="field"><label>Ca(mg)</label><input type="number" id="addCa_${meal}" placeholder="0" step="0.1"></div>
              <div class="field"><label>VitC(mg)</label><input type="number" id="addVc_${meal}" placeholder="0" step="0.1"></div>
              <div class="field"><label>VitD(μg)</label><input type="number" id="addVd_${meal}" placeholder="0" step="0.1"></div>
              <div class="field"><label>塩分(g)</label><input type="number" id="addSalt_${meal}" placeholder="0" step="0.01"></div>
            </div>
            <button class="btn btn-primary btn-block" onclick="addEntry('${meal}')">追加する</button>
            <div id="addMsg_${meal}" class="status-msg"></div>
          </div>
        </details>
      </div>`;
    }
    html += `</div>`;
  });
  document.getElementById('mealBlocks').innerHTML = html;
  restoreAddSearchAfterRender(searchBefore);
  renderExerciseItems();
}

// ── Search ──
// 検索対象は 内蔵DB・カスタム食品・複合食品 のみ（外部の食品DB(Open Food Facts)は参照しない）
// クエリは「そのまま/ひらがな→カタカナ」と「ローマ字→カナ」の両方の解釈で照合し、良い方のスコアを採用する
function queryVariants(query) {
  const raw = String(query || '').toLowerCase().trim();
  const norm = normalize(raw);
  let roma = null, romaU = null, kana = null, kanaU = null;
  const k = romajiToKana(raw);
  if (k && k.replace(/ー/g, '').length >= 2) { roma = looseKana(k); romaU = looseKana(k, true); }
  // かな入力でも、長音・ウ/オ・濁点の表記ゆれ（とうふ/トーフ、やきざかな/ヤキサカナ）は吸収して当てる
  if (/^[\u30A1-\u30FA\u30FC]{2,}$/.test(norm)) { kana = looseKana(norm); kanaU = looseKana(norm, true); }
  return { raw, norm, roma, romaU, kana, kanaU };
}
// 読み(_kana/_kanaU)との照合。読みの先頭一致 > 読み内の語頭一致 > 部分一致。濁点まで無視した一致は低めに評価
function kanaTier(kn, q, hi, mid, lo) {
  if (!q || !kn) return 0;
  if (kn.startsWith(q)) return hi;
  if (kn.split(' ').some(t => t.startsWith(q))) return mid;
  return kn.includes(q) ? lo : 0;
}
function kanaScore(food, qv) {
  return Math.max(
    kanaTier(food._kana,  qv.roma,  95, 80, 72), kanaTier(food._kanaU, qv.romaU, 70, 62, 55),
    kanaTier(food._kana,  qv.kana,  66, 60, 58), kanaTier(food._kanaU, qv.kanaU, 50, 46, 42));
}
function searchScore(food, query, qv) {
  const q=query.toLowerCase().trim(); if(!q) return 0;
  qv = qv || queryVariants(q);
  const s=food._search||'', nameNorm=normalize(food.name), qNorm=qv.norm;
  let score = kanaScore(food, qv);
  if (nameNorm===qNorm||s.startsWith(qNorm)) return 100;
  if (nameNorm.includes(qNorm)) return Math.max(score, 90);
  if (s.includes(qNorm)) return Math.max(score, 70);
  const en=(food.en||'').toLowerCase();
  if (en===q) return Math.max(score, 85); if (en.startsWith(q)) return Math.max(score, 80); if (en.includes(q)) return Math.max(score, 65);
  if (score) return score;
  let qi=0; for(let i=0;i<s.length&&qi<qNorm.length;i++) if(s[i]===qNorm[qi]) qi++;
  if (qi===qNorm.length) return 30;
  return 0;
}
function localSearch(q) {
  if (!q.trim()) return [];
  const qv = queryVariants(q);
  return getAllFoods().map(f=>({...f,_score:searchScore(f,q,qv)})).filter(f=>f._score>0).sort((a,b)=>b._score-a._score).slice(0,9);
}

const SRC_LABEL = {local:'内蔵',custom:'カスタム',combo:'複合'};
function resultItemHtml(f, i, meal, qty) {
  const cat = (f._src === 'custom' || f._src === 'combo') && f.category ? ` ・${fdEsc(f.category)}` : '';
  const qa = qty ? resolveQtyAmount(f, qty) : null;   // 量を打っている場合は、その量でのkcalを右に出す
  return `<div class="ri" onclick="selectAddResult(${i},'${meal}')"><div><div class="ri-name">${fdEsc(f.name)}<span class="badge badge-${f._src||'local'}">${SRC_LABEL[f._src||'local']}</span></div><div class="ri-sub">${f.per}gあたり P${f.p} F${f.f} C${f.c}${f.fiber?' 繊'+f.fiber:''}${(f.aa&&f.aa.score!=null&&f.p>=3)?' <span style="color:var(--text-sub)">・P吸収スコア'+Math.round(f.aa.score*100)+'%</span>':''}${cat}</div></div><div class="ri-cal">${qa ? `<span class="ri-amt">${fdEsc(qa.label)}${qa.label.endsWith('g') ? '' : '＝' + fmtAmt(qa.amount) + 'g'}</span>${ri((f.cal || 0) * qa.amount / (f.per || 100))}kcal` : `${f.cal}kcal`}</div></div>`;
}
function renderResultsFor(local, meal, qty) {
  const box=document.getElementById('addResultsBox_'+meal); if(!box) return;
  let html='';
  if(local.length){html+=`<div class="rs-label">${qty ? `「${fdEsc(qty.q)}」を ${fmtAmt(qty.num)}${fdEsc(qty.unit)} で記録（タップで確定）` : '内蔵・カスタムDB'}</div>`;html+=local.map((f,i)=>resultItemHtml(f,i,meal,qty)).join('')}
  else {html+=`<div class="no-result">見つかりませんでした</div>`}
  box.innerHTML=html; box._local=local; box._quick=false; box._qty=qty||null; box.style.display='block';
}
// 検索欄をタップしたとき（未入力）に、最近使った食品とよく使う食品を出して、1タップで記録できるようにする
function getQuickPickFoods() {
  const byName = new Map(); getAllFoods().forEach(f => byName.set(normFoodName(f.name), f)); // 同名はカスタム/複合が内蔵を上書き
  const sorted = [...entries].sort((a, b) => String(b.date).localeCompare(String(a.date)) || String(b.time || '').localeCompare(String(a.time || '')) || (b.id || 0) - (a.id || 0));
  const recent = [], seen = new Set();
  for (const e of sorted) { const k = normFoodName(e.name); if (seen.has(k)) continue; seen.add(k); const f = byName.get(k); if (f) recent.push(f); if (recent.length >= 8) break; }
  const since = toDateStr(new Date(Date.now() - 60 * 86400000)), cnt = new Map();
  entries.forEach(e => { if (String(e.date) >= since) { const k = normFoodName(e.name); cnt.set(k, (cnt.get(k) || 0) + 1); } });
  const recentKeys = new Set(recent.map(f => normFoodName(f.name)));
  const frequent = [...cnt.entries()].filter(([k, n]) => n >= 2 && !recentKeys.has(k) && byName.has(k)).sort((a, b) => b[1] - a[1]).slice(0, 8).map(([k]) => byName.get(k));
  return { recent, frequent };
}
function onAddSearchFocus(meal) {
  const inp = document.getElementById('addSearch_' + meal), box = document.getElementById('addResultsBox_' + meal);
  if (!inp || !box || inp.value.trim()) return;
  const { recent, frequent } = getQuickPickFoods();
  if (!recent.length && !frequent.length) return;
  const local = [...recent, ...frequent];
  let html = '';
  if (recent.length) html += `<div class="rs-label">最近使った食品</div>` + recent.map((f, i) => resultItemHtml(f, i, meal)).join('');
  if (frequent.length) html += `<div class="rs-label">よく使う食品（直近60日）</div>` + frequent.map((f, i) => resultItemHtml(f, recent.length + i, meal)).join('');
  box.innerHTML = html; box._local = local; box._quick = true; box._qty = null; box.style.display = 'block';
}
// （検索欄・結果の外をタップしたときに閉じる処理は、既存の document クリックハンドラが全ての結果ボックスに対して行う）
if (!window._addBase) window._addBase = {};
function onAddSearch(q, meal) {
  const box=document.getElementById('addResultsBox_'+meal);
  if(!q.trim()){if(box)box.style.display='none';return}
  // 名前に量が続く入力（「ご飯150」「卵2個」）は、名前だけで検索し、その量で記録できるようにする。全体で見つかる場合（例「B12」）は通常の検索
  let local = localSearch(q), qty = null;
  if (!local.length) { const pq = parseQtyQuery(q); if (pq) { const l2 = localSearch(pq.q); if (l2.length) { local = l2; qty = pq; } } }
  renderResultsFor(local, meal, qty);
}
// 食品(f)を、指定の量(amt: g)で食事記録のエントリにする（複合食品は材料の内訳も実量に換算して持たせる）
function buildEntryFromFood(f, meal, amt) {
  const per = f.per || 100;
  const r   = amt / per;
  const newEntry = {
    id: Date.now() + Math.random(),
    date: currentDate,
    meal,
    time:    nowTimeStr(),
    name:    f.name,
    amount:  amt,
    cal:     r1((f.cal||0)*r),
    p:       r1((f.p||0)*r),
    f:       r1((f.f||0)*r),
    c:       r1((f.c||0)*r),
    fiber:   r1((f.fiber||0)*r),
    ...fibSplitScaled(f, r, r1((f.fiber||0)*r)),
    iron:    r2((f.iron||0)*r),
    calcium: r1((f.calcium||0)*r),
    vitc:    r1((f.vitc||0)*r),
    vitd:    r2((f.vitd||0)*r),
    vita:    r1((f.vita||0)*r),
    vite:    r2((f.vite||0)*r),
    vitk:    r1((f.vitk||0)*r),
    iodine:  r1((f.iodine||0)*r),
    salt:    r2((f.salt||0)*r),
    fa:      f.fa || null,
    aa:      f.aa || null,
    digest:  f.digest || classifyDigestCategory(f.name, r1((f.p||0)*r)),
  };
  // 複合食品は、材料の内訳を実量(g)に換算して記録に持たせておく（あとで記録の編集画面から材料ごとに分量を調整できるように）
  if (f._src === 'combo' && Array.isArray(f.ingredients) && f.ingredients.length) {
    newEntry.ingredients = f.ingredients.map(ing => {
      const ip = ing.per || 100, ia = r1((ing.amount || ip) * r);
      return { name: ing.name, amount: ia, per: ip, cal: ing.cal || 0, p: ing.p || 0, f: ing.f || 0, c: ing.c || 0,
        ...Object.fromEntries(MICRO_KEYS.map(k => [k, ing[k] || 0])) };
    });
  }
  return newEntry;
}
// ══ 数量の指定（数量シート）・単位・既定量の学習 ══
// 検索結果をタップしたときの動き: 「確認する」(既定) = 数量シートで量を決めてから記録 / 「すぐ記録」= 既定量で即記録し、通知から量を変更できる。
// 検索欄に量を打った（例「ご飯150」「卵2個」）場合は、その量でそのまま記録する。
const AMOUNT_MODE_KEY = 'pfcAmountSheet', AMOUNT_MAX = 5000;
function getAmountSheetMode() { try { return localStorage.getItem(AMOUNT_MODE_KEY) === 'instant' ? 'instant' : 'ask'; } catch (e) { return 'ask'; } }
function setAmountSheetMode(m) { try { localStorage.setItem(AMOUNT_MODE_KEY, m === 'instant' ? 'instant' : 'ask'); } catch (e) {} }
const fmtAmt = v => String(Math.round((v || 0) * 10) / 10);
// ── 単位（1個＝50g など）──
function sanitizeUnits(arr) {
  if (!Array.isArray(arr)) return []; const out = [];
  arr.forEach(u => {
    if (!u || typeof u !== 'object') return;
    const label = String(u.label == null ? '' : u.label).trim().slice(0, 8), g = parseFloat(u.g);
    if (label && isFinite(g) && g > 0 && g <= AMOUNT_MAX && !out.some(x => x.label === label)) out.push({ label, g: Math.round(g * 10) / 10 });
  });
  return out.slice(0, 8);
}
function unitsToText(units) { return sanitizeUnits(units).map(u => `${u.label}=${u.g}`).join(', '); }
function parseUnitsText(txt) {
  return sanitizeUnits(String(txt || '').normalize('NFKC').split(/[,、，\n]/).map(p => { const m = p.split('='); return m.length >= 2 ? { label: m[0].trim(), g: m[1].replace(/g/i, '') } : null; }).filter(Boolean));
}
function foodUnits(f) { return sanitizeUnits(f && f.units); }
const GENERIC_UNIT_DEFS = [{ label: '小さじ', ml: 5 }, { label: '大さじ', ml: 15 }, { label: 'カップ', ml: 200 }];
function genericUnitsFor(f) { const d = (f && f.density > 0) ? f.density : (f && f.name ? getFoodDensity(f.name) : 1) || 1; return GENERIC_UNIT_DEFS.map(u => ({ label: u.label, g: r1(u.ml * d), generic: true })); }
function allUnitsFor(f) { return [...foodUnits(f), ...genericUnitsFor(f)]; }
// ── 履歴からの既定量・よく使う量 ──
function foodHistory(name) { const k = normFoodName(name); return entries.filter(e => e.amount > 0 && normFoodName(e.name) === k); }
function lastAmountFor(name) {
  let best = null; foodHistory(name).forEach(e => { if (!best || String(e.date) + String(e.time || '') >= String(best.date) + String(best.time || '')) best = e; });
  return best ? best.amount : null;
}
function recentAmountsFor(name, n = 3) {
  const m = new Map(); foodHistory(name).forEach(e => { const a = Math.round(e.amount * 10) / 10, k = String(e.date) + String(e.time || ''), cur = m.get(a) || { n: 0, last: '' }; cur.n++; if (k > cur.last) cur.last = k; m.set(a, cur); });
  return [...m.entries()].sort((x, y) => y[1].n - x[1].n || (y[1].last > x[1].last ? 1 : -1)).slice(0, n).map(x => x[0]);
}
// 1食分が設定されていればそれ、無ければ前回の量、それも無ければ基準量
function defaultAmountFor(f) { if (f.serving > 0) return f.serving; const l = lastAmountFor(f.name); return l || f.per || 100; }
// ── 検索欄の量指定「ご飯150」「卵2個」「納豆 1パック」──
const QTY_RE = /^(.*?)[\s　]*([0-9]+(?:\.[0-9]+)?)[\s　]*(kg|g|ml|cc|グラム|個|こ|枚|杯|本|パック|切れ|切|丁|玉|袋|缶|人前|食|粒|房|膳|尾|皿|カップ|大さじ|小さじ)?$/i;
function parseQtyQuery(q) {
  const n = String(q || '').normalize('NFKC').trim(), m = QTY_RE.exec(n);
  if (!m || !m[1].trim()) return null;
  return { q: m[1].trim(), num: parseFloat(m[2]), unit: (m[3] || '').toLowerCase() };
}
const UNIT_ALIASES = { 'こ': '個', '切': '切れ', 'グラム': 'g' };
function resolveQtyAmount(f, qty) {
  const n = qty.num; if (!(n > 0)) return null;
  const u = UNIT_ALIASES[qty.unit] || qty.unit, units = allUnitsFor(f), own = foodUnits(f);
  const ok = (amount, label) => (amount > 0 && amount <= AMOUNT_MAX) ? { amount: Math.round(amount * 10) / 10, label } : null;
  if (u === '' || u === 'g') {
    if (u === '' && n <= 10 && own[0] && ok(n * own[0].g)) return ok(n * own[0].g, `${fmtAmt(n)}${own[0].label}`);   // 「卵2」→2個（単位のある食品で、小さい数のとき）
    return ok(n, `${fmtAmt(n)}g`);
  }
  if (u === 'kg') return ok(n * 1000, `${fmtAmt(n)}kg`);
  if (u === 'ml' || u === 'cc') return ok(n * (((f && f.density) > 0 ? f.density : getFoodDensity(f.name)) || 1), `${fmtAmt(n)}ml`);
  const hit = units.find(x => x.label === u); if (hit) return ok(n * hit.g, `${fmtAmt(n)}${hit.label}`);
  if (f.serving > 0 && ['個', '枚', '杯', '本', 'パック', '切れ', '人前', '食', '皿', '膳', '袋', '缶', '丁', '玉', '尾'].includes(u)) return ok(n * f.serving, `${fmtAmt(n)}${u}（1食分${fmtAmt(f.serving)}g）`);
  return null;
}
// ── 記録の登録（数量シート・即記録・検索欄の量指定で共通）──
function registerFoodEntry(f, meal, amt) {
  const snap = JSON.parse(JSON.stringify(entries));   // 「元に戻す」用
  const newEntry = buildEntryFromFood(f, meal, amt);
  if (!newEntry.fa || !newEntry.aa) enrichFoodProfile(newEntry);
  const { entry, merged } = addOrMergeEntry(newEntry);
  save();
  const box = document.getElementById('addResultsBox_' + meal); if (box) box.style.display = 'none';
  const inp = document.getElementById('addSearch_' + meal); if (inp) inp.value = '';
  const cont = document.getElementById('amtQuickPick_' + meal); if (cont) cont.style.display = 'none';
  renderRecord(); renderCalendar();
  return { entry: entry || newEntry, merged, snap };
}
function registerFromSelection(f, meal, amt, offerChange) {
  const { entry, merged, snap } = registerFoodEntry(f, meal, amt);
  const msg = merged ? `✅「${fdEsc(f.name)}」を合算しました（+${fmtAmt(amt)}g）` : `✅「${fdEsc(f.name)}」${fmtAmt(amt)}g を記録しました`;
  const acts = []; if (offerChange) acts.push({ label: '量を変更', fn: () => openAmountSheetForEntry(entry.id) });
  acts.push({ label: '元に戻す', fn: () => { entries = snap; save(); renderRecord(); renderCalendar(); } });
  showActionToast(msg, acts, offerChange ? 7000 : 5000);
}
function selectAddResult(i, meal) {
  const box = document.getElementById('addResultsBox_' + meal); if (!box) return;
  const f = box._local && box._local[i]; if (!f) return;
  window._addBase[meal] = { ...f };
  const q = box._qty ? resolveQtyAmount(f, box._qty) : null;
  if (q) { registerFromSelection(f, meal, q.amount, true); return; }               // 検索欄に量を打った → その量でそのまま記録
  if (getAmountSheetMode() === 'ask') { box.style.display = 'none'; openAmountSheetForFood(f, meal); return; }   // 数量シートで量を決めてから記録
  registerFromSelection(f, meal, defaultAmountFor(f), true);                        // すぐ記録（通知から量を変更できる）
}
function duplicateEntry(id) {
  const idx = entries.findIndex(e => e.id === id); if (idx < 0) return;
  const snap = JSON.parse(JSON.stringify(entries)), copy = JSON.parse(JSON.stringify(entries[idx]));
  copy.id = Date.now() + Math.random(); copy.time = nowTimeStr(); editingId = null;
  entries.splice(idx + 1, 0, copy); save(); renderRecord(); renderCalendar();
  showUndoToast(`「${fdEsc(copy.name)}」を複製しました`, () => { entries = snap; save(); renderRecord(); renderCalendar(); });
}
// 既存の記録の量を変更する（単品は値を比例配分、材料を持つ記録は材料の量を同じ比率で変える）
function applyEntryAmount(id, amt) {
  const e = entries.find(x => x.id === id); if (!e || !(amt > 0)) return;
  const snap = JSON.parse(JSON.stringify(entries)), old = e.amount || amt, k = amt / old;
  if (Array.isArray(e.ingredients) && e.ingredients.length) {
    e.ingredients.forEach(ing => { ing.amount = Math.round(ing.amount * k * 10) / 10; });
    recomputeEntryFromIngredients(e);
  } else {
    e.cal = r1(e.cal * k); e.p = r1(e.p * k); e.f = r1(e.f * k); e.c = r1(e.c * k);
    MICRO_KEYS.forEach(key => { if (e[key]) e[key] = microRound(key, e[key] * k); });
    e.amount = Math.round(amt * 10) / 10;
  }
  save(); renderRecord(); renderCalendar();
  showUndoToast(`「${fdEsc(e.name)}」の量を${fmtAmt(old)}g → ${fmtAmt(e.amount)}gに変更しました`, () => { entries = snap; save(); renderRecord(); renderCalendar(); });
}
// ── 数量シート（画面下から出る量の指定画面）──
const AS = { open: false, mode: 'add', f: null, meal: null, entryId: null, name: '', ref: null, base: 100, amount: 100, units: [], unit: null, count: 1, keypad: false, buf: '', fresh: true, warnAck: false, recent: [], timer: null };
const amountStep = a => a < 20 ? 1 : a < 100 ? 5 : 10;   // 量が大きいほど刻みを大きく（ボタンは＋/−の2つだけ）
function asRef(o, refAmt) { return { refAmt: refAmt || 1, cal: o.cal || 0, p: o.p || 0, f: o.f || 0, c: o.c || 0, fiber: o.fiber || 0 }; }
function openAmountSheetForFood(f, meal, initial) {
  const base = defaultAmountFor(f);
  Object.assign(AS, { open: true, mode: 'add', f, meal, entryId: null, name: f.name, ref: asRef(f, f.per || 100), base, amount: initial > 0 ? initial : base, units: allUnitsFor(f), unit: null, count: 1, keypad: false, buf: '', fresh: true, warnAck: false, recent: recentAmountsFor(f.name) });
  showAmountSheet();
}
function openAmountSheetForEntry(id) {
  const e = entries.find(x => x.id === id); if (!e) return;
  const food = getAllFoods().find(x => normFoodName(x.name) === normFoodName(e.name));
  Object.assign(AS, { open: true, mode: 'edit', f: food || null, meal: e.meal, entryId: id, name: e.name, ref: asRef(e, e.amount), base: e.amount, amount: e.amount, units: food ? allUnitsFor(food) : genericUnitsFor({ name: e.name }), unit: null, count: 1, keypad: false, buf: '', fresh: true, warnAck: false, recent: recentAmountsFor(e.name) });
  showAmountSheet();
}
function asPreview() { const r = AS.ref, k = r.refAmt > 0 ? AS.amount / r.refAmt : 0; return { cal: r.cal * k, p: r.p * k, f: r.f * k, c: r.c * k, fiber: r.fiber * k }; }
function asWarning() {   // 打ち間違い（小数点の位置など）に気づけるよう、極端な量を知らせる
  const pv = asPreview(), ratio = AS.base > 0 ? AS.amount / AS.base : 1;
  if (!(AS.amount > 0)) return { block: true, text: '量を入力してください' };
  if (AS.amount >= AMOUNT_MAX) return { text: `${AMOUNT_MAX.toLocaleString()}gが上限です` };
  if (ratio >= 5 && AS.amount >= 50) return { text: `いつもの量（${fmtAmt(AS.base)}g）の${fmtAmt(ratio)}倍です` };
  if (pv.cal >= 1500) return { text: `${ri(pv.cal)}kcalは1品としては多めです` };
  return null;
}
function showAmountSheet() { const root = document.getElementById('amountSheet'); if (!root) return; root.style.display = 'block'; document.body.style.overflow = 'hidden'; renderAmountSheet(); }
function closeAmountSheet() { asStopHold(); AS.open = false; const root = document.getElementById('amountSheet'); if (root) root.style.display = 'none'; document.body.style.overflow = ''; }
function renderAmountSheet() {
  const panel = document.getElementById('asPanel'); if (!panel) return;
  const chip = (cls, attrs, label) => `<button type="button" class="as-chip ${cls}" ${attrs}>${label}</button>`;
  const mults = [[0.5, '½'], [0.75, '¾'], [1, '1×'], [1.5, '1.5×'], [2, '2×'], [3, '3×']];
  const keypad = ['7', '8', '9', '4', '5', '6', '1', '2', '3', '.', '0', '⌫'].map(k => `<button type="button" class="as-key" onclick="asKey('${k}')">${k}</button>`).join('');
  const rows = AS.keypad
    ? `<div class="as-keypad">${keypad}</div><div class="as-hint">${AS.unit ? AS.unit.label + 'の数' : 'グラム'}を入力（最初の1桁で入れ替わります）</div>`
    : `<div class="as-label">いつもの量 ${fmtAmt(AS.base)}g を基準に</div><div class="as-chips">${mults.map(([m, l]) => chip('as-m', `data-m="${m}" onclick="asMultiply(${m})"`, l)).join('')}</div>`
      + (AS.recent.length ? `<div class="as-label">よく使う量</div><div class="as-chips">${AS.recent.map(a => chip('as-r', `data-a="${a}" onclick="asSetGrams(${a})"`, fmtAmt(a) + 'g')).join('')}</div>` : '')
      + `<div class="as-label">単位</div><div class="as-chips">${chip('as-g', 'data-g="1" onclick="asGramMode()"', 'g')}${AS.units.map((u, i) => chip('as-u' + (u.generic ? ' as-gen' : ''), `data-u="${i}" onclick="asPickUnit(${i})"`, `${fdEsc(u.label)} <small>${fmtAmt(u.g)}g</small>`)).join('')}</div>`
      + `<div class="as-stepper"><button type="button" class="as-step" data-step="-1" aria-label="減らす">−</button><button type="button" class="as-step" data-step="1" aria-label="増やす">＋</button></div>`;
  panel.innerHTML = `<div class="as-grab"></div>
    <div class="as-head"><div class="as-title">${fdEsc(AS.name)}<span class="as-sub">${AS.mode === 'add' ? fdEsc(AS.meal || '') + 'に記録' : '量の変更'}</span></div><button type="button" class="as-x" onclick="closeAmountSheet()" aria-label="閉じる">✕</button></div>
    <div class="as-display" onclick="asToggleKeypad()" role="button" aria-label="数字キーで入力"><span id="asNum" class="as-num"></span><span id="asUnit" class="as-unit"></span><span class="as-kp">${AS.keypad ? '▾' : '⌨'}</span></div>
    <div id="asSub" class="as-subline"></div><div id="asPv" class="as-pv"></div><div id="asWarn" class="as-warn" style="display:none"></div>
    ${rows}
    <button type="button" id="asConfirm" class="btn btn-primary as-confirm" onclick="confirmAmountSheet()"></button>
    <label class="as-toggle"><input type="checkbox" id="asInstant" ${getAmountSheetMode() === 'instant' ? 'checked' : ''} onchange="setAmountSheetMode(this.checked?'instant':'ask')">次回から確認せず、すぐ記録する（記録後の通知から量を変更できます）</label>`;
  panel.querySelectorAll('[data-step]').forEach(btn => {   // ＋/−は長押しで連続して変わる
    const dir = Number(btn.dataset.step);
    btn.addEventListener('pointerdown', ev => { ev.preventDefault(); asStep(dir); asStopHold(); AS.timer = setTimeout(function tick() { asStep(dir); AS.timer = setTimeout(tick, 90); }, 450); });
    ['pointerup', 'pointerleave', 'pointercancel'].forEach(t => btn.addEventListener(t, asStopHold));
  });
  updateAmountDisplay();
}
function asStopHold() { clearTimeout(AS.timer); AS.timer = null; }
function updateAmountDisplay() {   // 量が変わったときの更新（押している＋/−ボタンを作り直さないよう、変わる部分だけ書き換える）
  const $ = id => document.getElementById(id); if (!$('asNum')) return;
  const pv = asPreview(), w = asWarning();
  $('asNum').textContent = AS.keypad && !AS.fresh ? (AS.buf || '0') : fmtAmt(AS.unit ? AS.count : AS.amount);
  $('asUnit').textContent = AS.unit ? AS.unit.label : 'g';
  $('asSub').textContent = AS.unit ? `＝ ${fmtAmt(AS.amount)}g` : (AS.base > 0 ? `いつもの量の ${fmtAmt(AS.amount / AS.base)} 倍` : '');
  $('asPv').textContent = `${ri(pv.cal)}kcal　P${r1(pv.p)}　F${r1(pv.f)}　C${r1(pv.c)}${pv.fiber ? '　繊' + r1(pv.fiber) : ''}`;
  const we = $('asWarn'); if (w && !w.block) { we.style.display = 'block'; we.textContent = '⚠ ' + w.text; } else we.style.display = 'none';
  const cb = $('asConfirm'), label = AS.mode === 'add' ? `${AS.meal || ''}に記録する` : '量を変更する';
  cb.textContent = (w && !w.block && AS.warnAck) ? `それでも ${fmtAmt(AS.amount)}g で${AS.mode === 'add' ? '記録する' : '変更する'}` : `${label}　${fmtAmt(AS.amount)}g`;
  cb.disabled = !!(w && w.block); cb.classList.toggle('as-warnbtn', !!(w && !w.block && AS.warnAck));
  document.querySelectorAll('#asPanel .as-m').forEach(b => b.classList.toggle('on', !AS.unit && Math.round(AS.base * Number(b.dataset.m) * 10) / 10 === AS.amount));
  document.querySelectorAll('#asPanel .as-r').forEach(b => b.classList.toggle('on', !AS.unit && Number(b.dataset.a) === AS.amount));
  document.querySelectorAll('#asPanel .as-u').forEach(b => b.classList.toggle('on', AS.unit === AS.units[Number(b.dataset.u)]));
  document.querySelectorAll('#asPanel .as-g').forEach(b => b.classList.toggle('on', !AS.unit));
}
function asClamp(v) { return Math.min(AMOUNT_MAX, Math.max(0, Math.round(v * 10) / 10)); }
function asSetGrams(v) { AS.unit = null; AS.amount = asClamp(v); AS.fresh = true; AS.buf = ''; AS.warnAck = false; updateAmountDisplay(); }
function asGramMode() { AS.unit = null; AS.warnAck = false; updateAmountDisplay(); }
function asMultiply(m) { asSetGrams(AS.base * m); }
function asPickUnit(i) { const u = AS.units[i]; if (!u) return; AS.unit = u; AS.count = 1; AS.amount = asClamp(u.g); AS.warnAck = false; updateAmountDisplay(); }
function asStep(dir) {
  const EPS = 1e-9;
  if (AS.unit) {   // 単位モード: 5未満は0.5刻み、それ以上は1刻み（上下で対称）
    const st = (dir > 0 ? AS.count : AS.count - 0.01) < 5 ? 0.5 : 1;
    const next = dir > 0 ? Math.floor(AS.count / st + EPS) * st + st : Math.ceil(AS.count / st - EPS) * st - st;
    AS.count = Math.min(99, Math.max(0.5, next)); AS.amount = asClamp(AS.count * AS.unit.g);
  } else {         // グラム: 量が大きいほど刻みを大きくし、次のきりのよい値（5の倍数・10の倍数）へ進む
    const a = AS.amount, st = amountStep(dir > 0 ? a : Math.max(a - 0.1, 0));
    const next = dir > 0 ? Math.floor(a / st + EPS) * st + st : Math.ceil(a / st - EPS) * st - st;
    AS.amount = asClamp(Math.max(1, next));
  }
  AS.warnAck = false; updateAmountDisplay();
}
function asToggleKeypad() { AS.keypad = !AS.keypad; AS.fresh = true; AS.buf = ''; renderAmountSheet(); }
function asKey(k) {
  if (k === '⌫') AS.buf = AS.fresh ? '' : AS.buf.slice(0, -1);
  else { if (AS.fresh) AS.buf = ''; if (k === '.') { if (AS.buf.includes('.')) return; if (AS.buf === '') AS.buf = '0'; } if (AS.buf.length >= 6) return; AS.buf += k; }
  AS.fresh = false;
  const v = parseFloat(AS.buf) || 0;
  if (AS.unit) { AS.count = Math.min(99, v); AS.amount = asClamp(AS.count * AS.unit.g); } else AS.amount = asClamp(v);
  AS.warnAck = false; updateAmountDisplay();
}
function confirmAmountSheet() {
  const w = asWarning(); if (w && w.block) return;
  if (w && !AS.warnAck) { AS.warnAck = true; updateAmountDisplay(); return; }   // 極端な量は、もう一度押さないと確定しない
  const amt = AS.amount, mode = AS.mode, f = AS.f, meal = AS.meal, id = AS.entryId;
  closeAmountSheet();
  if (mode === 'add' && f) registerFromSelection(f, meal, amt, false); else if (mode === 'edit') applyEntryAmount(id, amt);
}
document.addEventListener('keydown', ev => { if (!AS.open) return; if (ev.key === 'Escape') closeAmountSheet(); else if (ev.key === 'Enter' && !(ev.target && ev.target.type === 'checkbox')) confirmAmountSheet(); });
document.addEventListener('pointerup', asStopHold); document.addEventListener('touchend', asStopHold);
// ══ 記録のグループ化（長押し→ドラッグ）と、複合食品への登録 ══
// 食事記録を長押しして別の記録の上にドロップすると、ひとつの「グループ」記録にまとめる（iOSのフォルダのように）。
// グループ = 材料(ingredients)を持つ記録。材料の分量はこれまでの複合食品の記録と同じ編集画面で調整でき、合計は自動計算される。
// 記録の各材料は「per グラムあたりの値」で持つ（comboScaled で実量に換算）。単品の記録は per = 量 ・値はそのまま。
function ingredientFromEntry(e) {
  const c = { ...e }; materializeFiberSplit(c);   // 過去の記録も食物繊維の内訳を補完してから持つ
  return { name: e.name, amount: e.amount, per: e.amount || 100, cal: c.cal || 0, p: c.p || 0, f: c.f || 0, c: c.c || 0, ...Object.fromEntries(MICRO_KEYS.map(k => [k, c[k] || 0])) };
}
function entryIngredients(e) { return (Array.isArray(e.ingredients) && e.ingredients.length) ? e.ingredients.map(i => ({ ...i })) : [ingredientFromEntry(e)]; }
function autoGroupName(ings) {
  const names = ings.map(i => i.name); const n = names.length;
  const txt = n <= 3 ? names.join('＋') : `${names.slice(0, 2).join('＋')}＋ほか${n - 2}品`;
  return txt.length > 30 ? txt.slice(0, 29) + '…' : txt;
}
function recomputeEntryFromIngredients(e) {
  const tot = comboTotals(e.ingredients.map(ing => comboScaled(ing, ing.amount)));
  e.amount = r1(e.ingredients.reduce((a, ing) => a + (ing.amount || 0), 0));
  e.cal = r1(tot.cal); e.p = r1(tot.p); e.f = r1(tot.f); e.c = r1(tot.c);
  MICRO_KEYS.forEach(k => { e[k] = microRound(k, tot[k]); });
  e.digest = 'mixed'; delete e.fa; delete e.aa; enrichFoodProfile(e);
  return e;
}
// 材料のリストから複合食品を組み立てる（記録のグループ・記録の選択のどちらからも使う）
function buildComboFromIngredients(ings, name, category) {
  const tot = comboTotals(ings.map(ing => comboScaled(ing, ing.amount)));
  const totalAmt = ings.reduce((a, ing) => a + Math.max(0, ing.amount || 0), 0);
  const cat = sanitizeCategory(category) || guessFoodCategory(name);
  // 100gあたりに正規化せず、材料の総重量を基準量(per)にする（手動の複合食品登録と同じ方式）
  return {
    id: Date.now() + Math.random(),
    name, ...(cat ? { category: cat } : {}), per: r1(totalAmt), serving: r1(totalAmt),
    cal: r1(tot.cal), p: r1(tot.p), f: r1(tot.f), c: r1(tot.c),
    ...Object.fromEntries(MICRO_KEYS.map(k => [k, microRound(k, tot[k])])),
    ingredients: ings.map(ing => ({ ...ing })),
    digest: 'mixed',
    _src: 'combo',
  };
}
function buildComboFromEntries(srcs, name, category) { return buildComboFromIngredients(srcs.map(ingredientFromEntry), name, category); }

// src を target の上にドロップしたときの処理。target の記録（位置・食事・時刻）がグループになり、src の記録は取り込まれて消える
function groupEntries(srcId, targetId) {
  if (srcId === targetId) return false;
  const si = entries.findIndex(e => e.id === srcId), ti = entries.findIndex(e => e.id === targetId);
  if (si === -1 || ti === -1) return false;
  const src = entries[si], tgt = entries[ti], snap = JSON.parse(JSON.stringify(entries));
  const tgtAuto = Array.isArray(tgt.ingredients) && tgt.ingredients.length && tgt.name === autoGroupName(tgt.ingredients);   // 自動命名のままのグループは、メンバーが増えたら名前も更新する
  const ings = [...entryIngredients(tgt), ...entryIngredients(src)];
  tgt.ingredients = ings;
  if (!(Array.isArray(snap[ti].ingredients) && snap[ti].ingredients.length) || tgtAuto) tgt.name = autoGroupName(ings);
  tgt.group = true;
  recomputeEntryFromIngredients(tgt);
  entries = entries.filter(e => e.id !== srcId);
  save();
  _grpOpen.add(tgt.id);
  renderRecord(); renderCalendar();
  showUndoToast(`「${src.name}」を「${snap[ti].name}」にグループ化しました（${ings.length}品）`, () => { entries = snap; save(); renderRecord(); renderCalendar(); });
  return true;
}
// グループ（材料を持つ記録）を、材料ごとの個別の記録に戻す
function ungroupEntry(id) {
  const idx = entries.findIndex(e => e.id === id); if (idx === -1) return;
  const g = entries[idx]; if (!Array.isArray(g.ingredients) || !g.ingredients.length) return;
  const snap = JSON.parse(JSON.stringify(entries));
  const parts = g.ingredients.map((ing, i) => {
    const sc = comboScaled(ing, ing.amount);
    const e = { id: Date.now() + Math.random() + i, date: g.date, meal: g.meal, time: g.time, name: ing.name, amount: r1(ing.amount),
      cal: r1(sc._cal), p: r1(sc._p), f: r1(sc._f), c: r1(sc._c), ...Object.fromEntries(MICRO_KEYS.map(k => [k, microRound(k, sc['_' + k] || 0)])) };   // comboScaled は値を「_cal」のように _ 付きのキーで返す
    e.digest = classifyDigestCategory(e.name, e.p); enrichFoodProfile(e); return e;
  });
  entries.splice(idx, 1, ...parts); _grpOpen.delete(id);
  save(); renderRecord(); renderCalendar();
  showUndoToast(`「${g.name}」のグループを解除しました（${parts.length}件）`, () => { entries = snap; save(); renderRecord(); renderCalendar(); });
}
// グループを、名前を付けて複合食品DBに登録する（以後は食品検索から1タップで記録できる）
function registerGroupAsCombo(id) {
  const g = entries.find(e => e.id === id); if (!g || !Array.isArray(g.ingredients) || !g.ingredients.length) return;
  const nameEl = document.getElementById('grpName_' + id), catEl = document.getElementById('grpCat_' + id), msg = document.getElementById('grpMsg_' + id);
  const fail = t => { if (msg) msg.textContent = t; else showToast(t); };
  const name = ((nameEl && nameEl.value) || g.name || '').trim(); if (!name) { fail('複合食品名を入力してください'); return; }
  if ([...comboFoods, ...customFoods].some(f => normFoodName(f.name) === normFoodName(name))) { fail(`「${name}」は既に登録されています。別の名前にしてください`); return; }
  const combo = buildComboFromIngredients(g.ingredients, name, catEl ? catEl.value : '');
  comboFoods.push(combo); saveCustom(); renderComboFoodList();
  showUndoToast(`「${name}」を複合食品に登録しました（${g.ingredients.length}品）`, () => { comboFoods = comboFoods.filter(f => f.id !== combo.id); saveCustom(); renderComboFoodList(); });
  if (msg) msg.textContent = '';
}
const _grpOpen = new Set();
function toggleGroupOpen(id) { if (_grpOpen.has(id)) _grpOpen.delete(id); else _grpOpen.add(id); renderRecord(); }
function groupMembersHtml(e) {
  return `<div class="grp-members" onclick="event.stopPropagation()">
    ${e.ingredients.map(ing => { const sc = comboScaled(ing, ing.amount); return `<div class="grp-m"><span>${fdEsc(ing.name)}</span><span>${r1(ing.amount)}g ・${ri(sc._cal)}kcal</span></div>`; }).join('')}
    <div class="row" style="margin:8px 0 6px"><div class="field" style="flex:2"><input type="text" id="grpName_${e.id}" value="${fdEsc(e.name)}" placeholder="複合食品名" autocomplete="off"></div><div class="field" style="flex:1.2"><input type="text" id="grpCat_${e.id}" list="foodCatList" value="${fdEsc(e.category || '')}" placeholder="カテゴリ" autocomplete="off"></div></div>
    <div id="grpMsg_${e.id}" class="status-msg status-err" style="margin-bottom:4px"></div>
    <div class="grp-actions"><button class="btn btn-primary btn-sm" onclick="registerGroupAsCombo(${e.id})">複合食品として登録</button><button class="btn btn-sm" onclick="ungroupEntry(${e.id})">グループ解除</button></div>
  </div>`;
}
// ── 長押し→ドラッグの操作 ──
const DRAG_HOLD_MS = 380;
const DRAG = { timer: null, pending: null, active: false, srcId: null, row: null, ghost: null, target: null, raf: 0, x: 0, y: 0, offX: 0, offY: 0, suppressUntil: 0 };
function dragRowFromEvent(ev) {
  const t = ev.target; if (!t || !t.closest) return null;
  if (t.closest('button, input, select, textarea, a, .edit-form, .grp-members')) return null;
  const row = t.closest('.log-item[data-eid]'); return row && row.closest('#mealBlocks') ? row : null;
}
function dragPointerStart(ev, x, y) {
  const row = dragRowFromEvent(ev); if (!row || DRAG.active) return;
  dragCancelPending(); DRAG.pending = { row, x, y };
  DRAG.timer = setTimeout(() => dragBegin(row, x, y), DRAG_HOLD_MS);
}
function dragCancelPending() { clearTimeout(DRAG.timer); DRAG.timer = null; DRAG.pending = null; }
function dragBegin(row, x, y) {
  DRAG.timer = null; DRAG.pending = null; DRAG.active = true; DRAG.row = row; DRAG.srcId = Number(row.dataset.eid);
  const r = row.getBoundingClientRect(); DRAG.offX = x - r.left; DRAG.offY = y - r.top; DRAG.x = x; DRAG.y = y;
  const ghost = row.cloneNode(true); ghost.classList.add('drag-ghost'); ghost.removeAttribute('data-eid');
  ghost.style.width = r.width + 'px'; ghost.style.transform = `translate(${x - DRAG.offX}px, ${y - DRAG.offY}px) scale(1.03)`;
  document.body.appendChild(ghost); DRAG.ghost = ghost;
  row.classList.add('dragging-src'); document.body.classList.add('drag-mode');
  try { if (navigator.vibrate) navigator.vibrate(12); } catch (e) {}
  dragAutoScroll();
}
function dragMove(x, y) {
  if (!DRAG.active) return; DRAG.x = x; DRAG.y = y;
  DRAG.ghost.style.transform = `translate(${x - DRAG.offX}px, ${y - DRAG.offY}px) scale(1.03)`;
  const el = typeof document.elementFromPoint === 'function' ? document.elementFromPoint(x, y) : null;
  let tr = el && el.closest ? el.closest('.log-item[data-eid]') : null;
  if (tr === DRAG.row || (tr && tr.closest('.drag-ghost'))) tr = null;
  if (tr !== DRAG.target) { if (DRAG.target) DRAG.target.classList.remove('drop-target'); DRAG.target = tr; if (tr) tr.classList.add('drop-target'); }
}
function dragAutoScroll() { // 画面の上端・下端の近くにいる間は自動でスクロールする
  if (!DRAG.active) return;
  const h = window.innerHeight || 800; let dy = 0;
  if (DRAG.y < 90) dy = -Math.ceil((90 - DRAG.y) / 6); else if (DRAG.y > h - 120) dy = Math.ceil((DRAG.y - (h - 120)) / 6);
  if (dy) { window.scrollBy(0, dy); dragMove(DRAG.x, DRAG.y); }
  DRAG.raf = requestAnimationFrame(dragAutoScroll);
}
function dragEnd(commit) {
  if (!DRAG.active) return;
  const targetId = DRAG.target ? Number(DRAG.target.dataset.eid) : null, srcId = DRAG.srcId;
  cancelAnimationFrame(DRAG.raf);
  if (DRAG.ghost) DRAG.ghost.remove();
  if (DRAG.row) DRAG.row.classList.remove('dragging-src'); if (DRAG.target) DRAG.target.classList.remove('drop-target');
  document.body.classList.remove('drag-mode');
  DRAG.active = false; DRAG.ghost = null; DRAG.row = null; DRAG.target = null; DRAG.suppressUntil = Date.now() + 450;   // 指を離した直後のクリック（編集画面が開く等）を無効にする
  if (commit && targetId != null) groupEntries(srcId, targetId);
}
function bindEntryDrag() {
  const root = document.getElementById('mealBlocks'); if (!root) return;
  root.addEventListener('touchstart', ev => { if (ev.touches && ev.touches.length === 1) dragPointerStart(ev, ev.touches[0].clientX, ev.touches[0].clientY); }, { passive: true });
  document.addEventListener('touchmove', ev => {   // ドラッグ中だけスクロールを止める（iOSでは最初から non-passive で登録しておく必要がある）
    const t = ev.touches && ev.touches[0]; if (!t) return;
    if (DRAG.active) { ev.preventDefault(); dragMove(t.clientX, t.clientY); }
    else if (DRAG.pending && Math.hypot(t.clientX - DRAG.pending.x, t.clientY - DRAG.pending.y) > 9) dragCancelPending();   // 動いたらスクロール操作とみなす
  }, { passive: false });
  document.addEventListener('touchend', () => { if (DRAG.active) dragEnd(true); else dragCancelPending(); });
  document.addEventListener('touchcancel', () => { if (DRAG.active) dragEnd(false); else dragCancelPending(); });
  root.addEventListener('mousedown', ev => { if (ev.button === 0) dragPointerStart(ev, ev.clientX, ev.clientY); });
  document.addEventListener('mousemove', ev => { if (DRAG.active) dragMove(ev.clientX, ev.clientY); else if (DRAG.pending && Math.hypot(ev.clientX - DRAG.pending.x, ev.clientY - DRAG.pending.y) > 9) dragCancelPending(); });
  document.addEventListener('mouseup', () => { if (DRAG.active) dragEnd(true); else dragCancelPending(); });
  document.addEventListener('click', ev => { if (Date.now() < DRAG.suppressUntil) { ev.stopPropagation(); ev.preventDefault(); } }, true);
  document.addEventListener('contextmenu', ev => { if (DRAG.active || DRAG.pending) ev.preventDefault(); });
}
// ── 記録の行を左にスワイプ → 「複製」「削除」を表示（押し間違えやすい✕ボタンの代わり）──
const SW = { row: null, x: 0, y: 0, decided: null, open: null };
function swipeClose() { if (SW.open) { SW.open.classList.remove('sw-open'); SW.open = null; } }
function swipeOpen(row) { if (SW.open && SW.open !== row) SW.open.classList.remove('sw-open'); row.classList.add('sw-open'); SW.open = row; DRAG.suppressUntil = Date.now() + 350; }
function bindEntrySwipe() {
  const root = document.getElementById('mealBlocks'); if (!root) return;
  root.addEventListener('touchstart', ev => { if (!ev.touches || ev.touches.length !== 1) return; const t = ev.touches[0]; SW.row = dragRowFromEvent(ev); SW.x = t.clientX; SW.y = t.clientY; SW.decided = null; }, { passive: true });
  document.addEventListener('touchmove', ev => {
    if (!SW.row || DRAG.active) return; const t = ev.touches && ev.touches[0]; if (!t) return;
    const dx = t.clientX - SW.x, dy = t.clientY - SW.y;
    if (SW.decided === null) { if (Math.abs(dx) > 14 && Math.abs(dx) > Math.abs(dy) * 1.5) SW.decided = 'h'; else if (Math.abs(dy) > 14) SW.decided = 'v'; }   // 縦に動いたらスクロール
    if (SW.decided === 'h') { if (dx < -50) { swipeOpen(SW.row); SW.row = null; } else if (dx > 50 && SW.row.classList.contains('sw-open')) { swipeClose(); SW.row = null; } }
  }, { passive: true });
  document.addEventListener('touchend', () => { SW.row = null; }); document.addEventListener('touchcancel', () => { SW.row = null; });
  document.addEventListener('click', ev => { if (Date.now() < DRAG.suppressUntil) return; if (SW.open && !(ev.target.closest && ev.target.closest('.sw-actions'))) swipeClose(); }, true);   // 他の場所をタップしたら閉じる
}
function dismissDragHint() { try { localStorage.setItem('pfcDragHint', '1'); } catch (e) {} const el = document.getElementById('dragHint'); if (el) el.style.display = 'none'; }
// ── 調味料クイック登録 ──
// 小さじ1 = 約5ml（油類・液体）/調味料によって重量が異なる
// ユーザーが自由に追加・削除できるよう配列で管理する（初回起動時はこの12種を初期値として使う）
const DEFAULT_QUICK_SEASONINGS = [
  { label:'しょうゆ',  name:'醤油（濃口）',     amount:6, cal:4,  p:0.5, f:0,   c:0.6, fiber:0,   iron:0.1, calcium:2, vitc:0,   vitd:0, salt:0.9 },
  { label:'味噌',      name:'味噌（米みそ）',   amount:6, cal:12, p:0.7, f:0.4, c:1.3, fiber:0.3, iron:0.2, calcium:8, vitc:0,   vitd:0, salt:0.7 },
  { label:'鶏ガラ',    name:'鶏ガラスープの素', amount:3, cal:7,  p:0.6, f:0.2, c:0.8, fiber:0,   iron:0.1, calcium:3, vitc:0,   vitd:0, salt:1.3 },
  { label:'米油',      name:'米油',             amount:4, cal:37, p:0,   f:4.0, c:0,   fiber:0,   iron:0,   calcium:0, vitc:0,   vitd:0, salt:0   },
  { label:'みりん',    name:'みりん',           amount:6, cal:14, p:0,   f:0,   c:3.1, fiber:0,   iron:0,   calcium:0, vitc:0,   vitd:0, salt:0   },
  { label:'にんにく',  name:'にんにく',         amount:5, cal:7,  p:0.3, f:0,   c:1.4, fiber:0.3, iron:0,   calcium:1, vitc:0.6, vitd:0, salt:0   },
  { label:'白だし',    name:'白だし',           amount:6, cal:7,  p:0.4, f:0,   c:1.4, fiber:0,   iron:0.1, calcium:3, vitc:0,   vitd:0, salt:1.0 },
  { label:'カレー粉',  name:'カレー粉',         amount:2, cal:7,  p:0.3, f:0.3, c:1.0, fiber:0.6, iron:0.3, calcium:5, vitc:0,   vitd:0, salt:0   },
  { label:'酢',        name:'酢（穀物酢）',     amount:5, cal:1,  p:0,   f:0,   c:0.1, fiber:0,   iron:0,   calcium:0, vitc:0,   vitd:0, salt:0   },
  { label:'砂糖',      name:'砂糖（上白糖）',   amount:3, cal:12, p:0,   f:0,   c:3.0, fiber:0,   iron:0,   calcium:0, vitc:0,   vitd:0, salt:0   },
  { label:'ウスター',  name:'ウスターソース',   amount:6, cal:7,  p:0.1, f:0,   c:1.6, fiber:0,   iron:0.1, calcium:4, vitc:0,   vitd:0, salt:0.5 },
  { label:'ケチャ',    name:'ケチャップ',       amount:5, cal:6,  p:0.1, f:0,   c:1.4, fiber:0.1, iron:0,   calcium:1, vitc:0.5, vitd:0, salt:0.2 },
];
let quickSeasonings = [];
try {
  const qs = JSON.parse(localStorage.getItem('pfcQuickSeasonings') || 'null');
  quickSeasonings = qs || JSON.parse(JSON.stringify(DEFAULT_QUICK_SEASONINGS));
} catch(e) { quickSeasonings = JSON.parse(JSON.stringify(DEFAULT_QUICK_SEASONINGS)); }
quickSeasonings.forEach(s => { if (s.id == null) s.id = Date.now() + Math.random(); });
function saveQuickSeasoningsLocal() { try { localStorage.setItem('pfcQuickSeasonings', JSON.stringify(quickSeasonings)); } catch (e) {} }
function saveQuickSeasonings() {
  try { localStorage.setItem('pfcQuickSeasonings', JSON.stringify(quickSeasonings)); } catch(e) {}
  queueCloudSave();
}

let _seasoningMsgTimer = null;
function addSeasoning(id) {
  const s = quickSeasonings.find(x => x.id === id);
  if (!s) return;
  const meal = document.getElementById('seasoningMeal')?.value || '昼食';
  const { merged } = addOrMergeEntry({
    id: Date.now() + Math.random(),
    date: currentDate,
    meal,
    time:    nowTimeStr(),
    name:    s.name,
    amount:  s.amount,
    cal:     s.cal,
    p:       s.p,
    f:       s.f,
    c:       s.c,
    fiber:   s.fiber,
    fibS:    s.fibS || 0,
    fibI:    s.fibI || 0,
    iron:    s.iron,
    calcium: s.calcium,
    vitc:    s.vitc,
    vitd:    s.vitd,
    salt:    s.salt,
    fa:      s.fa || null,
    aa:      s.aa || null,
    digest:  s.digest || classifyDigestCategory(s.name, s.p || 0),
  });
  save();
  renderRecord();
  showToast(merged ? `✅ ${s.name}（${s.amount}g）を${meal}に合算しました` : `✅ ${s.name}（${s.amount}g）を${meal}に追加`);
}
function renderQuickSeasonings() {
  const cont = document.getElementById('quickSeasoningBtns');
  if (!cont) return;
  cont.innerHTML = quickSeasonings.map(s =>
    `<button onclick="addSeasoning(${s.id})" class="seasoning-btn" style="flex:0 0 auto;white-space:nowrap">${s.label}</button>`
  ).join('') + `<button onclick="toggleQsManager()" class="seasoning-btn" style="flex:0 0 auto;white-space:nowrap;opacity:.75">⚙️ 管理</button>`;
}
function toggleQsManager() {
  const el = document.getElementById('quickSeasoningManager');
  if (!el) return;
  const show = el.style.display === 'none';
  el.style.display = show ? '' : 'none';
  if (show) renderQsExistingList();
}
function onQsSearch(q) {
  const box = document.getElementById('qsResultsBox');
  if (!q.trim()) { box.style.display = 'none'; return; }
  const local = localSearch(q);
  box.innerHTML = local.length
    ? local.map((f,i) => `<div class="ri" onclick="pickQsSeasoning(${i})"><div><div class="ri-name">${f.name}<span class="badge badge-${f._src||'local'}">${SRC_LABEL[f._src||'local']}</span></div><div class="ri-sub">${f.serving||f.per}gで登録されます</div></div><div class="ri-cal">${f.cal}kcal</div></div>`).join('')
    : `<div class="no-result">見つかりませんでした</div>`;
  box._local = local;
  box.style.display = 'block';
}
function pickQsSeasoning(i) {
  const box = document.getElementById('qsResultsBox');
  const f = box._local && box._local[i];
  if (!f) return;
  const per = f.per || 100, amt = f.serving || per, r = amt / per;
  quickSeasonings.push({
    id: Date.now() + Math.random(),
    label: f.name.length > 8 ? f.name.slice(0,8) : f.name,
    name: f.name, amount: r1(amt),
    cal: r1(f.cal*r), p: r1(f.p*r), f: r1(f.f*r), c: r1(f.c*r),
    fiber: r1((f.fiber||0)*r), iron: r1((f.iron||0)*r), calcium: r1((f.calcium||0)*r),
    vitc: r1((f.vitc||0)*r), vitd: r1((f.vitd||0)*r), salt: r2((f.salt||0)*r),
    fa: f.fa || null, aa: f.aa || null,
    digest: f.digest || classifyDigestCategory(f.name, r1(f.p*r)),
  });
  saveQuickSeasonings();
  renderQuickSeasonings();
  renderQsExistingList();
  box.style.display = 'none';
  document.getElementById('qsSearch').value = '';
}
function renderQsExistingList() {
  const el = document.getElementById('qsExistingList');
  if (!el) return;
  el.innerHTML = quickSeasonings.map(s =>
    `<div style="display:flex;align-items:center;gap:8px;padding:5px 0;border-bottom:1px solid var(--border);font-size:12px">
      <span style="flex:1">${s.label}<span style="color:var(--text-sub)"> — ${s.name} ${s.amount}g・${s.cal}kcal</span></span>
      <button class="btn btn-sm btn-danger" onclick="deleteQuickSeasoning(${s.id})">✕</button>
    </div>`
  ).join('') || `<div style="font-size:12px;color:var(--text-sub);padding:6px 0">まだありません</div>`;
}
function deleteQuickSeasoning(id) {
  const idx = quickSeasonings.findIndex(s => s.id === id);
  if (idx === -1) return;
  const removed = quickSeasonings[idx];
  quickSeasonings.splice(idx, 1);
  saveQuickSeasonings();
  renderQuickSeasonings();
  renderQsExistingList();
  showUndoToast(`「${removed.label}」をクイック登録から削除しました`, () => {
    quickSeasonings.splice(Math.min(idx, quickSeasonings.length), 0, removed);
    saveQuickSeasonings(); renderQuickSeasonings(); renderQsExistingList();
  });
}


function openCopyDayModal() {
  const modal = document.getElementById('copyDayModal');
  if (!modal) return;
  // タブをデフォルト（1日まるごと）にリセット
  document.querySelectorAll('#copyTabToggle .toggle-btn').forEach(b => b.classList.remove('active'));
  const dayTabBtn = document.querySelector('#copyTabToggle .toggle-btn[data-copytab="day"]');
  if (dayTabBtn) dayTabBtn.classList.add('active');
  const dayDiv = document.getElementById('copyTabDay'), mealDiv = document.getElementById('copyTabMeal');
  if (dayDiv) dayDiv.style.display = '';
  if (mealDiv) mealDiv.style.display = 'none';
  // デフォルト: 昨日
  const yesterday = new Date(currentDate + 'T00:00:00');
  yesterday.setDate(yesterday.getDate() - 1);
  const input = document.getElementById('copyFromDate');
  if (input) input.value = toDateStr(yesterday);
  const destLabel = document.getElementById('copyDestLabel');
  if (destLabel) destLabel.textContent = dateLabel(currentDate);
  modal.style.display = 'flex';
  updateCopyDayPreview();
}
function switchCopyTab(tab, el) {
  document.querySelectorAll('#copyTabToggle .toggle-btn').forEach(b => b.classList.remove('active'));
  el.classList.add('active');
  const dayDiv = document.getElementById('copyTabDay'), mealDiv = document.getElementById('copyTabMeal');
  if (dayDiv) dayDiv.style.display = tab === 'day' ? '' : 'none';
  if (mealDiv) mealDiv.style.display = tab === 'meal' ? '' : 'none';
  if (tab === 'meal') renderCopyPanel();
}
function closeCopyDayModal() {
  const modal = document.getElementById('copyDayModal');
  if (modal) modal.style.display = 'none';
  const msg = document.getElementById('copyDayMsg');
  if (msg) msg.textContent = '';
}
function updateCopyDayPreview() {
  const input = document.getElementById('copyFromDate');
  const preview = document.getElementById('copyDayPreview');
  if (!input || !preview) return;
  const fromDate = input.value;
  if (!fromDate) { preview.textContent = '日付を選択してください'; return; }
  const fromEntries = entries.filter(e => e.date === fromDate);
  const fromEx      = exercises.filter(e => e.date === fromDate);
  if (!fromEntries.length && !fromEx.length) {
    preview.textContent = `${dateLabel(fromDate)} の記録はありません`;
    return;
  }
  const s = sumEntries(fromEntries);
  const mealCounts = MEALS_ORDER.map(m => {
    const cnt = fromEntries.filter(e => e.meal === m).length;
    return cnt ? `${m}${cnt}品` : null;
  }).filter(Boolean).join(' / ');
  preview.innerHTML = `
    <div style="font-weight:600;margin-bottom:3px">${dateLabel(fromDate)}</div>
    <div>${mealCounts || '食事なし'}　合計 ${ri(s.cal)} kcal</div>
    ${fromEx.length ? `<div>運動: ${fromEx.map(e=>e.name).join('、')} (消費${ri(fromEx.reduce((a,e)=>a+(e.cal||0),0))}kcal)</div>` : ''}
  `;
}
function executeCopyDay() {
  const input     = document.getElementById('copyFromDate');
  const overwrite = document.getElementById('copyOverwrite')?.checked;
  const copyEx    = document.getElementById('copyExercise')?.checked;
  const msg       = document.getElementById('copyDayMsg');
  const fromDate  = input?.value;
  if (!fromDate) { if(msg){msg.className='status-msg status-err';msg.textContent='コピー元の日付を選んでください';} return; }
  if (fromDate === currentDate) { if(msg){msg.className='status-msg status-err';msg.textContent='コピー元とコピー先が同じ日付です';} return; }

  const fromEntries = entries.filter(e => e.date === fromDate);
  const fromEx      = exercises.filter(e => e.date === fromDate);
  if (!fromEntries.length && !fromEx.length) {
    if(msg){msg.className='status-msg status-err';msg.textContent='コピー元に記録がありません';}
    return;
  }

  // バックアップ
  takeAiBackup(`${dateLabel(fromDate)}→${dateLabel(currentDate)}コピー前`);

  // 食事コピー
  if (overwrite) entries = entries.filter(e => e.date !== currentDate);
  const now = Date.now();
  fromEntries.forEach((e, i) => {
    entries.push({ ...e, id: now + i, date: currentDate });
  });

  // 運動コピー
  if (copyEx) {
    if (overwrite) exercises = exercises.filter(e => e.date !== currentDate);
    fromEx.forEach((e, i) => {
      exercises.push({ ...e, id: now + 10000 + i, date: currentDate });
    });
  }

  save();
  saveExercises();
  renderRecord();
  renderCalendar();
  renderExerciseItems();

  const copied = fromEntries.length + (copyEx ? fromEx.length : 0);
  if(msg){msg.className='status-msg status-ok';msg.textContent=`✅ ${copied}件をコピーしました`;}
  setTimeout(() => closeCopyDayModal(), 1200);
}

// ── 食品登録 量クイック選択 ──
// 単位モード管理 (g / serving)
if (!window._amtUnit) window._amtUnit = {};

function setAmtUnit(meal, unit) {
  window._amtUnit[meal] = unit;
  const base = window._addBase?.[meal];
  const serving = base?.serving || base?.per || 100;

  // ボタンスタイル切り替え
  const gBtn = document.getElementById('unitG_'+meal);
  const sBtn = document.getElementById('unitS_'+meal);
  if (gBtn) {
    gBtn.style.background = unit === 'g' ? 'var(--accent)' : 'var(--bg)';
    gBtn.style.color      = unit === 'g' ? '#fff' : 'var(--text-sub)';
    gBtn.style.borderColor= unit === 'g' ? 'var(--accent)' : 'var(--border)';
  }
  if (sBtn) {
    sBtn.style.background = unit === 'serving' ? 'var(--accent)' : 'var(--bg)';
    sBtn.style.color      = unit === 'serving' ? '#fff' : 'var(--text-sub)';
    sBtn.style.borderColor= unit === 'serving' ? 'var(--accent)' : 'var(--border)';
  }

  const inp = document.getElementById('addAmt_'+meal);
  if (!inp) return;

  if (unit === 'serving') {
    inp.step = '0.5';
    inp.min  = '0.1';
    inp.value = '1';
    inp.placeholder = '人前';
  } else {
    inp.step = '1';
    inp.min  = '1';
    inp.value = serving;
    inp.placeholder = 'g';
  }
  recalcAdd(meal);
  // クイックピッカーも更新
  showAmtQuickPicker(meal, false);
}

function showAmtQuickPicker(meal, toggle = true) {
  const base    = window._addBase?.[meal];
  const cont    = document.getElementById('amtQuickPick_'+meal);
  if (!cont) return;

  const unit    = window._amtUnit?.[meal] || 'g';
  const serving = base?.serving || base?.per || 100;
  const per     = base?.per || 100;

  let buttons = [];
  if (unit === 'serving' && base?.serving) {
    // 人前モード: 0.5/1/1.5/2/3人前
    [0.5, 1, 1.5, 2, 3].forEach(n => {
      const gVal = Math.round(serving * n * 10) / 10;
      const label = n === Math.floor(n) ? `${n}人前` : `${n}人前`;
      buttons.push(`<button onclick="setAddAmtServing('${meal}',${n})"
        style="font-size:11px;padding:3px 9px;border:1px solid var(--border);border-radius:6px;
        background:${n===1?'var(--accent)':'var(--bg)'};color:${n===1?'#fff':'var(--text)'};cursor:pointer;white-space:nowrap">
        ${label}<span style="font-size:9px;opacity:.7;margin-left:3px">${gVal}g</span></button>`);
    });
  } else {
    // gモード: per値軸の選択肢
    const candidates = new Set([per]);
    [50, 100, 150, 200, 250, 300].forEach(v => candidates.add(v));
    if (serving && serving !== per) candidates.add(serving);
    if (per !== 100) [Math.round(per*0.5), Math.round(per*2)].forEach(v => v>0 && candidates.add(v));
    [...candidates].filter(v=>v>0).sort((a,b)=>a-b).forEach(v => {
      const isStar = v === (serving || per);
      buttons.push(`<button onclick="setAddAmt('${meal}',${v})"
        style="font-size:11px;padding:3px 8px;border:1px solid var(--border);border-radius:6px;
        background:${isStar?'var(--accent)':'var(--bg)'};color:${isStar?'#fff':'var(--text)'};cursor:pointer;white-space:nowrap">
        ${v}g${isStar?' ★':''}</button>`);
    });
  }

  cont.innerHTML = buttons.join('');
  if (toggle) {
    cont.style.display = cont.style.display === 'none' ? 'flex' : 'none';
  } else {
    if (cont.style.display !== 'none') cont.style.display = 'flex';
  }
}

function setAddAmtServing(meal, servings) {
  const base    = window._addBase?.[meal];
  const serving = base?.serving || base?.per || 100;
  const gVal    = Math.round(serving * servings * 10) / 10;
  const inp     = document.getElementById('addAmt_'+meal);
  if (inp) { inp.value = servings; }
  recalcAdd(meal);
}

function setAddAmt(meal, val) {
  const el = document.getElementById('addAmt_'+meal);
  if (el) { el.value = val; recalcAdd(meal); }
  const cont = document.getElementById('amtQuickPick_'+meal);
  if (cont) cont.style.display = 'none';
}


function fillAddMacros(f, amt, meal) {
  const r=amt/(f.per||100);
  const set=(id,val)=>{const el=document.getElementById(id+'_'+meal);if(el)el.value=r1(val*r)};
  set('addCal',f.cal);set('addP',f.p);set('addF',f.f);set('addC',f.c);
  set('addFib',f.fiber||0);
  { const el=document.getElementById('addFibS_'+meal); if(el){ const k=(f.fibS||0)+(f.fibI||0); el.value = (f.fiber>0 && k>0) ? r1(f.fiber*r*(f.fibS||0)/k) : ''; } }
  set('addFe',f.iron||0);set('addCa',f.calcium||0);set('addVc',f.vitc||0);set('addVd',f.vitd||0);
  const se=document.getElementById('addSalt_'+meal); if(se) se.value=r2((f.salt||0)*r);
}
function recalcAdd(meal) {
  const bn = window._addBase && window._addBase[meal]; if(!bn) return;
  const unit    = window._amtUnit?.[meal] || 'g';
  const rawVal  = parseFloat(document.getElementById('addAmt_'+meal)?.value) || 0;
  if (rawVal <= 0) return;
  const serving = bn.serving || bn.per || 100;
  const amtG    = unit === 'serving' ? rawVal * serving : rawVal;
  fillAddMacros(bn, amtG, meal);
}
// ── 重複食品のマージ登録 ──
// 同じ日付・食事区分・食品名（トリム＋大小文字無視）の記録が既にある場合は
// 新規エントリを追加せず、既存エントリへ数量・栄養価を加算する。
function normFoodName(n) { return (n || '').trim().toLowerCase().replace(/\s+/g, ''); }
function findDuplicateEntry(date, meal, name, excludeId) {
  const key = normFoodName(name);
  if (!key) return null;
  return entries.find(e =>
    e.date === date && e.meal === meal &&
    normFoodName(e.name) === key &&
    (excludeId == null || e.id !== excludeId)
  ) || null;
}
function addOrMergeEntry(newEntry, excludeId) {
  const dup = findDuplicateEntry(newEntry.date, newEntry.meal, newEntry.name, excludeId);
  if (dup) {
    dup.amount  = r1((dup.amount  || 0) + (newEntry.amount  || 0));
    dup.cal     = r1((dup.cal     || 0) + (newEntry.cal     || 0));
    dup.p       = r1((dup.p       || 0) + (newEntry.p       || 0));
    dup.f       = r1((dup.f       || 0) + (newEntry.f       || 0));
    dup.c       = r1((dup.c       || 0) + (newEntry.c       || 0));
    // 食物繊維の内訳は、合算前に双方の内訳を確定させてから足す（片方だけ内訳なしで合計とズレるのを防ぐ）
    materializeFiberSplit(dup); materializeFiberSplit(newEntry);
    MICRO_KEYS.forEach(k => { dup[k] = microRound(k, (dup[k] || 0) + (newEntry[k] || 0)); });
    if (!dup.fa && newEntry.fa) dup.fa = newEntry.fa;
    if (!dup.aa && newEntry.aa) dup.aa = newEntry.aa;
    if (!dup._fa && newEntry._fa) dup._fa = newEntry._fa;
    if (!dup.digest && newEntry.digest) dup.digest = newEntry.digest;
    // 複合食品の内訳(ingredients)は、同じ食品を同じ食事に重ねて記録した場合も失われないよう連結する
    if (newEntry.ingredients) dup.ingredients = (dup.ingredients || []).concat(newEntry.ingredients);
    return { entry: dup, merged: true };
  }
  entries.push(newEntry);
  return { entry: newEntry, merged: false };
}

function setMealTime(meal, timeVal) {
  if (!timeVal) { showToast('時刻を選択してください'); return; }
  const list = getDayEntries(currentDate).filter(e => e.meal === meal);
  if (!list.length) return;
  list.forEach(e => { e.time = timeVal; });
  save();
  renderRecord();
  showToast(`✅ ${meal}（${list.length}件）の摂取時刻を${timeVal}に設定しました`);
}
function nowTimeStr() {
  const d = new Date();
  return String(d.getHours()).padStart(2,'0') + ':' + String(d.getMinutes()).padStart(2,'0');
}
function gv(id) { return parseFloat(document.getElementById(id).value)||0; }
function addEntry(meal) {
  const nameEl=document.getElementById('addName_'+meal);
  const name=nameEl?nameEl.value.trim():'';
  const msg=document.getElementById('addMsg_'+meal);
  if(!name){
    if(msg){
      const searchVal = document.getElementById('addSearch_'+meal)?.value.trim();
      msg.className='status-msg status-err';
      msg.textContent = searchVal
        ? '検索結果からタップして選ぶか、下の「食品名」欄に手入力してください'
        : '食品名を入力してください';
    }
    return;
  }
  const newEntry = {id:Date.now(),date:currentDate,name,meal,time:nowTimeStr(),
    cal:gv('addCal_'+meal),p:gv('addP_'+meal),f:gv('addF_'+meal),c:gv('addC_'+meal),
    amount: (() => {
      const unit = window._amtUnit?.[meal] || 'g';
      const raw  = parseFloat(document.getElementById('addAmt_'+meal)?.value) || 1;
      const base = window._addBase?.[meal];
      if (unit === 'serving' && base?.serving) return Math.round(raw * base.serving * 10) / 10;
      return raw || 100;
    })(),
    fiber:gv('addFib_'+meal),...fibSplitFromInput(document.getElementById('addFibS_'+meal)?.value, gv('addFib_'+meal)),iron:gv('addFe_'+meal),calcium:gv('addCa_'+meal),vitc:gv('addVc_'+meal),vitd:gv('addVd_'+meal),salt:gv('addSalt_'+meal),
    fa: window._addBase?.[meal]?.fa || null,
    aa: window._addBase?.[meal]?.aa || null,
    _fa: window._addBase?.[meal]?.fa || null,
    digest: window._addBase?.[meal]?.digest || classifyDigestCategory(name, gv('addP_'+meal)),
  };
  // faもaaも未設定なら名前から推定
  if (!newEntry.fa || !newEntry.aa) enrichFoodProfile(newEntry);
  const { merged } = addOrMergeEntry(newEntry);
  save(); renderRecord(); renderCalendar();
  setTimeout(()=>{const m=document.getElementById('addMsg_'+meal);if(m){m.className='status-msg status-ok';m.textContent=merged?`「${name}」は既に記録済みのため数量を合算しました`:`「${name}」を追加しました`;setTimeout(()=>{if(m)m.textContent=''},2200)}},30);
}
function toggleAddPanel(meal) {
  const wasOpen = activeAddMeal === meal;
  if (wasOpen) {
    // 閉じる: 履歴を積んであればback()で消費し、実際のクローズ処理はpopstateハンドラに任せる
    // （activeAddMealをここで先にnullにしてしまうと、popstateハンドラの判定が
    //  常にfalseになり再描画が起きなくなるため、状態変更は必ず描画とセットで行う）
    if (window.history.state && window.history.state.pfcOverlay === 'addPanel') {
      try { history.back(); return; } catch(e) {}
    }
    activeAddMeal = null;
    editingId = null;
    renderRecord();
    return;
  }
  // 開く
  activeAddMeal = meal;
  _focusAddSearchMeal = meal;   // 開いた直後の1回だけ検索欄にフォーカスする
  editingId = null;
  // 端末の「戻る」操作（スワイプ／戻るボタン）でこのパネルを閉じられるよう履歴を1つ積む
  try { history.pushState({ pfcOverlay: 'addPanel' }, ''); } catch(e) {}
  renderRecord();
}
// 検索パネルを開いている状態で端末の「戻る」操作をした場合、アプリ自体を閉じずにパネルだけ閉じる
window.addEventListener('popstate', () => {
  if (activeAddMeal) {
    activeAddMeal = null;
    renderRecord();
  }
});
function startEdit(id){
  editingId=id;
  activeAddMeal=null; // 検索・食品追加パネルが開いていれば閉じる（同時に開かない）
  window._editOriginal = window._editOriginal || {};
  const src = entries.find(e => e.id === id);
  if (src) window._editOriginal[id] = {...src};
  renderRecord();
}
// 目標カロリーを起点に、PFC比を維持したまま量(g)・各栄養素を比例スケールする
function recalcEditByCal(id, val) {
  const base = window._editBase && window._editBase[id];
  const targetCal = parseFloat(val);
  if (!base || !targetCal || targetCal <= 0 || !base.cal) return;
  const ratio = targetCal / base.cal; // base.cal は amount=base.per(編集開始時の量)時点のカロリー
  const amtEl = document.getElementById('ea'+id);
  if (!amtEl) return;
  amtEl.value = r1((base.per || 100) * ratio);
  recalcEdit(id);
}
// 記録済みの複合食品エントリで、材料ごとの分量(g)を編集する。
// 変更のたびに材料の合計から量・カロリー・PFC・各ミクロ栄養素を再計算し、
// 画面を再描画せずに編集フォームの各欄とスライダー基準値だけを同期する（入力中のフォーカスを保つため）
function updateEditIngredientAmt(id, idx, val) {
  const entryIdx = entries.findIndex(e => e.id === id);
  if (entryIdx === -1) return;
  const e = entries[entryIdx];
  if (!e.ingredients || !e.ingredients[idx]) return;
  const amt = parseFloat(val);
  if (isNaN(amt) || amt < 0) return; // 空欄・入力途中は無視
  e.ingredients[idx] = { ...e.ingredients[idx], amount: amt };
  const tot = comboTotals(e.ingredients.map(ing => comboScaled(ing, ing.amount)));
  const totalAmt = e.ingredients.reduce((a, ing) => a + (ing.amount || 0), 0);
  e.amount = r1(totalAmt);
  e.cal = r1(tot.cal); e.p = r1(tot.p); e.f = r1(tot.f); e.c = r1(tot.c);
  MICRO_KEYS.forEach(k => { e[k] = microRound(k, tot[k]); });

  window._editBase = window._editBase || {};
  window._editBase[id] = {cal:e.cal,p:e.p,f:e.f,c:e.c,fiber:e.fiber||0,fibS:fibSInputVal(e),iron:e.iron||0,calcium:e.calcium||0,vitc:e.vitc||0,vitd:e.vitd||0,salt:e.salt||0,per:e.amount,
    ingredients: e.ingredients.map(ing=>({...ing}))};

  const amtEl = document.getElementById('ea'+id); if (amtEl) amtEl.value = e.amount;
  const sliderEl = document.getElementById('easlider'+id);
  if (sliderEl) { if (e.amount > parseFloat(sliderEl.max)) sliderEl.max = e.amount; sliderEl.value = e.amount; }
  const setVal = (elId, v, dec) => { const el = document.getElementById(elId+id); if (el) el.value = dec === 2 ? r2(v) : r1(v); };
  setVal('ec', e.cal); setVal('ep', e.p); setVal('ef', e.f); setVal('ecc', e.c);
  setVal('efib', e.fiber); { const el=document.getElementById('efibs'+id); if(el) el.value = fibSInputVal(e); }
  setVal('efe', e.iron); setVal('eca', e.calcium);
  setVal('evc', e.vitc); setVal('evd', e.vitd); setVal('esl', e.salt, 2);
  const totalLineEl = document.getElementById('editIngTotal'+id);
  if (totalLineEl) totalLineEl.textContent = `合計 ${ri(e.cal)}kcal P${r1(e.p)} F${r1(e.f)} C${r1(e.c)}${e.fiber ? ' 繊'+r1(e.fiber)+'g' : ''}`;
  saveDebounced();
}
// 食物繊維の合計を手で変えたら、水溶性の入力値も同じ比率でスケールしてから保存する
function fiberEdited(id) {
  const fe = document.getElementById('efib'+id), se = document.getElementById('efibs'+id);
  if (fe && se) {
    const prev = parseFloat(fe.dataset.prev) || 0, now = parseFloat(fe.value) || 0;
    if (se.value.trim() !== '' && prev > 0) se.value = r1((parseFloat(se.value) || 0) * now / prev);
    fe.dataset.prev = now;
  }
  autoSaveEdit(id);
}
function recalcEdit(id) {
  const base = window._editBase && window._editBase[id];
  if (!base) return;
  const amt = parseFloat(document.getElementById('ea'+id).value) || 0;
  if (amt <= 0) return;
  const sliderEl = document.getElementById('easlider'+id);
  if (sliderEl) {
    if (amt > parseFloat(sliderEl.max)) sliderEl.max = amt; // 大きい値を直接入力された場合はスライダーの上限を追従させる
    sliderEl.value = amt;
  }
  const r = amt / (base.per || 100);
  const set = (elId, val, dec) => {
    const el = document.getElementById(elId+id);
    if (el) el.value = dec === 2 ? r2(val*r) : r1(val*r);
  };
  set('ec', base.cal);
  set('ep', base.p);
  set('ef', base.f);
  set('ecc', base.c);
  set('efib', base.fiber);
  { const el = document.getElementById('efibs'+id); if (el) el.value = (base.fibS === '' || base.fibS == null) ? '' : r1(base.fibS * r); }
  set('efe', base.iron);
  set('eca', base.calcium);
  set('evc', base.vitc);
  set('evd', base.vitd);
  set('esl', base.salt, 2);
  // 複合食品の記録なら、全体量の変更に合わせて材料の分量(g)も同じ比率でスケールする
  // （編集を開始した時点の材料構成＝base.ingredients を常に基準にして計算し、誤差の蓄積を防ぐ）
  if (base.ingredients && base.ingredients.length) {
    const entryIdx = entries.findIndex(en => en.id === id);
    if (entryIdx !== -1 && entries[entryIdx].ingredients) {
      entries[entryIdx].ingredients = base.ingredients.map((ing, i) => ({ ...ing, amount: r1((ing.amount || 0) * r) }));
      base.ingredients.forEach((ing, i) => {
        const ingEl = document.getElementById(`eIng${id}_${i}`);
        if (ingEl) ingEl.value = r1((ing.amount || 0) * r);
      });
      const totalLineEl = document.getElementById('editIngTotal'+id);
      if (totalLineEl) totalLineEl.textContent = `合計 ${ri(base.cal*r)}kcal P${r1(base.p*r)} F${r1(base.f*r)} C${r1(base.c*r)}${base.fiber ? ' 繊'+r1(base.fiber*r)+'g' : ''}`;
    }
  }
  autoSaveEdit(id);
}
// 保存ボタンを押さなくても、編集中の内容を都度バックグラウンドで確定させる
// （画面の再描画はしない＝入力中のフォーカスやカーソル位置を崩さないため）
function autoSaveEdit(id) {
  const idx = entries.findIndex(e => e.id === id);
  if (idx === -1) return;
  const nameEl = document.getElementById('en'+id);
  const amtEl  = document.getElementById('ea'+id);
  if (!nameEl || !amtEl) return;
  const _oldEntry = entries[idx];
  const _newEntry = {
    ...entries[idx],
    name:    nameEl.value.trim() || entries[idx].name,
    amount:  parseFloat(amtEl.value) || entries[idx].amount,
    cal:     parseFloat(document.getElementById('ec'+id).value) || 0,
    p:       parseFloat(document.getElementById('ep'+id).value) || 0,
    f:       parseFloat(document.getElementById('ef'+id).value) || 0,
    c:       parseFloat(document.getElementById('ecc'+id).value) || 0,
    fiber:   parseFloat(document.getElementById('efib'+id).value) || 0,
    iron:    parseFloat(document.getElementById('efe'+id).value) || 0,
    calcium: parseFloat(document.getElementById('eca'+id).value) || 0,
    vitc:    parseFloat(document.getElementById('evc'+id).value) || 0,
    vitd:    parseFloat(document.getElementById('evd'+id).value) || 0,
    salt:    parseFloat(document.getElementById('esl'+id).value) || 0,
    meal:    document.getElementById('em'+id).value,
    time:    document.getElementById('et'+id)?.value || entries[idx].time,
  };
  syncFiberSplit(_oldEntry, _newEntry); // 食物繊維の量が変わった場合は内訳も同じ比率でスケール
  // 水溶性の入力欄に値があればそれを優先（不溶性＝食物繊維−水溶性）。空欄なら自動のまま
  const _fsEl = document.getElementById('efibs'+id);
  if (_fsEl && _fsEl.value.trim() !== '') { const sp = fibSplitFromInput(_fsEl.value, _newEntry.fiber); if (sp.fibS != null) Object.assign(_newEntry, sp); }
  entries[idx] = _newEntry;
  saveDebounced();
}
function cancelEdit(id){
  // オートセーブ済みの変更を、編集開始前の状態に戻す
  if (id != null && window._editOriginal && window._editOriginal[id]) {
    const idx = entries.findIndex(e => e.id === id);
    if (idx !== -1) entries[idx] = window._editOriginal[id];
    save();
  }
  if (window._editBase) window._editBase = {};
  if (window._editOriginal && id != null) delete window._editOriginal[id];
  editingId = null;
  renderRecord();
}
function saveEdit(id) {
  autoSaveEdit(id);
  if (window._editOriginal) delete window._editOriginal[id];
  save(); editingId=null; renderRecord(); renderCalendar();
}
function deleteEntry(id){
  const idx = entries.findIndex(e=>e.id===id);
  if (idx === -1) return;
  const removed = entries[idx];
  entries.splice(idx,1);
  if(editingId===id)editingId=null;
  save();renderRecord();renderCalendar();
  showUndoToast(`「${removed.name}」を削除しました`, () => {
    entries.splice(Math.min(idx, entries.length), 0, removed);
    save(); renderRecord(); renderCalendar();
  });
}

// ── Exercise ──
const EXERCISE_TYPES = {
  '3.5': 'ウォーキング',
  '7.0': 'ジョギング',
  '8.0': 'ランニング',
  '6.0': 'サイクリング',
  '8.0s': '水泳',
  '4.5': '筋トレ',
  '3.0': 'ヨガ・ストレッチ',
  '6.0b': 'バドミントン',
  '7.0t': 'テニス',
  '0': 'その他',
};

function toggleExercisePanel() {
  exPanelOpen = !exPanelOpen;
  const panel = document.getElementById('exerciseAddPanel');
  const btn   = document.getElementById('exAddBtn');
  if (panel) panel.style.display = exPanelOpen ? 'block' : 'none';
  if (btn)   btn.textContent      = exPanelOpen ? '✕ 閉じる' : '＋ 追加';
  if (exPanelOpen) onExTypeChange();
}

function onExTypeChange() {
  const sel = document.getElementById('exType');
  const manualRow = document.getElementById('exManualRow');
  if (!sel || !manualRow) return;
  manualRow.style.display = sel.value === '0' ? 'flex' : 'none';
}

function addExercise() {
  const sel  = document.getElementById('exType');
  const mins = parseFloat(document.getElementById('exMinutes').value) || 0;
  const msg  = document.getElementById('exMsg');

  if (!sel) return;
  const mets = parseFloat(sel.value);
  const isManual = sel.value === '0';

  let burnedCal = 0;
  let exName    = '';

  if (isManual) {
    burnedCal = parseFloat(document.getElementById('exManualCal').value) || 0;
    exName    = (document.getElementById('exManualName').value || '').trim() || 'その他';
  } else {
    if (mins <= 0) {
      if (msg) { msg.className='status-msg status-err'; msg.textContent='時間を入力してください'; }
      return;
    }
    // 消費カロリー = METs × 体重(kg) × 時間(h)
    const weight = profile.weight || userWeight || 65;
    burnedCal = r1(mets * weight * (mins / 60));
    // select の表示テキストから種目名を取得
    exName = sel.options[sel.selectedIndex].text.replace(/（.*）/, '').trim();
  }

  if (burnedCal <= 0) {
    if (msg) { msg.className='status-msg status-err'; msg.textContent='消費カロリーを入力してください'; }
    return;
  }

  exercises.push({
    id: Date.now(),
    date: currentDate,
    name: exName,
    minutes: mins,
    cal: burnedCal,
  });
  saveExercises();
  renderExerciseItems();

  // フォームリセット
  document.getElementById('exMinutes').value = '30';
  const manualCal  = document.getElementById('exManualCal');
  const manualName = document.getElementById('exManualName');
  if (manualCal)  manualCal.value  = '';
  if (manualName) manualName.value = '';

  if (msg) {
    msg.className = 'status-msg status-ok';
    msg.textContent = `「${exName}」を追加しました（${burnedCal} kcal）`;
    setTimeout(() => { if (msg) msg.textContent = ''; }, 2000);
  }
}

function deleteExercise(id) {
  const idx = exercises.findIndex(e => e.id === id);
  if (idx === -1) return;
  const removed = exercises[idx];
  exercises.splice(idx, 1);
  saveExercises();
  renderExerciseItems();
  showUndoToast(`「${removed.name}」を削除しました`, () => {
    exercises.splice(Math.min(idx, exercises.length), 0, removed);
    saveExercises(); renderExerciseItems();
  });
}

function renderExerciseItems() {
  const dayEx  = exercises.filter(e => e.date === currentDate);
  const items  = document.getElementById('exerciseItems');
  const sub    = document.getElementById('exerciseSub');
  const totalCal = dayEx.reduce((a, e) => a + (e.cal || 0), 0);

  if (sub) sub.textContent = dayEx.length ? `${ri(totalCal)} kcal 消費` : '未記録';

  if (!items) return;
  if (!dayEx.length) { items.innerHTML = ''; return; }

  items.innerHTML = `<div class="meal-items">${
    dayEx.map(e =>
      `<div class="log-item">
        <div>
          <div class="li-name">${e.name}</div>
          <div class="li-detail">${e.minutes ? e.minutes + '分' : ''}　消費 ${ri(e.cal)} kcal</div>
        </div>
        <div class="li-right">
          <div class="li-cal" style="color:#e91e63">${ri(e.cal)}</div>
          <button class="btn btn-sm btn-danger" onclick="deleteExercise(${e.id})" style="padding:6px 10px">✕</button>
        </div>
      </div>`
    ).join('')
  }</div>`;
}

// ── Copy ──
function renderCopyPanel() {
  const filter=document.getElementById('copyFilter').value;
  const days=[...new Set(entries.map(e=>e.date))].filter(d=>d!==currentDate).sort((a,b)=>b.localeCompare(a)).slice(0,14);
  const cont=document.getElementById('copyPanel');
  if(!days.length){cont.innerHTML=`<div style="font-size:12px;color:var(--text-sub);padding:8px 0">記録がありません</div>`;return}
  let html='';
  days.forEach(d=>{
    const grouped={};MEALS_ORDER.forEach(m=>{grouped[m]=[]});
    getDayEntries(d).filter(e=>!filter||e.meal===filter).forEach(e=>{(grouped[e.meal]||grouped['間食']).push(e)});
    MEALS_ORDER.forEach(meal=>{
      const mitems=grouped[meal];if(!mitems||!mitems.length||(filter&&meal!==filter))return;
      const ms=sumEntries(mitems);
      html+=`<div class="copy-item"><div class="ci-header"><span class="ci-title">${fmtDate(d)} — ${meal}（${ri(ms.cal)}kcal）</span><button class="btn btn-sm btn-primary" onclick="copyMeal('${d}','${meal}')">コピー</button></div>${mitems.map(e=>`<div class="ci-food">${e.name}（${e.amount}g）${ri(e.cal)}kcal</div>`).join('')}</div>`;
    });
  });
  cont.innerHTML=html||`<div style="font-size:12px;color:var(--text-sub);padding:8px 0">該当なし</div>`;
}
function copyMeal(date, meal) {
  const target=document.getElementById('copyTarget').value;
  getDayEntries(date).filter(e=>e.meal===meal).forEach(e=>entries.push({...e,id:Date.now()+Math.random(),date:currentDate,meal:target}));
  save(); renderRecord(); renderCalendar();
}

// ── Stats ──
// ── 食品プロファイル自動付与 ──
// AI・手動登録食品に fa/aa を自動推定して付与する
const AA_PROFILES_MAP = {
  whey:    {leu:.11,ile:.07,val:.06,lys:.10,met:.02,thr:.07,trp:.02,his:.02,score:1.09},
  egg:     {leu:.09,ile:.06,val:.07,lys:.09,met:.03,thr:.06,trp:.02,his:.03,score:1.13},
  chicken: {leu:.09,ile:.05,val:.05,lys:.10,met:.03,thr:.05,trp:.01,his:.03,score:1.08},
  beef:    {leu:.09,ile:.05,val:.05,lys:.09,met:.03,thr:.05,trp:.01,his:.03,score:1.00},
  pork:    {leu:.09,ile:.05,val:.05,lys:.09,met:.03,thr:.05,trp:.01,his:.03,score:0.98},
  fish:    {leu:.09,ile:.05,val:.05,lys:.10,met:.03,thr:.05,trp:.01,his:.03,score:1.00},
  milk:    {leu:.10,ile:.06,val:.07,lys:.08,met:.03,thr:.05,trp:.01,his:.03,score:1.22},
  casein:  {leu:.09,ile:.06,val:.06,lys:.08,met:.03,thr:.04,trp:.01,his:.03,score:1.07},
  soy:     {leu:.08,ile:.05,val:.05,lys:.07,met:.01,thr:.04,trp:.01,his:.03,score:0.91},
  wheat:   {leu:.07,ile:.04,val:.04,lys:.02,met:.02,thr:.03,trp:.01,his:.02,score:0.45},
  rice:    {leu:.08,ile:.04,val:.05,lys:.04,met:.02,thr:.04,trp:.01,his:.02,score:0.59},
  legume:  {leu:.08,ile:.05,val:.05,lys:.07,met:.01,thr:.04,trp:.01,his:.03,score:0.72},
  nut:     {leu:.07,ile:.04,val:.05,lys:.03,met:.02,thr:.03,trp:.01,his:.03,score:0.40},
  mixed:   {leu:.08,ile:.05,val:.05,lys:.06,met:.02,thr:.04,trp:.01,his:.03,score:0.75},
};
const AA_PAT_MAP = [
  [/ホエイ|whey|WPC|WPI/i,                                          'whey'],
  [/カゼイン|casein/i,                                               'casein'],
  [/卵|たまご|タマゴ|目玉焼き|ゆで卵|スクランブル|玉子|オムレツ/i,  'egg'],
  [/鶏|チキン|ささみ|焼き鳥|唐揚げ|から揚げ|ファミチキ/i,           'chicken'],
  [/牛|ビーフ|ハンバーグ|牛丼|ワッパー/i,                           'beef'],
  [/豚|ポーク|とんかつ|メンチ|ウインナー|ソーセージ|ベーコン|ハム|餃子|シュウマイ/i, 'pork'],
  [/さば|さんま|いわし|まぐろ|マグロ|ツナ|鮭|サーモン|あじ|ぶり|えび|いか|ほたて|あさり|カニ|シーフード/i, 'fish'],
  [/牛乳|ミルク|ヨーグルト|チーズ|乳/i,                             'milk'],
  [/豆腐|納豆|豆乳|大豆|えだまめ|きな粉/i,                          'soy'],
  [/ご飯|白米|玄米|おにぎり|寿司|チャーハン/i,                      'rice'],
  [/パン|うどん|パスタ|スパゲッティ|ラーメン|そば|麺|ピザ|クッキー/i,'wheat'],
  [/レンズ豆|ひよこ豆|黒豆|インゲン|あずき/i,                       'legume'],
  [/アーモンド|くるみ|ピーナッツ|ナッツ|ごま/i,                     'nut'],
];
const FA_PAT_MAP = [
  [/米油/i,                    {sat:.17,mufa:.42,n3:.01,n6:.35,trans:.01}],
  [/オリーブ/i,                {sat:.14,mufa:.74,n3:.01,n6:.10,trans:.00}],
  [/ごま油/i,                  {sat:.15,mufa:.39,n3:.00,n6:.43,trans:.00}],
  [/えごま|亜麻仁/i,           {sat:.09,mufa:.19,n3:.57,n6:.14,trans:.00}],
  [/バター/i,                  {sat:.63,mufa:.27,n3:.01,n6:.03,trans:.04}],
  [/マーガリン/i,              {sat:.22,mufa:.44,n3:.06,n6:.24,trans:.04}],
  [/マヨネーズ/i,              {sat:.12,mufa:.35,n3:.06,n6:.44,trans:.01}],
  [/サラダ油|キャノーラ|菜種/i,{sat:.15,mufa:.29,n3:.07,n6:.47,trans:.00}],
  [/さば|鯖/i,                 {sat:.25,mufa:.29,n3:.31,n6:.04,trans:.00}],
  [/さんま/i,                  {sat:.22,mufa:.42,n3:.22,n6:.03,trans:.00}],
  [/いわし|オイルサーディン/i, {sat:.25,mufa:.27,n3:.31,n6:.05,trans:.00}],
  [/まぐろ|マグロ|ツナ/i,      {sat:.28,mufa:.18,n3:.38,n6:.05,trans:.00}],
  [/鮭|サーモン/i,             {sat:.22,mufa:.32,n3:.32,n6:.08,trans:.00}],
  [/ぶり/i,                    {sat:.24,mufa:.39,n3:.21,n6:.06,trans:.00}],
  [/えび|いか/i,               {sat:.30,mufa:.18,n3:.28,n6:.10,trans:.00}],
  [/ほたて|あさり|カニ/i,      {sat:.28,mufa:.24,n3:.24,n6:.08,trans:.00}],
  [/鶏もも|唐揚げ|から揚げ|焼き鳥/i,{sat:.31,mufa:.44,n3:.03,n6:.18,trans:.01}],
  [/鶏むね|ささみ|サラダチキン/i,    {sat:.28,mufa:.40,n3:.02,n6:.22,trans:.01}],
  [/豚|ポーク|とんかつ|ベーコン|ハム|ウインナー|ソーセージ|餃子/i, {sat:.38,mufa:.46,n3:.01,n6:.12,trans:.01}],
  [/牛|ビーフ|ハンバーグ/i,    {sat:.47,mufa:.43,n3:.01,n6:.05,trans:.02}],
  [/卵|たまご|目玉焼き|ゆで卵|スクランブル/i, {sat:.30,mufa:.42,n3:.03,n6:.19,trans:.01}],
  [/牛乳|ミルク/i,             {sat:.62,mufa:.28,n3:.01,n6:.02,trans:.03}],
  [/チーズ/i,                  {sat:.63,mufa:.27,n3:.01,n6:.02,trans:.03}],
  [/ヨーグルト/i,              {sat:.60,mufa:.30,n3:.01,n6:.03,trans:.02}],
  [/豆腐|納豆|豆乳|大豆/i,     {sat:.14,mufa:.24,n3:.07,n6:.52,trans:.00}],
  [/くるみ/i,                  {sat:.08,mufa:.15,n3:.13,n6:.58,trans:.00}],
  [/アーモンド/i,              {sat:.08,mufa:.66,n3:.00,n6:.22,trans:.00}],
  [/ピーナッツ/i,              {sat:.17,mufa:.46,n3:.00,n6:.32,trans:.00}],
  [/ごま（炒り）/i,            {sat:.15,mufa:.38,n3:.00,n6:.42,trans:.00}],
  [/プロテイン/i,              {sat:.20,mufa:.28,n3:.04,n6:.16,trans:.01}],
  [/天ぷら|フライ|揚げ|コロッケ|たこ焼き/i, {sat:.20,mufa:.32,n3:.05,n6:.38,trans:.01}],
  [/バーガー|マクドナルド|KFC|ポテト/i,      {sat:.32,mufa:.38,n3:.03,n6:.22,trans:.02}],
  [/ピザ/i,                    {sat:.35,mufa:.35,n3:.02,n6:.20,trans:.02}],
  [/カレー/i,                  {sat:.30,mufa:.35,n3:.03,n6:.25,trans:.01}],
  [/ラーメン|パスタ|うどん|そば|焼きそば/i, {sat:.25,mufa:.30,n3:.04,n6:.30,trans:.01}],
];

// 食品名から fa/aa を推定して付与
function enrichFoodProfile(entry) {
  const name = entry.name || '';
  // digest 推定
  if (!entry.digest) {
    entry.digest = classifyDigestCategory(name, entry.p || 0);
  }
  // fa 推定
  if (!entry.fa && (entry.f || 0) >= 0.5) {
    for (const [pat, prof] of FA_PAT_MAP) {
      if (pat.test(name)) { entry.fa = prof; break; }
    }
  }
  // aa 推定（タンパク質1g以上）
  if (!entry.aa && (entry.p || 0) >= 1.0) {
    let aaKey = 'mixed';
    for (const [pat, key] of AA_PAT_MAP) {
      if (pat.test(name)) { aaKey = key; break; }
    }
    entry.aa = AA_PROFILES_MAP[aaKey];
  }
  return entry;
}


// 各カテゴリの脂肪酸比率（脂質g全体に対する割合）
// sat=飽和, mufa=一価不飽和(ω9主体), pufa_n3=ω3, pufa_n6=ω6, pufa_n9=ω9(リノレイン酸以外の一価)
// 参考: 日本食品標準成分表2020 脂肪酸組成
const FATTY_ACID_PROFILES = [
  // ── 油脂類 ──
  { pat:/米油|こめあぶら/i,          label:'米油',         sat:.17, mufa:.42, n3:.01, n6:.35, n9:.04, trans:.01 },
  { pat:/オリーブ|olive/i,           label:'オリーブ油',   sat:.14, mufa:.74, n3:.01, n6:.10, n9:.00, trans:.00 },
  { pat:/ごま油|セサミ|sesame/i,     label:'ごま油',       sat:.15, mufa:.39, n3:.00, n6:.43, n9:.02, trans:.00 },
  { pat:/サラダ油|大豆油|キャノーラ|菜種/i, label:'サラダ油', sat:.15, mufa:.29, n3:.07, n6:.47, n9:.02, trans:.00 },
  { pat:/バター|butter/i,            label:'バター',       sat:.63, mufa:.27, n3:.01, n6:.03, n9:.01, trans:.04 },
  { pat:/マーガリン|margarine/i,     label:'マーガリン',   sat:.22, mufa:.44, n3:.06, n6:.24, n9:.00, trans:.04 },
  { pat:/ラード|豚脂/i,              label:'ラード',       sat:.39, mufa:.45, n3:.00, n6:.11, n9:.05, trans:.00 },
  { pat:/ヘット|牛脂/i,              label:'牛脂',         sat:.51, mufa:.43, n3:.01, n6:.03, n9:.01, trans:.01 },
  { pat:/ココナッツ|coconut/i,       label:'ココナッツ油', sat:.88, mufa:.06, n3:.00, n6:.02, n9:.04, trans:.00 },
  { pat:/えごま|亜麻|フラックス|linseed|flax/i, label:'えごま油', sat:.09, mufa:.19, n3:.57, n6:.14, n9:.01, trans:.00 },
  { pat:/くるみ|ウォールナッツ|walnut/i, label:'くるみ',  sat:.08, mufa:.15, n3:.13, n6:.58, n9:.06, trans:.00 },
  { pat:/アーモンド|almond/i,        label:'アーモンド',   sat:.08, mufa:.66, n3:.00, n6:.22, n9:.04, trans:.00 },
  // ── 魚類（EPA/DHA豊富 → ω3高） ──
  { pat:/さば|鯖|mackerel/i,         label:'さば',         sat:.25, mufa:.29, n3:.31, n6:.04, n9:.09, trans:.00 },
  { pat:/さんま|秋刀魚/i,            label:'さんま',       sat:.22, mufa:.42, n3:.22, n6:.03, n9:.09, trans:.00 },
  { pat:/いわし|鰯|sardine/i,        label:'いわし',       sat:.25, mufa:.27, n3:.31, n6:.05, n9:.10, trans:.00 },
  { pat:/まぐろ|マグロ|ツナ|tuna/i,  label:'まぐろ',       sat:.28, mufa:.18, n3:.38, n6:.05, n9:.08, trans:.00 },
  { pat:/鮭|さけ|サーモン|salmon/i,  label:'鮭',           sat:.22, mufa:.32, n3:.32, n6:.08, n9:.04, trans:.00 },
  { pat:/ぶり|鰤|yellowtail/i,       label:'ぶり',         sat:.24, mufa:.39, n3:.21, n6:.06, n9:.08, trans:.00 },
  { pat:/えび|海老|shrimp/i,         label:'えび',         sat:.30, mufa:.18, n3:.28, n6:.10, n9:.12, trans:.00 },
  { pat:/いか|烏賊|squid/i,          label:'いか',         sat:.31, mufa:.22, n3:.26, n6:.07, n9:.12, trans:.00 },
  // ── 肉類 ──
  { pat:/鶏もも|鶏モモ/i,            label:'鶏もも',       sat:.31, mufa:.44, n3:.03, n6:.18, n9:.03, trans:.01 },
  { pat:/鶏むね|鶏胸|ささみ|チキン|chicken/i, label:'鶏むね', sat:.28, mufa:.40, n3:.02, n6:.22, n9:.06, trans:.01 },
  { pat:/豚ロース|豚バラ|豚ひき|ポーク|pork/i, label:'豚肉', sat:.38, mufa:.46, n3:.01, n6:.12, n9:.02, trans:.01 },
  { pat:/牛ロース|牛バラ|牛ひき|ビーフ|beef/i, label:'牛肉', sat:.47, mufa:.43, n3:.01, n6:.05, n9:.02, trans:.02 },
  { pat:/ベーコン|ハム|ソーセージ|ウインナー/i, label:'加工肉', sat:.36, mufa:.44, n3:.01, n6:.12, n9:.03, trans:.02 },
  // ── 卵・乳製品 ──
  { pat:/卵|たまご|タマゴ|egg/i,      label:'卵',           sat:.30, mufa:.42, n3:.03, n6:.19, n9:.04, trans:.01 },
  { pat:/牛乳|ミルク|milk/i,          label:'牛乳',         sat:.62, mufa:.28, n3:.01, n6:.02, n9:.05, trans:.03 },
  { pat:/チーズ|cheese/i,             label:'チーズ',       sat:.63, mufa:.27, n3:.01, n6:.02, n9:.03, trans:.03 },
  { pat:/ヨーグルト|yogurt/i,         label:'ヨーグルト',   sat:.60, mufa:.30, n3:.01, n6:.03, n9:.04, trans:.02 },
  // ── 大豆・ナッツ ──
  { pat:/豆腐|とうふ|大豆|soy|tofu/i, label:'大豆製品',    sat:.14, mufa:.24, n3:.07, n6:.52, n9:.03, trans:.00 },
  { pat:/納豆/i,                       label:'納豆',         sat:.13, mufa:.22, n3:.07, n6:.54, n9:.04, trans:.00 },
  // ── デフォルト（分類不明） ──
];
// デフォルト（日本の食事平均的な脂肪酸比率）
const FA_DEFAULT = { sat:.30, mufa:.35, n3:.04, n6:.26, n9:.04, trans:.01 };

const FA_GOALS = {
  sat:  { label:'飽和脂肪酸',    short:'飽和',   color:'#e57373', ideal:'〜30%', goodFn: v => v <= 30 },
  mufa: { label:'一価不飽和(ω9)',short:'ω9/MUFA',color:'#81c784', ideal:'35〜45%', goodFn: v => v >= 30 && v <= 50 },
  n3:   { label:'多価不飽和 ω3', short:'ω3',     color:'#64b5f6', ideal:'5〜10%', goodFn: v => v >= 3 && v <= 15 },
  n6:   { label:'多価不飽和 ω6', short:'ω6',     color:'#ffb74d', ideal:'25〜40%', goodFn: v => v >= 15 && v <= 45 },
  trans:{ label:'トランス脂肪酸',short:'トランス',color:'#ef9a9a', ideal:'〜1%',  goodFn: v => v <= 1 },
};

function classifyFattyAcid(name) {
  for (const prof of FATTY_ACID_PROFILES) {
    if (prof.pat.test(name)) return prof;
  }
  return null;
}

function calcFattyAcids(list) {
  const totals = { sat:0, mufa:0, n3:0, n6:0, trans:0 };
  let totalFat = 0;

  list.forEach(e => {
    const fatG = e.f || 0;
    if (fatG < 0.5) return; // 脂質0.5g未満スキップ
    totalFat += fatG;

    // ① エントリに直接faフィールドがある場合（LOCAL_DB紐付き）優先
    let prof = e._fa || null;

    // ② パターンマッチ（手動入力・カスタム食品）
    if (!prof) {
      for (const p of FATTY_ACID_PROFILES) {
        if (p.pat.test(e.name)) { prof = p; break; }
      }
    }
    if (!prof) prof = FA_DEFAULT;

    totals.sat   += fatG * (prof.sat   || 0);
    totals.mufa  += fatG * (prof.mufa  || 0);
    totals.n3    += fatG * (prof.n3    || 0);
    totals.n6    += fatG * (prof.n6    || 0);
    totals.trans += fatG * (prof.trans || 0);
  });

  if (totalFat < 0.5) return null;

  const pct = {};
  Object.keys(totals).forEach(k => { pct[k] = r1(totals[k] / totalFat * 100); });
  const n3n6ratio = totals.n6 > 0 ? r1(totals.n3 / totals.n6) : 0;
  const abs = {};
  return { pct, abs, totalFat: r1(totalFat), n3n6ratio };
}

function renderFattyAcidPanel(list) {
  const el = document.getElementById('fattyAcidPanel');
  if (!el) return;

  // 脂質0.5g未満の食品をスキップ理由として記録
  const skipped = list.filter(e => (e.f || 0) < 0.5).map(e => e.name);
  const data = calcFattyAcids(list);

  if (!data || data.totalFat < 0.5) {
    el.innerHTML = '<div style="font-size:12px;color:var(--text-sub);padding:4px 0">脂質の記録が少ないため推定できません（目安: 5g以上）</div>';
    return;
  }

  const { pct, abs, totalFat, n3n6ratio } = data;

  // DB紐付き件数 / パターンマッチ件数 / デフォルト件数をカウント
  let dbCount = 0, patCount = 0, defCount = 0;
  list.forEach(e => {
    if ((e.f || 0) < 0.5) return;
    if (e._fa) dbCount++;
    else {
      let matched = false;
      for (const p of FATTY_ACID_PROFILES) { if (p.pat.test(e.name)) { matched = true; break; } }
      if (matched) patCount++; else defCount++;
    }
  });

  const bars = ['sat','mufa','n3','n6','trans'].map(k => {
    const g    = FA_GOALS[k];
    const v    = pct[k];
    const good = g.goodFn(v);
    const barW = Math.min(v, 80);
    return `
      <div style="margin-bottom:7px">
        <div style="display:flex;justify-content:space-between;align-items:baseline;margin-bottom:3px">
          <span style="font-size:11px;font-weight:600">${g.label}</span>
          <span style="display:flex;align-items:baseline;gap:5px">
            <span style="font-size:13px;font-weight:700;color:${good ? 'var(--green)' : 'var(--amber)'}">${v}%</span>
            <span style="font-size:10px;color:var(--text-sub)">${abs[k]}g</span>
            <span style="font-size:9px;color:var(--text-sub)">目標${g.ideal}</span>
            <span style="font-size:11px">${good ? '✓' : '△'}</span>
          </span>
        </div>
        <div style="height:8px;border-radius:4px;background:var(--border);overflow:hidden">
          <div style="height:100%;border-radius:4px;width:${barW}%;background:${g.color};transition:width .5s cubic-bezier(.4,0,.2,1)"></div>
        </div>
      </div>`;
  }).join('');

  const ratioColor   = n3n6ratio >= 0.2 ? 'var(--green)' : n3n6ratio >= 0.1 ? 'var(--amber)' : 'var(--red)';
  const ratioComment = n3n6ratio >= 0.25
    ? '理想的なバランスです'
    : n3n6ratio >= 0.1
    ? 'ω3をもう少し増やすと◎（青魚・えごま油など）'
    : 'ω6過多です。ω3源（青魚・亜麻仁・くるみ）を意識して摂りましょう';

  // 精度インジケーター
  const total = dbCount + patCount + defCount || 1;
  const accuracy = Math.round((dbCount + patCount) / total * 100);
  const accColor = accuracy >= 80 ? 'var(--green)' : accuracy >= 50 ? 'var(--amber)' : 'var(--red)';

  el.innerHTML = `
    <div style="background:var(--surface2);border:1px solid var(--border);border-radius:var(--radius-sm);padding:11px 12px">
      <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:8px;flex-wrap:wrap;gap:4px">
        <div style="font-size:10px;color:var(--text-sub)">脂質総量 ${totalFat}g を分析</div>
        <div style="display:flex;gap:4px;font-size:9px;flex-wrap:wrap">
          ${dbCount > 0 ? `<span style="background:var(--green-light);color:var(--green);border-radius:4px;padding:1px 5px;font-weight:600">DB紐付き ${dbCount}品</span>` : ''}
          ${patCount > 0 ? `<span style="background:var(--accent-light);color:var(--accent);border-radius:4px;padding:1px 5px;font-weight:600">パターン ${patCount}品</span>` : ''}
          ${defCount > 0 ? `<span style="background:var(--amber-light);color:#c67c00;border-radius:4px;padding:1px 5px;font-weight:600">推定平均 ${defCount}品</span>` : ''}
          <span style="background:var(--surface);border:1px solid var(--border);border-radius:4px;padding:1px 5px;color:${accColor};font-weight:600">精度 ${accuracy}%</span>
        </div>
      </div>
      ${bars}
      <div style="margin-top:10px;padding:9px 11px;background:var(--surface);border-radius:8px;border:1px solid var(--border)">
        <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:4px">
          <span style="font-size:11px;font-weight:600">ω3 : ω6 比率</span>
          <span style="font-size:15px;font-weight:700;color:${ratioColor}">1 : ${n3n6ratio > 0 ? r1(1/n3n6ratio) : '∞'}</span>
        </div>
        <div style="font-size:11px;color:var(--text-sub)">${ratioComment}</div>
        <div style="font-size:10px;color:var(--text-muted);margin-top:3px">理想比率: ω3:ω6 = 1:4〜1:5 程度</div>
      </div>
      ${skipped.length ? `<div style="font-size:10px;color:var(--text-muted);margin-top:6px">脂質0.5g未満のためスキップ: ${skipped.slice(0,5).join('、')}${skipped.length > 5 ? '…他' : ''}</div>` : ''}
      <div style="font-size:10px;color:var(--text-sub);margin-top:8px;line-height:1.6;padding-top:6px;border-top:1px solid var(--border)">
        ⚠ 食品名・DB紐付きからの推定値です。調理法・産地・ブランドにより実際の比率は異なります。
      </div>
    </div>`;
}



// ── 体重ログ（バーチャル体重計） ──
// 体重をあまり量らない前提で、専用の入力UIは増やさず、設定画面の「体重」欄を実際に変更した
// タイミングだけを実測アンカーとして記録する（recordWeightLogEntry参照）。
// 代謝変動推定・体脂肪変化の各機能は、このログから求めた「推定体重」を使う。
function recordWeightLogEntry(dateStr, weightVal) {
  if (!isFinite(weightVal) || weightVal <= 0) return;
  profile.weightLog = profile.weightLog || [];
  const idx = profile.weightLog.findIndex(w => w.date === dateStr);
  if (idx >= 0) profile.weightLog[idx].weight = weightVal;
  else profile.weightLog.push({ date: dateStr, weight: weightVal });
  profile.weightLog.sort((a, b) => a.date < b.date ? -1 : (a.date > b.date ? 1 : 0));
  if (profile.weightLog.length > 500) profile.weightLog = profile.weightLog.slice(-500); // 万一の肥大化対策
}
function weightLogSorted() { return (profile.weightLog || []).slice(); } // 常にソート済みで保持しているのでそのまま返す
// 体重変化のうち脂肪1kg=7200kcal・筋肉(除脂肪)1kg=4500kcalとして、体組成モードからkcal/kgを決める
// （代謝変動推定カードの「体組成モード」設定をそのまま共用する）
function kcalPerKgForEstimate() {
  if (metaCompMode === 'fat') return 7200;
  if (metaCompMode === 'mixed') return (7200 + 4500) / 2;
  const fatRatio = (parseInt(document.getElementById('metaFatRatio')?.value) || 100) / 100;
  return 7200 * fatRatio + 4500 * (1 - fatRatio);
}
// [fromDate, toDate] 区間・両端の体重(fromW→toW)から、その区間の実効TDEEを逆算する
// （記録のある日だけを使う。記録が1日も無ければ計算式のTDEEにフォールバック）
function actualTdeeBetween(fromDate, toDate, fromW, toW) {
  const dates = []; let d = new Date(fromDate + 'T00:00:00'); const end = new Date(toDate + 'T00:00:00');
  while (d <= end) { dates.push(toDateStr(d)); d.setDate(d.getDate() + 1); }
  const recorded = dates.filter(ds => getDayEntries(ds).length);
  if (!recorded.length) return calcTDEE();
  const avgCal = recorded.reduce((s, ds) => s + sumEntries(getDayEntries(ds)).cal, 0) / recorded.length;
  const kcalPerKg = kcalPerKgForEstimate();
  return avgCal - (toW - fromW) * kcalPerKg / recorded.length;
}
// 指定日の推定体重（＝バーチャル体重計）。
// ・実測ログが無ければ設定中の体重をそのまま返す（従来と同じ、推定のしようがない）
// ・実測アンカーの間は、その区間で逆算した実効TDEEを使ってカロリー収支を積み上げて補間する
// ・最後の実測より後（今日を含む）は、直前の区間で分かっている実効TDEE（無ければ計算式のTDEE）で延長する
function estimateWeightOnDate(dateStr) {
  const log = weightLogSorted();
  if (!log.length) return profile.weight || null;
  const exact = log.find(w => w.date === dateStr);
  if (exact) return exact.weight;
  if (log.length === 1 || dateStr <= log[0].date) return log[0].weight;
  const last = log[log.length - 1];
  let lo, hi, tdee;
  if (dateStr <= last.date) {
    lo = log[0]; hi = last;
    for (let i = 0; i < log.length - 1; i++) { if (dateStr >= log[i].date && dateStr <= log[i+1].date) { lo = log[i]; hi = log[i+1]; break; } }
    tdee = actualTdeeBetween(lo.date, hi.date, lo.weight, hi.weight);
  } else {
    hi = last; const prev = log.length >= 2 ? log[log.length - 2] : last;
    tdee = log.length >= 2 ? actualTdeeBetween(prev.date, hi.date, prev.weight, hi.weight) : calcTDEE();
    lo = last; // 延長は最後の実測地点を起点にする
  }
  const kcalPerKg = kcalPerKgForEstimate();
  let d = new Date(lo.date + 'T00:00:00'); const target = new Date(dateStr + 'T00:00:00');
  let balance = 0;
  while (d < target) {
    const ds = toDateStr(d);
    const es = getDayEntries(ds);
    const intake = es.length ? sumEntries(es).cal : tdee; // 記録の無い日はTDEE通り食べたとみなす（収支0）
    balance += intake - tdee;
    d.setDate(d.getDate() + 1);
  }
  return r1(lo.weight + balance / kcalPerKg);
}
// その日の体重が実測（ログにその日付そのものの記録がある）か推定かを返す
function weightIsMeasured(dateStr) { return weightLogSorted().some(w => w.date === dateStr); }

let metaCompMode = 'fat'; // fat / mixed / custom

function toggleMetaHelp() {
  const el = document.getElementById('metaHelp');
  if (el) el.style.display = el.style.display === 'none' ? 'block' : 'none';
}

function setMetaCompMode(mode, el) {
  metaCompMode = mode;
  document.querySelectorAll('.meta-comp-btn').forEach(b => b.classList.toggle('active', b.dataset.mode === mode));
  const customPanel = document.getElementById('metaCustomComp');
  if (customPanel) customPanel.style.display = mode === 'custom' ? 'block' : 'none';
  refreshMetaWeights();
  calcMetabolism();
}

function initMetaInputs() {
  // デフォルト: 直近30日
  const to   = new Date(currentDate + 'T00:00:00');
  const from = new Date(to); from.setDate(from.getDate() - 29);
  const toEl   = document.getElementById('metaTo');
  const fromEl = document.getElementById('metaFrom');
  if (toEl   && !toEl.value)   toEl.value   = toDateStr(to);
  if (fromEl && !fromEl.value) fromEl.value  = toDateStr(from);
  refreshMetaWeights();
}
// 開始日・終了日それぞれの推定体重を体重欄に入れ直す（体重をあまり量らない前提のデフォルト動作）。
// ユーザーが体重欄を直接編集した場合はそちらを優先し、日付を変えるまでは上書きしない
function refreshMetaWeights() {
  const fromEl = document.getElementById('metaFrom'), toEl = document.getElementById('metaTo');
  const wFrom  = document.getElementById('metaWFrom'), wTo = document.getElementById('metaWTo');
  if (fromEl && fromEl.value && wFrom && !wFrom.dataset.userEdited) wFrom.value = estimateWeightOnDate(fromEl.value) ?? '';
  if (toEl   && toEl.value   && wTo   && !wTo.dataset.userEdited)   wTo.value   = estimateWeightOnDate(toEl.value)   ?? '';
  renderMetaWeightLabels();
}
function renderMetaWeightLabels() {
  const fromEl = document.getElementById('metaFrom'), toEl = document.getElementById('metaTo');
  const setLabel = (id, dateStr) => {
    const el = document.getElementById(id); if (!el || !dateStr) return;
    el.textContent = weightIsMeasured(dateStr) ? '実測' : (weightLogSorted().length ? '推定（記録から算出）' : '推定（体重ログなし・現在の設定値）');
  };
  setLabel('metaWFromLabel', fromEl && fromEl.value);
  setLabel('metaWToLabel',   toEl   && toEl.value);
}
function markMetaWeightEdited(el) { el.dataset.userEdited = '1'; }

function calcMetabolism() {
  const fromStr = document.getElementById('metaFrom')?.value;
  const toStr   = document.getElementById('metaTo')?.value;
  const wFrom   = parseFloat(document.getElementById('metaWFrom')?.value);
  const wTo     = parseFloat(document.getElementById('metaWTo')?.value);
  const result  = document.getElementById('metaResult');
  renderMetaWeightLabels();
  if (!result) return;

  if (!fromStr || !toStr || isNaN(wFrom) || isNaN(wTo)) {
    result.innerHTML = '<div style="font-size:12px;color:var(--text-sub);padding:8px 0">すべての項目を入力してください</div>';
    return;
  }
  if (fromStr >= toStr) {
    result.innerHTML = '<div style="font-size:12px;color:var(--red)">終了日は開始日より後にしてください</div>';
    return;
  }

  // 期間内の記録を集計
  const fromD = new Date(fromStr + 'T00:00:00');
  const toD   = new Date(toStr   + 'T00:00:00');
  const days  = Math.round((toD - fromD) / 86400000) + 1;

  // 記録のある日のみカウント（記録がない日は除外してTDEE計算を歪めない）
  const recordedDates = [];
  for (let i = 0; i < days; i++) {
    const d = new Date(fromD); d.setDate(d.getDate() + i);
    const ds = toDateStr(d);
    if (entries.some(e => e.date === ds)) recordedDates.push(ds);
  }
  const recordedDays = recordedDates.length;

  if (recordedDays === 0) {
    result.innerHTML = '<div style="font-size:12px;color:var(--text-sub);padding:8px 0">この期間に食事記録がありません</div>';
    return;
  }

  const totalCal = recordedDates.reduce((sum, ds) => sum + sumEntries(getDayEntries(ds)).cal, 0);
  const avgCal   = totalCal / recordedDays;

  // 体重変化 → kcal換算
  const weightDelta = wTo - wFrom; // 増加なら正
  // 体組成モードで1kgあたりのkcalを決定
  let kcalPerKg;
  if (metaCompMode === 'fat') {
    kcalPerKg = 7200;
  } else if (metaCompMode === 'mixed') {
    kcalPerKg = (7200 + 4500) / 2; // 5850
  } else {
    const fatRatio = (parseInt(document.getElementById('metaFatRatio')?.value) || 100) / 100;
    kcalPerKg = 7200 * fatRatio + 4500 * (1 - fatRatio);
  }

  // 実績TDEE = (摂取合計 - 体重変化によるエネルギー変動) / 記録日数
  // 体重増加 → 余剰カロリーがあった → 実TDEEは低い
  const actualTDEE = (totalCal - weightDelta * kcalPerKg) / recordedDays;
  const settingTDEE = calcTDEE();
  const delta = actualTDEE - settingTDEE;
  const deltaAbs = Math.abs(Math.round(delta));

  // 代謝変動の方向
  const isUp   = delta > 50;
  const isDown = delta < -50;
  const isNeut = !isUp && !isDown;
  const deltaColor = isUp ? 'var(--green)' : isDown ? 'var(--red)' : 'var(--text-sub)';
  const deltaLabel = isUp ? '⬆ 代謝亢進' : isDown ? '⬇ 代謝低下' : '→ ほぼ変化なし';
  const deltaDesc  = isUp
    ? `計算値より約${deltaAbs}kcal/日多く消費しています。運動習慣・筋肉量増加・NEAT増加などが考えられます。`
    : isDown
    ? `計算値より約${deltaAbs}kcal/日少ない消費です。食事制限による代謝適応・活動量低下などが考えられます。`
    : `計算値とほぼ一致しています（誤差${deltaAbs}kcal以内）。`;

  // 信頼度（記録日数・期間に加えて、体重が実測アンカーに基づいているかも反映する）
  const anchorCount = weightLogSorted().filter(w => w.date >= fromStr && w.date <= toStr).length
    + (weightLogSorted().some(w => w.date < fromStr) ? 1 : 0) + (weightLogSorted().some(w => w.date > toStr) ? 1 : 0);
  const hasRealAnchor = weightLogSorted().length >= 2;
  let confidence = recordedDays >= 21 ? '高' : recordedDays >= 10 ? '中' : '低';
  let confColor  = recordedDays >= 21 ? 'var(--green)' : recordedDays >= 10 ? 'var(--amber)' : 'var(--red)';
  if (!hasRealAnchor) { confidence = '低'; confColor = 'var(--red)'; }
  const fatRatioForTile = metaCompMode === 'fat' ? 1 : metaCompMode === 'mixed' ? 0.5 : (parseInt(document.getElementById('metaFatRatio')?.value) || 100) / 100;
  const fatDelta = weightDelta * fatRatioForTile;

  result.innerHTML = `
    <!-- 主要結果 -->
    <div style="background:var(--surface2);border:1px solid var(--border);border-radius:var(--radius-sm);padding:12px;margin-bottom:10px">
      <div style="display:grid;grid-template-columns:1fr 1fr;gap:8px;margin-bottom:10px">
        <div style="text-align:center;padding:8px;background:var(--surface);border-radius:8px;border:1px solid var(--border)">
          <div style="font-size:10px;color:var(--text-sub)">実績TDEE（推定）</div>
          <div style="font-size:22px;font-weight:700;letter-spacing:-.5px">${Math.round(actualTDEE)}</div>
          <div style="font-size:10px;color:var(--text-sub)">kcal/日</div>
        </div>
        <div style="text-align:center;padding:8px;background:var(--surface);border-radius:8px;border:1px solid var(--border)">
          <div style="font-size:10px;color:var(--text-sub)">設定TDEE（計算値）</div>
          <div style="font-size:22px;font-weight:700;letter-spacing:-.5px">${settingTDEE}</div>
          <div style="font-size:10px;color:var(--text-sub)">kcal/日</div>
        </div>
      </div>
      <div style="text-align:center;padding:10px;background:var(--surface);border-radius:8px;border:1px solid var(--border)">
        <div style="font-size:12px;color:var(--text-sub);margin-bottom:4px">代謝変動</div>
        <div style="font-size:26px;font-weight:700;color:${deltaColor};letter-spacing:-.5px">
          ${isNeut ? '±0' : (isUp ? '+' : '−') + deltaAbs}
          <span style="font-size:13px;font-weight:400">kcal/日</span>
        </div>
        <div style="font-size:12px;font-weight:600;color:${deltaColor};margin-top:2px">${deltaLabel}</div>
      </div>
    </div>

    <!-- 詳細 -->
    <div style="font-size:11px;color:var(--text-sub);line-height:1.7;margin-bottom:10px;background:var(--surface2);border-radius:8px;padding:10px;border:1px solid var(--border)">
      ${deltaDesc}
    </div>

    <!-- 内訳 -->
    <div style="display:grid;grid-template-columns:repeat(3,1fr);gap:5px;font-size:11px;margin-bottom:8px">
      <div style="background:var(--surface2);border-radius:8px;padding:7px;text-align:center;border:1px solid var(--border)">
        <div style="color:var(--text-sub);font-size:9px">記録日数</div>
        <div style="font-weight:700;font-size:15px">${recordedDays}<span style="font-size:9px;font-weight:400">日</span></div>
        <div style="color:var(--text-sub);font-size:9px">/ ${days}日間</div>
      </div>
      <div style="background:var(--surface2);border-radius:8px;padding:7px;text-align:center;border:1px solid var(--border)">
        <div style="color:var(--text-sub);font-size:9px">平均摂取</div>
        <div style="font-weight:700;font-size:15px">${Math.round(avgCal)}<span style="font-size:9px;font-weight:400">kcal</span></div>
        <div style="color:var(--text-sub);font-size:9px">/ 日</div>
      </div>
      <div style="background:var(--surface2);border-radius:8px;padding:7px;text-align:center;border:1px solid var(--border)">
        <div style="color:var(--text-sub);font-size:9px">体重変化</div>
        <div style="font-weight:700;font-size:15px;color:${weightDelta < 0 ? 'var(--green)' : weightDelta > 0 ? 'var(--red)' : 'var(--text-sub)'}">${weightDelta >= 0 ? '+' : ''}${r1(weightDelta)}<span style="font-size:9px;font-weight:400">kg</span></div>
        <div style="color:var(--text-sub);font-size:9px">≈ ${Math.round(Math.abs(weightDelta)*kcalPerKg)}kcal</div>
      </div>
    </div>

    <!-- 推定体脂肪変化 -->
    <div style="background:var(--surface2);border:1px solid var(--border);border-radius:var(--radius-sm);padding:10px;margin-bottom:10px;text-align:center">
      <div style="font-size:10px;color:var(--text-sub);margin-bottom:2px">推定体脂肪の変化（体組成モード基準）</div>
      <div style="font-size:20px;font-weight:700;letter-spacing:-.5px;color:${fatDelta < -0.05 ? 'var(--green)' : fatDelta > 0.05 ? 'var(--red)' : 'var(--text-sub)'}">
        ${fatDelta >= 0 ? '+' : ''}${r1(fatDelta)}<span style="font-size:12px;font-weight:400"> kg</span>
      </div>
    </div>

    <!-- 信頼度 -->
    <div style="display:flex;align-items:center;gap:6px;font-size:11px;color:var(--text-sub);flex-wrap:wrap">
      <span>推定信頼度：</span>
      <span style="font-weight:700;color:${confColor}">${confidence}</span>
      <span>（${recordedDays}日分の記録）</span>
      ${recordedDays < 10 ? '<span style="color:var(--amber)">⚠ 10日以上の記録で精度が上がります</span>' : ''}
    </div>
    ${!hasRealAnchor ? `<div style="margin-top:6px;font-size:11px;color:var(--amber);background:var(--surface2);border:1px solid var(--border);border-radius:8px;padding:8px">⚠ 実測の体重ログがまだ2件未満のため、体重変化は「設定中の体重のまま」という仮定に基づく参考値です。設定タブで体重を更新すると、その時点が実測記録として使われるようになります。</div>` : ''}`;
}

function renderMetabolismSection() {
  initMetaInputs();
  calcMetabolism();
}


// 食品カテゴリ別パラメータ
const AMINO_PARAMS = {
  // 動物性（肉・魚・卵）: 速い吸収、高ロイシン
  animal:  { absRate: 9,  leucineRatio: 0.09, peakMin: 60,  halfLife: 110 },
  // 乳製品（チーズ・ヨーグルト・牛乳）: 中速、中ロイシン
  dairy:   { absRate: 6,  leucineRatio: 0.10, peakMin: 90,  halfLife: 150 },
  // 大豆・豆類: やや遅い
  soy:     { absRate: 5,  leucineRatio: 0.08, peakMin: 90,  halfLife: 130 },
  // その他植物性: 遅い、低ロイシン
  plant:   { absRate: 4,  leucineRatio: 0.06, peakMin: 120, halfLife: 140 },
  // プロテインパウダー（ホエイ相当）
  whey:    { absRate: 10, leucineRatio: 0.11, peakMin: 45,  halfLife: 90  },
};

const ANIMAL_PAT  = /鶏|豚|牛|羊|ささみ|チキン|ポーク|ビーフ|ラム|ひき肉|合いびき|ベーコン|ハム|ソーセージ|ウインナー|いわし|さば|さんま|あじ|さけ|鮭|サーモン|まぐろ|マグロ|ツナ|えび|いか|ほたて|あさり|カニ|ぶり|たい|鯛|たら|焼き鳥|唐揚げ|から揚げ|ハンバーグ|卵|たまご|タマゴ|ゆで卵|目玉焼き|スクランブル|チキン|プロテイン.*動物|animal|chicken|pork|beef|fish|salmon|tuna|egg/i;
const DAIRY_PAT   = /牛乳|ミルク|チーズ|ヨーグルト|ホエイ|カゼイン|プロテイン(?!.*大豆)|milk|cheese|yogurt|whey|casein/i;
const SOY_PAT     = /大豆|豆腐|納豆|豆乳|枝豆|おから|テンペ|soy|tofu|natto/i;
const WHEY_PAT    = /ホエイ|ウェイ|WPC|WPI|whey/i;

function classifyProteinSource(name) {
  if (WHEY_PAT.test(name))  return 'whey';
  if (DAIRY_PAT.test(name)) return 'dairy';
  if (ANIMAL_PAT.test(name)) return 'animal';
  if (SOY_PAT.test(name))   return 'soy';
  return 'plant';
}

// 食事1回分のアミノ酸時系列を生成（minutesOffset=食事時刻の0時からの分数）
// 返値: 分→相対濃度 のMap（0〜1440分）
function calcAminoTimeSeries(entries, minutesOffset) {
  // 食品ごとに分類してタンパク質量と吸収パラメータを集計
  const groups = { animal:0, dairy:0, soy:0, plant:0, whey:0 };
  entries.forEach(e => {
    const src = classifyProteinSource(e.name);
    groups[src] += (e.p || 0);
  });

  const RESOLUTION = 5; // 5分刻み
  const totalMinutes = 1440;
  const curve = new Array(Math.ceil(totalMinutes / RESOLUTION)).fill(0);

  Object.entries(groups).forEach(([src, protein]) => {
    if (protein <= 0) return;
    const p = AMINO_PARAMS[src];
    // 吸収時間 = protein / absRate (時間) → 分
    const absorptionDuration = (protein / p.absRate) * 60;
    // ピーク時刻（食事時刻 + peakMin）
    const peakMinOffset = minutesOffset + p.peakMin;
    // ピーク濃度 = protein * leucineRatio（ロイシン量g）をそのまま使う
    const peakLeucine = protein * p.leucineRatio;

    // 上昇フェーズ: 食事時刻 → ピーク
    // 減衰フェーズ: ピーク → halfLifeに従って指数減衰
    for (let i = 0; i < curve.length; i++) {
      const t = i * RESOLUTION; // 現在の分
      const dt = t - minutesOffset; // 食事後経過分
      if (dt < 0) continue;

      let conc = 0;
      if (dt <= p.peakMin) {
        // 上昇: 線形
        conc = peakLeucine * (dt / p.peakMin);
      } else {
        // 減衰: 指数
        const decayT = dt - p.peakMin;
        conc = peakLeucine * Math.exp(-Math.log(2) * decayT / p.halfLife);
      }
      curve[i] += conc;
    }
  });

  return curve;
}

// 食事時刻の保存キー
function aminoTimeKey(date) { return 'aminoTimes_' + date; }
function loadAminoTimes(date) {
  try { return JSON.parse(localStorage.getItem(aminoTimeKey(date)) || '{}'); } catch { return {}; }
}
function saveAminoTimes(date, times) {
  try { localStorage.setItem(aminoTimeKey(date), JSON.stringify(times)); } catch {}
}

let aminoChartInstance = null;

function toggleAminoHelp() {
  const el = document.getElementById('aminoHelp');
  if (el) el.style.display = el.style.display === 'none' ? 'block' : 'none';
}

function renderAminoInputs() {
  const cont = document.getElementById('aminoTimeInputs');
  if (!cont) return;
  const times = loadAminoTimes(currentDate);
  const meals = ['朝食','昼食','夕食','間食'];
  cont.innerHTML = meals.map(meal => {
    const mealEntries = getDayEntries(currentDate).filter(e => e.meal === meal);
    if (!mealEntries.length) return '';
    const totalP = r1(mealEntries.reduce((a,e) => a + (e.p||0), 0));
    const leucineApprox = r1(mealEntries.reduce((a,e) => {
      const src = classifyProteinSource(e.name);
      return a + (e.p||0) * AMINO_PARAMS[src].leucineRatio;
    }, 0));
    return `<div style="display:flex;align-items:center;gap:8px;background:var(--surface2);border:1px solid var(--border);border-radius:9px;padding:8px 11px">
      <div style="flex:1;min-width:0">
        <div style="font-size:12px;font-weight:600">${meal}</div>
        <div style="font-size:10px;color:var(--text-sub)">P ${totalP}g　ロイシン約 ${leucineApprox}g</div>
      </div>
      <input type="time" value="${times[meal]||''}" onchange="onAminoTimeChange('${meal}',this.value)"
        style="font-size:13px;padding:5px 8px;border:1.5px solid var(--border);border-radius:7px;background:var(--surface);color:var(--text);width:100px">
    </div>`;
  }).filter(Boolean).join('');
  if (!cont.innerHTML) cont.innerHTML = '<div style="font-size:12px;color:var(--text-sub);padding:6px 0">今日の食事記録がありません</div>';
}

function onAminoTimeChange(meal, value) {
  const times = loadAminoTimes(currentDate);
  if (value) times[meal] = value; else delete times[meal];
  saveAminoTimes(currentDate, times);
  renderAminoChart();
}

function renderAminoChart() {
  const canvas = document.getElementById('aminoChart');
  const summary = document.getElementById('aminoSummary');
  if (!canvas) return;

  const times = loadAminoTimes(currentDate);
  const RESOLUTION = 5;
  const points = Math.ceil(1440 / RESOLUTION);
  const combined = new Array(points).fill(0);

  const MPS_THRESHOLD = 2.5; // ロイシン2.5g以上でMPS促進

  let hasData = false;
  Object.entries(times).forEach(([meal, timeStr]) => {
    if (!timeStr) return;
    const [h, m] = timeStr.split(':').map(Number);
    const minutesOffset = h * 60 + m;
    const mealEntries = getDayEntries(currentDate).filter(e => e.meal === meal);
    if (!mealEntries.length) return;
    hasData = true;
    const curve = calcAminoTimeSeries(mealEntries, minutesOffset);
    curve.forEach((v, i) => { combined[i] += v; });
  });

  // ラベル（1時間刻み表示）
  const labels = Array.from({length: points}, (_, i) => {
    const totalMin = i * RESOLUTION;
    const h = Math.floor(totalMin / 60) % 24;
    const m = totalMin % 60;
    return m === 0 ? `${h}:00` : '';
  });

  // MPS閾値ライン、バックグラウンドレベル（ベースライン = 0.3g相当）
  const baseline = 0.3;
  const data = combined.map(v => r1(Math.max(v + baseline, baseline)));

  // Chart描画
  if (aminoChartInstance) { aminoChartInstance.destroy(); aminoChartInstance = null; }
  const ctx = canvas.getContext('2d');
  const accent = getComputedStyle(document.documentElement).getPropertyValue('--accent').trim() || '#3266ad';

  // グラデーション
  const grad = ctx.createLinearGradient(0, 0, 0, 180);
  grad.addColorStop(0, 'rgba(50,102,173,.35)');
  grad.addColorStop(1, 'rgba(50,102,173,.02)');

  aminoChartInstance = new Chart(ctx, {
    type: 'line',
    data: {
      labels,
      datasets: [
        {
          label: '血中アミノ酸（ロイシン換算g）',
          data,
          borderColor: '#3266ad',
          backgroundColor: grad,
          borderWidth: 2,
          fill: true,
          tension: 0.4,
          pointRadius: 0,
          pointHoverRadius: 4,
        },
        {
          label: `MPS促進閾値 (${MPS_THRESHOLD}g)`,
          data: new Array(points).fill(MPS_THRESHOLD),
          borderColor: '#e91e63',
          borderWidth: 1.5,
          borderDash: [5, 4],
          pointRadius: 0,
          fill: false,
        },
      ],
    },
    options: {
      responsive: true, maintainAspectRatio: false,
      animation: { duration: 600 },
      plugins: {
        legend: { display: true, labels: { font: { size: 10 }, boxWidth: 14, padding: 8 } },
        tooltip: {
          callbacks: {
            title: items => {
              const idx = items[0].dataIndex;
              const totalMin = idx * RESOLUTION;
              const h = Math.floor(totalMin / 60) % 24;
              const m = String(totalMin % 60).padStart(2,'0');
              return `${h}:${m}`;
            },
            label: item => item.datasetIndex === 0
              ? `ロイシン換算: ${item.raw}g`
              : `閾値: ${item.raw}g`,
          },
        },
      },
      scales: {
        x: {
          ticks: { font: { size: 9 }, maxRotation: 0, autoSkip: true, maxTicksLimit: 12, color: '#6b7280' },
          grid: { color: 'rgba(0,0,0,.05)' },
        },
        y: {
          min: 0,
          ticks: { font: { size: 9 }, color: '#6b7280', callback: v => v + 'g' },
          grid: { color: 'rgba(0,0,0,.05)' },
          title: { display: true, text: 'ロイシン換算 (g)', font: { size: 9 }, color: '#6b7280' },
        },
      },
    },
  });

  // サマリー計算
  if (!summary) return;
  if (!hasData) {
    summary.innerHTML = '<div style="font-size:12px;color:var(--text-sub);grid-column:span 2;padding:4px 0">食事時刻を入力するとサマリーが表示されます</div>';
    return;
  }
  const peak = Math.max(...data);
  // MPS閾値を超えている時間（分）
  const mpsMinutes = data.filter(v => v >= MPS_THRESHOLD).length * RESOLUTION;
  // 今この瞬間の濃度
  const now = new Date();
  const nowMin = now.getHours() * 60 + now.getMinutes();
  const nowIdx = Math.floor(nowMin / RESOLUTION);
  const nowVal = data[Math.min(nowIdx, data.length-1)] || 0;
  // 総ロイシン（各食事の推定量）
  const totalLeucine = r1(getDayEntries(currentDate).reduce((a,e) => {
    const src = classifyProteinSource(e.name);
    return a + (e.p||0) * AMINO_PARAMS[src].leucineRatio;
  }, 0));

  const card = (label, val, unit, sub, color='var(--accent)') => `
    <div style="background:var(--surface2);border:1px solid var(--border);border-radius:9px;padding:9px 11px">
      <div style="font-size:10px;color:var(--text-sub);margin-bottom:2px">${label}</div>
      <div style="font-size:18px;font-weight:700;color:${color}">${val}<span style="font-size:11px;font-weight:400;color:var(--text-sub);margin-left:2px">${unit}</span></div>
      <div style="font-size:10px;color:var(--text-sub);margin-top:2px">${sub}</div>
    </div>`;

  summary.innerHTML =
    card('ピーク濃度', r1(peak), 'g', 'ロイシン換算') +
    card('現在の推定値', r1(nowVal), 'g', now.getHours()+':'+String(now.getMinutes()).padStart(2,'0')+'時点', nowVal >= MPS_THRESHOLD ? 'var(--green)' : 'var(--text-sub)') +
    card('MPS促進時間', mpsMinutes, '分', `閾値${MPS_THRESHOLD}g以上の時間`, mpsMinutes > 0 ? 'var(--green)' : 'var(--text-sub)') +
    card('1日ロイシン合計', totalLeucine, 'g', '推定値（食品別係数による）');
}

function renderAminoSection() {
  renderAminoInputs();
  renderAminoChart();
}


// ── 耐容上限量（UL）超過チェック ──
// 期間平均ではなく「その期間内に1日でも上限を超えた日があったか」を見る。
// 平均で見ると、例えば1日だけ大量に摂取した日があっても他の日で薄まってしまい
// 見逃してしまうため、ULは日ごとの安全域の指標として日単位でチェックする。
function checkUlExceedances(period) {
  const today = new Date(); today.setHours(0,0,0,0);
  const days = period==='today' ? [toDateStr(new Date())]
    : Array.from({length:period==='7d'?7:period==='30d'?30:90}, (_,i) => { const d=new Date(today); d.setDate(d.getDate()-i); return toDateStr(d); });

  const results = [];
  Object.keys(MICRO_GOALS).forEach(key => {
    const g = MICRO_GOALS[key];
    if (!g.ul) return; // ULが設定されていない栄養素（ビタミンK等）はチェック対象外
    const overDays = [];
    days.forEach(d => {
      const list = getDayEntries(d);
      if (!list.length) return;
      const val = sumEntries(list)[key] || 0;
      if (val > g.ul) overDays.push({ date: d, val: r1(val) });
    });
    if (overDays.length) {
      results.push({ key, label: g.label, unit: g.unit, ul: g.ul, overDays, maxVal: Math.max(...overDays.map(o=>o.val)) });
    }
  });
  return results;
}
function renderUlWarning() {
  const el = document.getElementById('ulWarning');
  if (!el) return;
  const issues = checkUlExceedances(statsPeriod);
  if (!issues.length) { el.innerHTML = ''; return; }
  el.innerHTML = `
    <div class="card" style="padding:11px 13px;margin-bottom:12px;border:1.5px solid #f0ad4e55;background:linear-gradient(135deg,#fff8ec,#fffdf9)">
      <div style="display:flex;align-items:center;gap:6px;margin-bottom:8px;font-weight:700;font-size:13px;color:#a06a1a">
        ⚠️ 耐容上限量を超えた日があります
      </div>
      <div style="display:flex;flex-direction:column;gap:6px">
        ${issues.map(i => `
          <div style="font-size:12px;line-height:1.6;color:#4b3a1a">
            <b>${i.label}</b>: ${i.overDays.length}日間で上限（${i.ul}${i.unit}）を超過（最大 ${i.maxVal}${i.unit}）
            <div style="font-size:10px;color:#6b5638">${i.overDays.map(o=>o.date.slice(5)).join('、')}</div>
          </div>`).join('')}
      </div>
      <div style="font-size:10px;color:#6b5638;margin-top:8px;border-top:1px solid #f0ad4e33;padding-top:6px">
        耐容上限量は日本人の食事摂取基準(2020年版)の成人目安値です。サプリメントの重複摂取や、海藻類（ヨウ素）の多量摂取などが主な原因になりやすい項目です。
      </div>
    </div>`;
}
function getAvg(period) {
  const today=new Date(); today.setHours(0,0,0,0);
  const days=period==='today'?[toDateStr(new Date())]:Array.from({length:period==='7d'?7:period==='30d'?30:90},(_,i)=>{const d=new Date(today);d.setDate(d.getDate()-i);return toDateStr(d)});
  const wd=days.filter(d=>getDayEntries(d).length>0); if(!wd.length) return null;
  const tot=wd.map(d=>sumEntries(getDayEntries(d))); const n=wd.length;
  const avg={days:n};
  ['cal','p','f','c','fiber','fibS','fibI','fibU','iron','calcium','vitc','vitd','vita','vite','vitk','iodine','salt'].forEach(k=>{avg[k]=r1(tot.reduce((a,t)=>a+(t[k]||0),0)/n)});
  return avg;
}
function goalBar(label, actual, target, unit, color, reverse=false) {
  const pct=Math.min(actual/target*100,100), over=actual>target;
  const col=reverse?(over?'#c0392b':color):(over?'#c0392b':color);
  return `<div class="goal-bar-wrap"><div class="goal-bar-label"><span>${label}</span><span style="font-weight:500;color:${over&&!reverse?'#c0392b':'var(--text)'}">${actual}${unit}<span style="font-weight:400;color:var(--text-sub)"> / ${target}${unit}</span></span></div><div class="goal-bar-track"><div class="goal-bar-fill" style="width:${pct}%;background:${col}"></div></div><div style="font-size:10px;text-align:right;margin-top:2px;color:${over&&!reverse?'#c0392b':'var(--text-sub)'}"> ${over?`+${r1(actual-target)}${unit} オーバー`:`あと ${r1(target-actual)}${unit}`}</div></div>`;
}
function setPeriod(period, el) {
  statsPeriod = period;
  document.querySelectorAll('.period-tab').forEach(b => b.classList.remove('active'));
  if (el) el.classList.add('active');
  renderStats();
}
function renderStats() {
  renderUlWarning();
  const g=goals(), avg=getAvg(statsPeriod), s=avg||{cal:0,p:0,f:0,c:0,fiber:0,iron:0,calcium:0,vitc:0,vitd:0,vita:0,vite:0,vitk:0,iodine:0,salt:0};
  // 統計期間の吸収タンパク質（平均）
  const statsDays = (() => {
    const now = new Date(); const days = statsPeriod==='today'?1:statsPeriod==='7d'?7:statsPeriod==='30d'?30:90;
    const dates = Array.from({length:days},(_,i)=>{const d=new Date(now);d.setDate(d.getDate()-i);return toDateStr(d);});
    return dates;
  })();
  const statsAbsP = statsDays.length > 0
    ? r1(statsDays.reduce((sum,date) => {
        const dayList = entries.filter(e=>e.date===date);
        return sum + calcAbsorbedProtein(dayList);
      }, 0) / (avg?.days || 1))
    : 0;
  const lbl=statsPeriod==='today'?'今日':statsPeriod==='7d'?`週平均(${avg?avg.days:'0'}日)`:statsPeriod==='30d'?`月平均(${avg?avg.days:'0'}日)`:`3ヶ月平均(${avg?avg.days:'0'}日)`;
  const score=avg?Math.round(Math.min(s.cal/g.cal,1)*25+Math.min(statsAbsP/g.p,1)*35+Math.min(s.f/g.f,1)*20+Math.min(s.c/g.c,1)*20):0;
  document.getElementById('goalBars').innerHTML = avg ? `
    <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:12px">
      <span style="font-size:11px;color:var(--text-sub)">${lbl}</span>
      <span style="font-size:26px;font-weight:600;color:${score>=80?'#2e7d32':score>=60?'#e8a838':'#c0392b'}">${score}<span style="font-size:12px;color:var(--text-sub)">/100</span></span>
    </div>
    <div style="margin-bottom:10px;font-size:11px;color:var(--text-sub)">体重 <input type="number" value="${userWeight}" min="30" max="200" step="0.5" oninput="userWeight=parseFloat(this.value)||65;localStorage.setItem('pfcWeight',userWeight);renderStats()" style="width:50px;font-size:12px;padding:2px 5px;border:1px solid var(--border);border-radius:6px;background:var(--surface);color:var(--text)"> kg → タンパク質目標 ${g.p}g</div>
    <div style="font-size:11px;font-weight:600;color:var(--text-sub);margin-bottom:8px">PFC・カロリー</div>
    ${goalBar('カロリー',ri(s.cal),g.cal,'kcal','#3266ad')}${goalBar('タンパク質（摂取）',r1(s.p),g.p,'g','#3266ad')}${goalBar('タンパク質（吸収補正）',statsAbsP,g.p,'g','#3266ad')}${goalBar('脂質',r1(s.f),g.f,'g','#e8a838')}${goalBar('炭水化物',r1(s.c),g.c,'g','#4caf50')}
    <div style="font-size:11px;font-weight:600;color:var(--text-sub);margin:12px 0 8px">ビタミン・ミネラル・食物繊維</div>
    ${goalBar('食物繊維',r1(s.fiber),21,'g','#8bc34a')}${fiberSplitBlock(s)}${goalBar('鉄',r1(s.iron),7,'mg','#e91e63')}${goalBar('カルシウム',ri(s.calcium),700,'mg','#03a9f4')}${goalBar('ビタミンC',ri(s.vitc),100,'mg','#ff9800')}${goalBar('ビタミンD',r1(s.vitd),8.5,'μg','#ffd600')}${goalBar('ビタミンA',ri(s.vita),850,'μg','#ff7043')}${goalBar('ビタミンE',r1(s.vite),6.5,'mg','#ab47bc')}${goalBar('ビタミンK',ri(s.vitk),150,'μg','#26a69a')}${goalBar('ヨウ素',ri(s.iodine),130,'μg','#5c6bc0')}${goalBar('塩分',r1(s.salt),7.5,'g','#9e9e9e',true)}
  ` : `<div style="text-align:center;padding:2rem;color:var(--text-sub);font-size:13px">この期間の記録がありません</div>`;
  renderCharts();
  renderVitDStock();
}
// ── ビタミンD ストック（体内蓄積）推定 ──
// 血中の主要な貯蔵型である25(OH)Dの半減期（文献上おおよそ3週間/21日）に基づく
// 単一コンパートメントの指数減衰モデル。
//   Stock(day) = Stock(day-1) × 減衰率 + その日の摂取量
// 減衰率は半減期21日から算出（e^(-ln2/21) ≈ 0.9675、1日あたり約3.25%減少）。
//
// 重要な限界（UIにも明記する）:
//   ・日照による皮膚合成を一切考慮していない（ビタミンDの主要な供給源は
//     食事より日光であることが多く、屋外活動が多い人はここでの推定より
//     実際の体内量は多いはずである）
//   ・絶対的な血中濃度ではなく、記録開始日を「目安量を続けていた場合の
//     定常状態」とみなした相対的な蓄積トレンドである（採血の代替にはならない）
const VITD_HALFLIFE_DAYS = 21;
const VITD_DECAY = Math.pow(0.5, 1 / VITD_HALFLIFE_DAYS);
function calcVitDStockSeries() {
  const allDates = [...new Set(entries.map(e => e.date))].sort();
  if (!allDates.length) return [];
  const startDate = allDates[0];
  const endDate = toDateStr(new Date());
  // 開始日の前提在庫: 目安量(8.5μg/日)を継続摂取した場合の定常状態を初期値とする
  const rdaSteady = MICRO_GOALS.vitd.goal / (1 - VITD_DECAY);

  let stock = rdaSteady;
  const series = [];
  const d = new Date(startDate + 'T00:00:00');
  const end = new Date(endDate + 'T00:00:00');
  while (d <= end) {
    const ds = toDateStr(d);
    const intake = sumEntries(getDayEntries(ds)).vitd || 0;
    stock = stock * VITD_DECAY + intake;
    series.push({ date: ds, stock: r1(stock) });
    d.setDate(d.getDate() + 1);
  }
  return series;
}
function renderVitDStock() {
  const wrap = document.getElementById('vitdStockWrap');
  if (!wrap) return;
  const series = calcVitDStockSeries();
  if (series.length < 2) { wrap.style.display = 'none'; return; }
  wrap.style.display = '';

  const rdaSteady = MICRO_GOALS.vitd.goal / (1 - VITD_DECAY);
  const latest = series[series.length - 1].stock;
  const pct = Math.round(latest / rdaSteady * 100);

  document.getElementById('vitdStockSummary').innerHTML =
    `現在の推定ストック: <b style="font-size:15px">${latest}</b> <span style="color:var(--text-sub)">(目安量継続時を100%とすると ${pct}%)</span>`;

  // 表示範囲は直近90日まで（それより前は折りたたむ）
  const shown = series.slice(-90);
  const labels = shown.map(s => { const dt = new Date(s.date + 'T00:00:00'); return `${dt.getMonth()+1}/${dt.getDate()}`; });
  const skip = shown.length > 30 ? Math.ceil(shown.length / 12) : 1;

  if (vitdStockChart) vitdStockChart.destroy();
  vitdStockChart = new Chart(document.getElementById('vitdStockChart'), {
    type: 'line',
    data: {
      labels,
      datasets: [
        { label: 'ストック推定', data: shown.map(s => s.stock), borderColor: '#ffd600', backgroundColor: 'rgba(255,214,0,.12)', tension: .3, pointRadius: 0, borderWidth: 2, fill: true },
        { label: '定常状態(目安量継続時)', data: shown.map(() => r1(rdaSteady)), borderColor: 'rgba(128,128,128,.4)', borderDash: [4,3], borderWidth: 1, pointRadius: 0, fill: false },
      ],
    },
    options: {
      responsive: true, maintainAspectRatio: false,
      plugins: { legend: { position: 'bottom', labels: { font: { size: 10 }, boxWidth: 8, padding: 8 } } },
      scales: {
        y: { beginAtZero: true, ticks: { font: { size: 10 } }, grid: { color: 'rgba(128,128,128,.1)' } },
        x: { ticks: { font: { size: 10 }, callback: (_, i) => i % skip === 0 ? labels[i] : '' } },
      },
    },
  });
}
function getLast(n) { return Array.from({length:n},(_,i)=>{const d=new Date();d.setDate(d.getDate()-(n-1-i));return toDateStr(d)}); }
function renderCharts() {
  const n=statsPeriod==='90d'?90:statsPeriod==='30d'?30:7;
  const days=getLast(n);
  const labels=days.map(d=>{const dt=new Date(d+'T00:00:00');return`${dt.getMonth()+1}/${dt.getDate()}`});
  const skip=n>30?Math.ceil(n/12):1;
  const g=goals();
  const baseOpts={responsive:true,maintainAspectRatio:false,plugins:{legend:{display:false}},scales:{y:{beginAtZero:true,ticks:{font:{size:10}},grid:{color:'rgba(128,128,128,.1)'}},x:{ticks:{font:{size:10},callback:(_,i)=>i%skip===0?labels[i]:''}}}};
  if(calChart) calChart.destroy();
  calChart=new Chart(document.getElementById('calChart'),{type:'bar',data:{labels,datasets:[{label:'摂取',data:days.map(d=>ri(sumEntries(getDayEntries(d)).cal)),backgroundColor:'#3266ad',borderRadius:2},{type:'line',label:'目標',data:days.map(()=>g.cal),borderColor:'#c0392b',borderDash:[4,3],borderWidth:1.5,pointRadius:0,fill:false}]},options:{...baseOpts,plugins:{legend:{display:false}}}});
  if(pfcChart) pfcChart.destroy();
  pfcChart=new Chart(document.getElementById('pfcChart'),{type:'line',data:{labels,datasets:[
    {label:'P',data:days.map(d=>r1(sumEntries(getDayEntries(d)).p)),borderColor:'#3266ad',backgroundColor:'transparent',tension:.3,pointRadius:0,borderWidth:2},
    {label:'F',data:days.map(d=>r1(sumEntries(getDayEntries(d)).f)),borderColor:'#e8a838',backgroundColor:'transparent',tension:.3,pointRadius:0,borderWidth:2,borderDash:[5,3]},
    {label:'C',data:days.map(d=>r1(sumEntries(getDayEntries(d)).c)),borderColor:'#4caf50',backgroundColor:'transparent',tension:.3,pointRadius:0,borderWidth:2,borderDash:[2,2]},
    {label:'P目標',data:days.map(()=>g.p),borderColor:'rgba(50,102,173,.3)',borderDash:[3,3],borderWidth:1,pointRadius:0,fill:false},
  ]},options:{...baseOpts,plugins:{legend:{position:'bottom',labels:{font:{size:10},boxWidth:8,padding:8}}}}});
  renderAminoSection();
  renderMetabolismSection();
}

// ── CSV ──
const CSV_HEADERS = ['date','meal','name','amount','cal','p','f','c','fiber','iron','calcium','vitc','vitd','salt','fiber_soluble','fiber_insoluble','net_cal',
  'day_bmr_kcal','day_tdee_kcal','day_exercise_kcal','day_total_burn_kcal','day_intake_kcal','day_net_intake_kcal','day_balance_kcal','day_net_balance_kcal'];
const TDEE_CSV_HEADERS = ['date','bmr_kcal','activity_desc','activity_kcal','steps','tdee_kcal','exercise_kcal','total_burn_kcal','intake_kcal','balance_kcal',
  'tdee_formula','bmr_formula','bmr_calc','temp_multiplier','neat_pct','activity_source','tef_kcal','profile_used',
  'fiber_g','fiber_adj_kcal','net_intake_kcal','net_balance_kcal','net_calc'];
// その日のエネルギー収支の材料（TDEE内訳・運動消費・摂取・実質カロリー）。食事記録の各行・日別の表・日別CSVで共通に使う
function dayEnergyInfo(d) {
  const tb = getTdeeBreakdown(d);
  const exCal = exercises.filter(x => x.date === d).reduce((a, x) => a + (x.cal || 0), 0);
  const daySum = sumEntries(getDayEntries(d)), intake = r1(daySum.cal);
  const totalBurn = r1(tb.tdee + exCal), net = calcNetCalories(daySum);   // 実質カロリーは画面の「実質」表示と同じ計算
  return { tb, exCal, daySum, intake, totalBurn, net };
}
function csvQ(v) { return `"${String(v).replace(/"/g, '""')}"`; }
// 日別の1行（TDEE_CSV_HEADERS の順）
function dailyCsvCells(d, bd, x) {
  const { tb, exCal, daySum, intake, totalBurn, net } = x;
  return [
    d, ri(tb.bmr), csvQ(describeActivity(tb)), tb.simple ? '' : ri(tb.activeCal),
    tb.detail ? (tb.detail.steps || 0) : '', tb.tdee, ri(exCal), ri(totalBurn),
    intake, r1(intake - totalBurn),
    csvQ(describeTdeeFormula(tb)), csvQ(bd.name), csvQ(`${bd.expr} = ${ri(bd.raw)}` + (bd.tempMult !== 1 ? ` × 気温補正${bd.tempMult}(${bd.temp}℃)` : '') + ` → BMR ${ri(bd.bmr)}`),
    bd.tempMult, tb.simple ? '' : getNeatPct(), tdeeActivitySource(tb), tb.simple ? 0 : tb.tef,
    csvQ(`${bd.sex} ${bd.h}cm ${bd.w}kg ${bd.age}歳` + (bd.bf ? ` 体脂肪${bd.bf}%` : '') + '（現在のプロフィール設定）'),
    r1(daySum.fiber), net.fiberAdj, net.netCal, r1(net.netCal - totalBurn),
    csvQ(`表示 ${intake}kcal − 食物繊維 ${r1(daySum.fiber)}g × ${FIBER_NET_KCAL_PER_G}kcal = 実質 ${net.netCal}kcal（実質収支 = 実質摂取 − 総消費）`),
  ];
}
function downloadCsv(rows, filename) {
  const blob = new Blob(['\uFEFF' + rows.join('\n')], { type: 'text/csv;charset=utf-8' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a'); a.href = url; a.download = filename; a.click(); URL.revokeObjectURL(url);
}
function exportCSV() {
  const from=document.getElementById('csvFrom').value, to=document.getElementById('csvTo').value;
  let data=[...entries];
  if(from) data=data.filter(e=>e.date>=from);
  if(to) data=data.filter(e=>e.date<=to);
  data=data.sort((a,b)=>a.date.localeCompare(b.date)||MEALS_ORDER.indexOf(a.meal)-MEALS_ORDER.indexOf(b.meal));
  // 食事記録の各行には、その日のBMR・TDEE・総消費・摂取・実質摂取・収支も付ける（日別の表を探さなくても、どの行からでもTDEEが分かる）
  const dayCache = {}, di = d => dayCache[d] || (dayCache[d] = dayEnergyInfo(d));
  const rows=[CSV_HEADERS.join(','),...data.map(e=>{ const x = di(e.date); return [e.date,e.meal,csvQ(e.name||''),e.amount||0,r1(e.cal||0),r1(e.p||0),r1(e.f||0),r1(e.c||0),r1(e.fiber||0),r1(e.iron||0),ri(e.calcium||0),ri(e.vitc||0),r1(e.vitd||0),r2(e.salt||0),...(() => { const sp = getFiberSplit(e); return [r1(sp.s), r1(sp.i + sp.u)]; })(),r1((e.cal||0) - (e.fiber||0) * FIBER_NET_KCAL_PER_G),
    ri(x.tb.bmr), x.tb.tdee, ri(x.exCal), ri(x.totalBurn), x.intake, x.net.netCal, r1(x.intake - x.totalBurn), r1(x.net.netCal - x.totalBurn)].join(','); })];

  // ── 消費カロリー詳細（日別、1行1日）──ファイルの末尾に、空行をはさんで別の表として付ける
  // 食事記録の対象日を軸に、その日のTDEE内訳・運動消費・摂取との差引をまとめる。
  // ※ BMRは現在のプロフィール設定（体重・年齢等）で計算するため、過去に体重や設定を
  //    変えている場合、当時の実際の値とは異なる（このアプリは体組成の履歴を保持していない）
  const dates = [...new Set(data.map(e => e.date))].sort();
  if (dates.length) {
    rows.push('');
    rows.push(TDEE_CSV_HEADERS.join(','));
    const bd = getBmrDetail();
    dates.forEach(d => rows.push(dailyCsvCells(d, bd, di(d)).join(',')));
  }
  downloadCsv(rows, `pfc_export_${toDateStr(new Date())}.csv`);
}
// 日別だけを1つの表にしたCSV（TDEE・運動・摂取・実質収支・計算式）。期間内の全日を出す（記録の無い日も含む）。表計算ソフトやpandasでそのまま読める
const DAILY_CSV_HEADERS = [...TDEE_CSV_HEADERS, 'record_count'];
function exportDailyCSV() {
  let from = document.getElementById('csvFrom').value, to = document.getElementById('csvTo').value;
  const pool = [...entries.map(e => e.date), ...exercises.map(x => x.date), ...Object.keys(dailyActivity)].filter(Boolean).sort();
  if (!from) from = pool[0]; if (!to) to = pool[pool.length - 1];
  if (!from || !to) { showToast('出力できる日別データがありません'); return; }
  if (from > to) [from, to] = [to, from];
  const dates = []; const MAXD = 1100;
  for (const d = new Date(from + 'T00:00:00'); toDateStr(d) <= to && dates.length < MAXD; d.setDate(d.getDate() + 1)) dates.push(toDateStr(d));
  const bd = getBmrDetail();
  const rows = [DAILY_CSV_HEADERS.join(','), ...dates.map(d => [...dailyCsvCells(d, bd, dayEnergyInfo(d)), getDayEntries(d).length].join(','))];
  downloadCsv(rows, `pfc_daily_${toDateStr(new Date())}.csv`);
  if (dates.length >= MAXD && toDateStr(new Date(from + 'T00:00:00')) !== to) showToast(`期間が長いため、最初の${MAXD}日分を出力しました`);
}
function importCSV() {
  const text=document.getElementById('csvImportArea').value.trim();
  const msg=document.getElementById('csvImportMsg');
  if(!text){msg.className='status-msg status-err';msg.textContent='CSVデータを入力してください';return}
  const lines=text.split('\n').map(l=>l.trim()).filter(Boolean);
  const header=lines[0].toLowerCase().split(',').map(h=>h.trim().replace(/^"|"$/g,''));
  const idxOf=k=>header.indexOf(k);
  let count=0, skip=0;
  for(let i=1;i<lines.length;i++){
    try{
      const cols=parseCsvLine(lines[i]);
      const date=(cols[idxOf('date')]||'').trim().replace(/^"|"$/g,'');
      const meal=(cols[idxOf('meal')]||'').trim().replace(/^"|"$/g,'');
      const name=(cols[idxOf('name')]||'').trim().replace(/^"|"$/g,'');
      if(!date||!name||!MEALS_ORDER.includes(meal)){skip++;continue}
      const entry={id:Date.now()+i+Math.random(),date,meal,name,
        amount:parseFloat(cols[idxOf('amount')])||100, cal:parseFloat(cols[idxOf('cal')])||0, p:parseFloat(cols[idxOf('p')])||0,
        f:parseFloat(cols[idxOf('f')])||0, c:parseFloat(cols[idxOf('c')])||0,
        fiber:parseFloat(cols[idxOf('fiber')])||0, iron:parseFloat(cols[idxOf('iron')])||0,
        calcium:parseFloat(cols[idxOf('calcium')])||0, vitc:parseFloat(cols[idxOf('vitc')])||0,
        vitd:parseFloat(cols[idxOf('vitd')])||0, salt:parseFloat(cols[idxOf('salt')])||0};
      if (idxOf('fiber_soluble') >= 0 && idxOf('fiber_insoluble') >= 0) { // 内訳つきCSV。無い古いCSVは食品名から自動推定される
        const fs = parseFloat(cols[idxOf('fiber_soluble')]), fi = parseFloat(cols[idxOf('fiber_insoluble')]);
        if (isFinite(fs) && isFinite(fi) && fs + fi > 0) { entry.fibS = r1(fs); entry.fibI = r1(Math.max(0, entry.fiber - r1(fs))); }
      }
      const dup=entries.some(e=>e.date===entry.date&&e.meal===entry.meal&&e.name===entry.name&&e.amount===entry.amount);
      if(!dup){entries.push(entry);count++}else skip++;
    }catch(err){skip++}
  }
  save();
  if(count>0){msg.className='status-msg status-ok';msg.textContent=`${count}件をインポートしました（スキップ: ${skip}件）`}
  else{msg.className='status-msg status-err';msg.textContent=`インポートできませんでした（スキップ: ${skip}件）`}
  renderRecord(); renderCalendar();
}
function parseCsvLine(line) {
  const result=[]; let cur='', inQ=false;
  for(let i=0;i<line.length;i++){
    if(line[i]==='"'){if(inQ&&line[i+1]==='"'){cur+='"';i++}else inQ=!inQ}
    else if(line[i]===','&&!inQ){result.push(cur);cur=''}
    else cur+=line[i];
  }
  result.push(cur); return result;
}

// ── 食品DBのエクスポート・インポート（カスタム食品・複合食品） ──
// CSVは食事記録用で1行=1食品に丸めてしまうため、fa/aa/ingredientsなど構造を保てるJSONを別に用意する。
// 端末間の移行や、docs/llm-food-db-prompt.md のような外部LLMでのデータ拡充・見直しに使う想定。
const FOOD_DB_EXPORT_KIND = 'pfc-app-food-db';
function exportFoodDb(opts) {
  // opts: { kind, ids } を渡すと、その種別の選択した食品だけを書き出す（もう一方の種別は含めない）
  const only = opts && opts.ids ? opts : null;
  const payload = {
    kind: FOOD_DB_EXPORT_KIND, version: 1, exportedAt: new Date().toISOString(),
    customFoods: JSON.parse(JSON.stringify(only ? (only.kind === 'custom' ? customFoods.filter(f => only.ids.has(f.id)) : []) : customFoods)),
    comboFoods: JSON.parse(JSON.stringify(only ? (only.kind === 'combo' ? comboFoods.filter(f => only.ids.has(f.id)) : []) : comboFoods)),
  };
  const blob = new Blob([JSON.stringify(payload, null, 2)], { type: 'application/json' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url; a.download = `pfc_fooddb_${only ? 'selected_' : ''}${toDateStr(new Date())}.json`; a.click();
  URL.revokeObjectURL(url);
}
function handleFoodDbFileSelect(ev) {
  const file = ev.target.files && ev.target.files[0]; if (!file) return;
  const reader = new FileReader();
  reader.onload = () => { document.getElementById('fooddbImportArea').value = String(reader.result || ''); };
  reader.onerror = () => {
    const msg = document.getElementById('fooddbImportMsg');
    msg.className = 'status-msg status-err'; msg.textContent = 'ファイルの読み込みに失敗しました';
  };
  reader.readAsText(file, 'utf-8');
}
// 1件の食品オブジェクトを取り込み用に検証・整形する。cal/p/f/c/per が数値でない、または name が無いものは null（スキップ）
function sanitizeImportedFood(raw, kind) {
  if (!raw || typeof raw !== 'object') return null;
  const name = String(raw.name || '').trim();
  const per = parseFloat(raw.per);
  const cal = parseFloat(raw.cal), p = parseFloat(raw.p), f = parseFloat(raw.f), c = parseFloat(raw.c);
  if (!name || !isFinite(per) || per <= 0 || ![cal, p, f, c].every(isFinite)) return null;
  const yomi = sanitizeYomi(raw.yomi || '');
  const serving = parseFloat(raw.serving);
  const food = {
    id: Date.now() + Math.random(),
    name, ...(yomi ? { yomi } : {}), per,
    ...(isFinite(serving) && serving > 0 ? { serving } : {}),
    cal: Math.max(0, cal), p: Math.max(0, p), f: Math.max(0, f), c: Math.max(0, c),
    ...pickMicros(raw),
  };
  Object.assign(food, aiFiberSplit({ ...raw, name }));
  const fa = sanitizeFa(raw.fa), aa = sanitizeAa(raw.aa);
  if (fa) food.fa = fa; if (aa) food.aa = aa;
  if (typeof raw.en === 'string' && raw.en.trim()) food.en = raw.en.trim().slice(0, 120);
  if (typeof raw.tags === 'string' && raw.tags.trim()) food.tags = raw.tags.trim().slice(0, 200);
  { const cat = sanitizeCategory(raw.category) || guessFoodCategory(name); if (cat) food.category = cat; }
  { const u = sanitizeUnits(raw.units); if (u.length) food.units = u; }
  if (raw.digest) food.digest = raw.digest; else food.digest = classifyDigestCategory(name, p || 0);
  if (kind === 'combo' && Array.isArray(raw.ingredients)) {
    food.ingredients = raw.ingredients.map(ing => {
      const ip = parseFloat(ing.per) || 100, ia = parseFloat(ing.amount) || ip;
      return { name: String(ing.name || '材料'), amount: ia, per: ip,
        cal: parseFloat(ing.cal) || 0, p: parseFloat(ing.p) || 0, f: parseFloat(ing.f) || 0, c: parseFloat(ing.c) || 0,
        ...pickMicros(ing), ...aiFiberSplit({ ...ing, name: String(ing.name || '材料') }) };
    });
  }
  return food;
}
function importFoodDb() {
  const text = document.getElementById('fooddbImportArea').value.trim();
  const msg = document.getElementById('fooddbImportMsg');
  if (!text) { msg.className = 'status-msg status-err'; msg.textContent = 'JSONデータを入力してください'; return; }
  let data;
  try { data = JSON.parse(text); } catch (e) {
    msg.className = 'status-msg status-err'; msg.textContent = 'JSONの形式が正しくありません: ' + e.message; return;
  }
  // { customFoods, comboFoods } を含むオブジェクト、またはどちらか一方の配列そのものにも対応
  const customList = Array.isArray(data.customFoods) ? data.customFoods : (Array.isArray(data) ? data : []);
  const comboList = Array.isArray(data.comboFoods) ? data.comboFoods : [];
  if (!customList.length && !comboList.length) {
    msg.className = 'status-msg status-err'; msg.textContent = '食品データが見つかりませんでした（customFoods / comboFoods 配列が必要です）'; return;
  }
  takeAiBackup('食品DBインポート');
  let added = 0, updated = 0, skipped = 0;
  customList.forEach(raw => {
    const food = sanitizeImportedFood(raw, 'custom');
    if (!food) { skipped++; return; }
    const idx = customFoods.findIndex(f => normFoodName(f.name) === normFoodName(food.name));
    if (idx >= 0) { food.id = customFoods[idx].id; customFoods[idx] = food; updated++; }
    else { customFoods.push(food); added++; }
  });
  comboList.forEach(raw => {
    const food = sanitizeImportedFood(raw, 'combo');
    if (!food || !food.ingredients || !food.ingredients.length) { skipped++; return; }
    const idx = comboFoods.findIndex(f => normFoodName(f.name) === normFoodName(food.name));
    if (idx >= 0) { food.id = comboFoods[idx].id; comboFoods[idx] = food; updated++; }
    else { comboFoods.push(food); added++; }
  });
  saveCustom();
  if (typeof renderCustomFoodList === 'function') renderCustomFoodList();
  if (typeof renderComboFoodList === 'function') renderComboFoodList();
  msg.className = 'status-msg status-ok';
  msg.textContent = `追加${added}件・更新${updated}件${skipped ? `（スキップ${skipped}件）` : ''}を取り込みました`;
}

// ── Custom foods ──
function setCustomMode(mode) {
  document.getElementById('csSinglePanel').style.display=mode==='single'?'block':'none';
  document.getElementById('csComboPanel').style.display=mode==='combo'?'block':'none';
  document.getElementById('csTabSingle').className='btn'+(mode==='single'?' btn-primary':'');
  document.getElementById('csTabCombo').className='btn'+(mode==='combo'?' btn-success':'');
  if(mode==='single') renderCustomFoodList(); else renderComboFoodList();
}
function saveCustomFood() {
  const name=document.getElementById('csFoodName').value.trim(); const msg=document.getElementById('csSaveMsg');
  if(!name){msg.className='status-msg status-err';msg.textContent='食品名を入力してください';return}
  const yomi=sanitizeYomi(document.getElementById('csFoodYomi').value);
  const cat=sanitizeCategory(document.getElementById('csCat').value) || guessFoodCategory(name);
  customFoods.push({id:Date.now(),name,...(yomi?{yomi}:{}),...(cat?{category:cat}:{}),...(parseFloat(document.getElementById('csServing')?.value)>0?{serving:Math.min(parseFloat(document.getElementById('csServing').value),5000)}:{}),cal:gv('csCal'),p:gv('csP'),f:gv('csF'),c:gv('csC'),per:gv('csPer')||100,
    fiber:gv('csFib'),...fibSplitFromInput(document.getElementById('csFibS').value, gv('csFib')),iron:gv('csFe'),calcium:gv('csCa'),vitc:gv('csVc'),vitd:gv('csVd'),salt:gv('csSalt')});
  saveCustom(); msg.className='status-msg status-ok'; msg.textContent=`「${name}」を登録しました`;
  ['csFoodName','csFoodYomi','csCat','csServing','csCal','csP','csF','csC','csFib','csFibS','csFe','csCa','csVc','csVd','csSalt'].forEach(id=>document.getElementById(id).value='');
  document.getElementById('csPer').value='100'; renderCustomFoodList(); setTimeout(()=>{msg.textContent=''},2500);
}
function deleteCustomFood(id){
  const idx = customFoods.findIndex(f=>f.id===id);
  if (idx === -1) return;
  const removed = customFoods[idx];
  customFoods.splice(idx,1);
  if (editingCustomFoodId === id) editingCustomFoodId = null;
  saveCustom();renderCustomFoodList();
  showUndoToast(`「${removed.name}」をDBから削除しました`, () => {
    customFoods.splice(Math.min(idx, customFoods.length), 0, removed);
    saveCustom(); renderCustomFoodList();
  });
}
let editingCustomFoodId = null;
function startEditCustomFood(id) {
  editingCustomFoodId = id;
  renderCustomFoodList();
}
function cancelEditCustomFood() {
  editingCustomFoodId = null;
  renderCustomFoodList();
}
function saveEditCustomFood(id) {
  const idx = customFoods.findIndex(f => f.id === id);
  if (idx === -1) return;
  const gvSuf = (suf) => { const el = document.getElementById('ecf'+suf+id); return el ? (parseFloat(el.value) || 0) : 0; };
  const nameEl = document.getElementById('ecfName'+id);
  const name = nameEl ? nameEl.value.trim() : '';
  const msg = document.getElementById('csSaveMsg');
  if (!name) {
    if (msg) { msg.className = 'status-msg status-err'; msg.textContent = '食品名を入力してください'; }
    return;
  }
  if (customFoods.some((f,i) => i !== idx && normFoodName(f.name) === normFoodName(name))) {
    if (msg) { msg.className = 'status-msg status-err'; msg.textContent = `「${name}」は既に別のカスタム食品で使われています`; }
    return;
  }
  const yomiEl = document.getElementById('ecfYomi'+id);
  const yomi = yomiEl ? sanitizeYomi(yomiEl.value) : '';
  customFoods[idx] = {
    ...customFoods[idx],
    name,
    per:     gvSuf('Per') || 100,
    cal:     gvSuf('Cal'), p: gvSuf('P'), f: gvSuf('F'), c: gvSuf('C'),
    fiber:   gvSuf('Fib'), iron: gvSuf('Fe'), calcium: gvSuf('Ca'),
    vitc:    gvSuf('Vc'),  vitd: gvSuf('Vd'), salt: gvSuf('Salt'),
  };
  { // 水溶性の入力があれば内訳を保存、空欄なら内訳を外して自動（食品名から推定／区分不明）に戻す
    delete customFoods[idx].fibS; delete customFoods[idx].fibI;
    const fs = document.getElementById('ecfFibS'+id);
    Object.assign(customFoods[idx], fibSplitFromInput(fs ? fs.value : '', customFoods[idx].fiber));
  }
  if (yomi) customFoods[idx].yomi = yomi; else delete customFoods[idx].yomi; // 空欄なら自動推定に戻す
  { const catEl = document.getElementById('ecfCat'+id); const cat = catEl ? sanitizeCategory(catEl.value) : customFoods[idx].category;
    if (cat) customFoods[idx].category = cat; else delete customFoods[idx].category; }
  delete customFoods[idx].fibEst; // 手動で保存した値は推定扱いにしない
  { const sv = parseFloat(document.getElementById('ecfServing'+id)?.value); if (sv > 0) customFoods[idx].serving = Math.min(sv, 5000); else delete customFoods[idx].serving; }
  saveCustom();
  editingCustomFoodId = null;
  renderCustomFoodList();
  showToast(`「${name}」を更新しました`);
}
function renderCustomFoodList() {
  const cont=document.getElementById('customFoodList'); if(!cont) return;
  refreshFoodCatList(); renderFoodCatMgr();
  const view = getFoodDbView('custom'); renderFoodDbChrome('custom', view);
  if (!view.total) { cont.innerHTML=`<div style="font-size:12px;color:var(--text-sub);padding:8px 0">まだ登録がありません</div>`; return; }
  if (_fdServingMode.custom) {
    const rows = view.list.filter(({f}) => !_fdServUnsetOnly.custom || !(f.serving > 0));
    cont.innerHTML = rows.length ? rows.map(({f}) => servingRowHtml('custom', f)).join('') : `<div style="font-size:12px;color:var(--text-sub);padding:8px 0">${_fdServUnsetOnly.custom ? '未設定の食品はありません' : '条件に合う食品がありません'}</div>`;
    return;
  }
  if (!view.list.length) { cont.innerHTML=`<div style="font-size:12px;color:var(--text-sub);padding:8px 0">条件に合う食品がありません</div>`; return; }
  cont.innerHTML=view.list.map(({f})=>{
    if (editingCustomFoodId === f.id && !_fdSelectMode.custom) {
      return `<div class="custom-item" id="ecfBox${f.id}" style="flex-direction:column;align-items:stretch;gap:6px;padding:10px">
        <div class="row" style="margin-bottom:0"><div class="field" style="flex:3"><label>食品名</label><input type="text" id="ecfName${f.id}" value="${fdEsc(f.name)}"></div><div class="field" style="flex:1"><label>基準量(g)</label><input type="number" id="ecfPer${f.id}" value="${f.per}"></div></div>
        <div class="row" style="margin-bottom:0"><div class="field"><label>読み（任意・空欄で自動推定）</label><input type="text" id="ecfYomi${f.id}" value="${fdEsc(f.yomi||'')}" autocomplete="off"></div><div class="field"><label>カテゴリ</label><input type="text" id="ecfCat${f.id}" list="foodCatList" value="${fdEsc(f.category||'')}" placeholder="未分類" autocomplete="off"></div></div>
        <div class="row" style="margin-bottom:0"><div class="field"><label>kcal</label><input type="number" id="ecfCal${f.id}" value="${f.cal}" step="0.1"></div><div class="field"><label>P</label><input type="number" id="ecfP${f.id}" value="${f.p}" step="0.1"></div><div class="field"><label>F</label><input type="number" id="ecfF${f.id}" value="${f.f}" step="0.1"></div><div class="field"><label>C</label><input type="number" id="ecfC${f.id}" value="${f.c}" step="0.1"></div></div>
        <div class="row" style="margin-bottom:0"><div class="field"><label>食物繊維</label><input type="number" id="ecfFib${f.id}" value="${f.fiber||0}" step="0.1"></div><div class="field"><label>うち水溶性</label><input type="number" id="ecfFibS${f.id}" value="${fibSInputVal(f)}" placeholder="自動" step="0.1"></div><div class="field"><label>鉄</label><input type="number" id="ecfFe${f.id}" value="${f.iron||0}" step="0.1"></div><div class="field"><label>Ca</label><input type="number" id="ecfCa${f.id}" value="${f.calcium||0}" step="0.1"></div></div>
        <div class="row" style="margin-bottom:0"><div class="field"><label>VitC</label><input type="number" id="ecfVc${f.id}" value="${f.vitc||0}" step="0.1"></div><div class="field"><label>VitD</label><input type="number" id="ecfVd${f.id}" value="${f.vitd||0}" step="0.1"></div><div class="field"><label>塩分</label><input type="number" id="ecfSalt${f.id}" value="${f.salt||0}" step="0.01"></div><div class="field"><label>1食分(g)</label><input type="number" id="ecfServing${f.id}" value="${f.serving||''}" placeholder="${f.per}" step="1"></div></div>
        <div style="display:flex;gap:6px">
          <button class="btn btn-primary btn-sm" style="flex:1" onclick="saveEditCustomFood(${f.id})">保存</button>
          <button class="btn btn-sm" style="flex:1" onclick="cancelEditCustomFood()">取消</button>
        </div>
      </div>`;
    }
    const sp = (f.fiber > 0 && (f.fibS != null && f.fibI != null)) ? `（水${r1(f.fibS)}/不${r1(f.fibI)}）` : '';
    const used = view.usage.get(normFoodName(f.name)) || 0;
    const sel = _fdSelectMode.custom;
    return `<${sel ? 'label' : 'div'} class="custom-item${sel ? ' fd-selrow' : ''}">${sel ? foodDbCheck('custom', f) : ''}<div style="flex:1;min-width:0"><div style="font-weight:500">${fdEsc(f.name)} ${foodDbBadge(f)}</div><div style="font-size:10px;color:var(--text-sub)">${f.per}gあたり ${f.cal}kcal P${f.p} F${f.f} C${f.c}${f.fiber?' 繊'+f.fiber+sp:''}${used?` ・記録${used}回`:''}</div></div>${sel ? '' : foodDbActions('custom', f)}</${sel ? 'label' : 'div'}>`;
  }).join('');
}

// ── Combo foods ──
function onComboSearch(q) {
  const box=document.getElementById('comboResultsBox');
  if(!q.trim()){box.style.display='none';return}
  renderComboResults(localSearch(q));
}
function renderComboResults(local) {
  const box=document.getElementById('comboResultsBox'); let html='';
  if(local.length){html+=`<div class="rs-label">内蔵・カスタムDB</div>`;html+=local.map((f,i)=>`<div class="ri" onclick="addComboIngredient(${i})"><div><div class="ri-name">${f.name}<span class="badge badge-${f._src||'local'}">${SRC_LABEL[f._src||'local']}</span></div><div class="ri-sub">${f.per}gあたり P${f.p} F${f.f} C${f.c}</div></div><div class="ri-cal">${f.cal}kcal</div></div>`).join('')}
  else {html+=`<div class="no-result">見つかりませんでした</div>`}
  box.innerHTML=html; box._local=local; box.style.display='block';
}
// 複合食品の材料1件について、実量(amt g)あたりの栄養素を _cal/_p/... の形で計算する（全ミクロ栄養素を含む）
function comboScaled(f, amt) {
  const r = amt / (f.per || 100);
  const o = { amount: amt, _cal: r1((f.cal||0)*r), _p: r1((f.p||0)*r), _f: r1((f.f||0)*r), _c: r1((f.c||0)*r) };
  MICRO_KEYS.forEach(k => { o['_'+k] = microRound(k, (f[k]||0)*r); });
  return o;
}
function comboTotals(ings) {
  const t = { cal:0, p:0, f:0, c:0 }; MICRO_KEYS.forEach(k => { t[k] = 0; });
  ings.forEach(f => { ['cal','p','f','c',...MICRO_KEYS].forEach(k => { t[k] += (f['_'+k] || 0); }); });
  return t;
}
function addComboIngredient(i) {
  const box=document.getElementById('comboResultsBox'); const f=box._local && box._local[i]; if(!f) return;
  const per=f.per||100;
  if (comboReplaceIdx != null && comboIngredients[comboReplaceIdx]) {
    // 入れ替え: 元の材料の量(g)を引き継いで差し替える
    const keepAmt = comboIngredients[comboReplaceIdx].amount;
    comboIngredients[comboReplaceIdx] = {...f, per, ...comboScaled({...f, per}, keepAmt)};
    comboReplaceIdx = null; const inp = document.getElementById('comboSearch'); if (inp) inp.placeholder = '食材を検索…';
  } else {
    const amt=f.serving||per;
    comboIngredients.push({...f, per, ...comboScaled({...f, per}, amt)});
  }
  box.style.display='none'; document.getElementById('comboSearch').value=''; renderComboIngredients();
}
function updateComboAmt(i, val) {
  const f = comboIngredients[i];
  const amt = parseFloat(val);
  // 入力途中の空欄・無効値では amount を勝手に上書きしない（100gへの巻き戻りを防止）
  if (isNaN(amt) || amt <= 0) { updateComboTotal(); return; }
  comboIngredients[i]={...f, ...comboScaled(f, amt)};
  // 合計表示だけ更新し、入力欄のDOMは再生成しない（再生成すると入力中にフォーカスが外れてしまう）
  updateComboTotal();
}
function updateComboTotal() {
  if (!comboIngredients.length) { document.getElementById('comboTotal').textContent=''; return }
  const tot = comboTotals(comboIngredients);
  document.getElementById('comboTotal').textContent=`合計 ${ri(tot.cal)}kcal P${r1(tot.p)} F${r1(tot.f)} C${r1(tot.c)} 繊${r1(tot.fiber)}g`;
}
function removeComboIngredient(i){comboIngredients.splice(i,1);renderComboIngredients()}
let comboReplaceIdx = null; // 入れ替え待ちの材料の位置（検索で選んだ食材に、量を引き継いで差し替える）
function toggleComboReplace(i) {
  comboReplaceIdx = (comboReplaceIdx === i) ? null : i;
  const inp = document.getElementById('comboSearch');
  if (inp) { inp.placeholder = comboReplaceIdx != null ? `「${comboIngredients[i].name}」の代わりの食材を検索…` : '食材を検索…'; if (comboReplaceIdx != null) { inp.scrollIntoView({ behavior: 'smooth', block: 'center' }); inp.focus(); } }
  renderComboIngredients();
}
function renderComboIngredients() {
  const cont=document.getElementById('comboIngredients');
  if (comboReplaceIdx != null && !comboIngredients[comboReplaceIdx]) comboReplaceIdx = null;
  if(!comboIngredients.length){cont.innerHTML=`<div style="font-size:12px;color:var(--text-sub);padding:4px 0">食材を検索して追加してください</div>`;document.getElementById('comboTotal').textContent='';return}
  cont.innerHTML=comboIngredients.map((f,i)=>`<div class="combo-ingredient"${comboReplaceIdx===i?' style="outline:2px solid #3266ad;border-radius:7px"':''}><span style="font-weight:500;flex:1">${fdEsc(f.name)}${comboReplaceIdx===i?' <span class="fd-badge" style="background:#3266ad;color:#fff">入れ替え待ち</span>':''}</span><input type="number" value="${f.amount}" min="1" style="width:50px;font-size:12px;padding:2px 5px;border:1px solid var(--border);border-radius:7px;background:var(--surface);color:var(--text);margin:0 6px" oninput="updateComboAmt(${i},this.value)"><span style="font-size:10px;color:var(--text-sub);margin-right:5px">g</span><button class="btn btn-sm" style="margin-right:4px" title="別の食材に入れ替え（量は引き継ぎ）" onclick="toggleComboReplace(${i})">⇄</button><button class="btn btn-sm btn-danger" onclick="removeComboIngredient(${i})">✕</button></div>`).join('');
  updateComboTotal();
}
function editComboFood(id) {
  const f = comboFoods.find(f => f.id === id);
  if (!f) return;
  // 編集対象をフォームに展開
  document.getElementById('comboName').value = f.name;
  document.getElementById('comboYomi').value = f.yomi || '';
  document.getElementById('comboCat').value = f.category || '';
  // 食材リストを復元
  comboIngredients = (f.ingredients || []).map(ing => {
    const per = ing.per || 100;
    const amount = ing.amount || per;
    return { ...ing, per, ...comboScaled({ ...ing, per }, amount) };
  });
  renderComboIngredients();
  // 保存ボタンを「更新」モードにする
  const btn = document.getElementById('comboSaveBtn');
  const msg = document.getElementById('comboSaveMsg');
  btn.textContent = '更新';
  btn.dataset.editId = id;
  msg.textContent = `「${f.name}」を編集中`;
  msg.className = 'status-msg status-ok';
  renderComboFoodList();
  // フォームまでスクロール
  document.getElementById('csComboPanel').scrollIntoView({ behavior: 'smooth', block: 'start' });
}

function saveComboFood() {
  const name = document.getElementById('comboName').value.trim();
  const msg  = document.getElementById('comboSaveMsg');
  const btn  = document.getElementById('comboSaveBtn');
  if (!name) { msg.className='status-msg status-err'; msg.textContent='複合食品名を入力してください'; return }
  if (!comboIngredients.length) { msg.className='status-msg status-err'; msg.textContent='食材を追加してください'; return }

  const tot = comboTotals(comboIngredients);
  const totalAmt = comboIngredients.reduce((a,f) => a + f.amount, 0);

  const editId = btn.dataset.editId ? Number(btn.dataset.editId) : null;

  // 100gあたりに正規化せず、実際に作った総重量を基準量(per)にする
  // → 記録タブで選ぶ際のデフォルト量が「100g」ではなく「作った分そのまま」になる
  const yomi = sanitizeYomi(document.getElementById('comboYomi').value);
  const catIn = sanitizeCategory(document.getElementById('comboCat').value);
  const foodData = {
    id: editId || Date.now(),
    name, ...(yomi ? { yomi } : {}), per: r1(totalAmt), serving: r1(totalAmt),
    cal: r1(tot.cal), p: r1(tot.p), f: r1(tot.f), c: r1(tot.c),
    ...Object.fromEntries(MICRO_KEYS.map(k => [k, microRound(k, tot[k])])),
    ingredients: comboIngredients.map(f => ({
      name: f.name, amount: f.amount,
      per: f.per || 100, cal: f.cal, p: f.p, f: f.f, c: f.c,
      ...Object.fromEntries(MICRO_KEYS.map(k => [k, f[k]||0])),
    })),
    digest: 'mixed',
    _src: 'combo',
  };

  if (editId) {
    // 編集時は元の食品の項目（タグ・英名など）を引き継ぐ。読み・カテゴリは入力欄の内容を優先
    const prev = comboFoods.find(f => f.id === editId) || {};
    const merged = { ...prev, ...foodData };
    if (!yomi) delete merged.yomi;
    if (catIn) merged.category = catIn; else delete merged.category;
    delete merged.fibEst;
    comboFoods = comboFoods.map(f => f.id === editId ? merged : f);
    msg.textContent = `「${name}」を更新しました`;
  } else {
    const cat = catIn || guessFoodCategory(name);
    comboFoods.push(cat ? { ...foodData, category: cat } : foodData);
    msg.textContent = `「${name}」を登録しました`;
  }

  // フォームリセット
  btn.textContent = '複合食品として登録';
  delete btn.dataset.editId;
  comboIngredients = [];
  document.getElementById('comboName').value = '';
  document.getElementById('comboYomi').value = '';
  document.getElementById('comboCat').value = '';
  renderComboIngredients();
  saveCustom();
  msg.className = 'status-msg status-ok';
  renderComboFoodList();
  setTimeout(() => { msg.textContent = ''; }, 2500);
}

function deleteComboFood(id) {
  const idx = comboFoods.findIndex(f => f.id === id);
  if (idx === -1) return;
  const removed = comboFoods[idx];
  comboFoods.splice(idx, 1);
  // 削除対象を編集中だった場合はフォームを登録モードに戻す
  const btn = document.getElementById('comboSaveBtn');
  if (btn && btn.dataset.editId && Number(btn.dataset.editId) === id) resetComboForm();
  saveCustom();
  renderComboFoodList();
  showUndoToast(`「${removed.name}」を複合食品DBから削除しました`, () => {
    comboFoods.splice(Math.min(idx, comboFoods.length), 0, removed);
    saveCustom(); renderComboFoodList();
  });
}

function renderComboFoodList() {
  const cont = document.getElementById('comboFoodList'); if (!cont) return;
  refreshFoodCatList(); renderFoodCatMgr();
  const view = getFoodDbView('combo'); renderFoodDbChrome('combo', view);
  if (!view.total) { cont.innerHTML = `<div style="font-size:12px;color:var(--text-sub);padding:8px 0">まだ登録がありません</div>`; return; }
  if (!view.list.length) { cont.innerHTML = `<div style="font-size:12px;color:var(--text-sub);padding:8px 0">条件に合う食品がありません</div>`; return; }
  if (_fdServingMode.combo) {
    const rows = view.list.filter(({f}) => !_fdServUnsetOnly.combo || !(f.serving > 0));
    cont.innerHTML = rows.length ? rows.map(({f}) => servingRowHtml('combo', f)).join('') : `<div style="font-size:12px;color:var(--text-sub);padding:8px 0">${_fdServUnsetOnly.combo ? '未設定の食品はありません' : '条件に合う食品がありません'}</div>`;
    return;
  }
  const editing = Number(document.getElementById('comboSaveBtn')?.dataset.editId) || null;
  cont.innerHTML = view.list.map(({f}) => {
    const used = view.usage.get(normFoodName(f.name)) || 0;
    const sp = (f.fiber > 0 && (f.fibS != null && f.fibI != null)) ? `（水${r1(f.fibS)}/不${r1(f.fibI)}）` : '';
    const sel = _fdSelectMode.combo;
    return `<${sel ? 'label' : 'div'} class="custom-item${sel ? ' fd-selrow' : ''}"${editing === f.id && !sel ? ' style="outline:2px solid var(--primary, #3266ad)"' : ''}>
      ${sel ? foodDbCheck('combo', f) : ''}
      <div style="flex:1;min-width:0">
        <div style="font-weight:500">${fdEsc(f.name)} ${foodDbBadge(f)}${editing === f.id ? ' <span class="fd-badge" style="background:#3266ad;color:#fff">編集中</span>' : ''}</div>
        <div style="font-size:10px;color:var(--text-sub)">全量${f.per}gで ${ri(f.cal)}kcal P${r1(f.p)} F${r1(f.f)} C${r1(f.c)}${f.fiber?' 繊'+r1(f.fiber)+sp:''}${used?` ・記録${used}回`:''}</div>
        <div style="font-size:10px;color:var(--text-sub)">${(f.ingredients||[]).map(i=>`${fdEsc(i.name)}(${i.amount}g)`).join('、')}</div>
      </div>
      ${sel ? '' : foodDbActions('combo', f)}
    </${sel ? 'label' : 'div'}>`;
  }).join('');
}

// ══ 食品登録タブ：簡易データベース機能（検索・カテゴリ・ソート・複製・編集）══
const FOOD_CATEGORIES = ['主食','主菜','副菜','果物','乳製品','間食・菓子','飲料','調味料','外食・惣菜','サプリ・プロテイン','その他'];
// 名前からのカテゴリ推定（先勝ち）。登録時にカテゴリが空のときの既定値と「自動分類」ボタンで使う。外れたら編集で直せる
const FOOD_CAT_RULES = [
  [/プロテインバー|バー$|チョコ|クッキー|ケーキ|ドーナツ|せんべい|煎餅|八ツ橋|月餅|アイス|シャーベット|プリン|杏仁|スナック|ナチョス|ポテチ|菓子|ブラックサンダー|グミ|キャンディ/, '間食・菓子'],
  [/プロテイン|サプリ|EAA|BCAA|クレアチン|青汁|MCT|ウィダー|ゼリー飲料/, 'サプリ・プロテイン'],
  [/ラーメン|スシロー|はま寿司|くら寿司|定食|弁当|ランチ|セット|丼|牛めし|カレー(?!ルー)|ソーキそば|餃子|唐揚|から揚|惣菜|外食|店|チェーン/, '外食・惣菜'],
  [/醤油|しょうゆ|味噌|みそ|ソース|ルー|タレ|たれ|ドレッシング|マヨ|ケチャップ|酢|油|スパイス|だし|出汁|サンバル|コチュジャン|豆板|塩|砂糖|みりん|ごま油|ハチミツ|はちみつ|シロップ/, '調味料'],
  [/チーズ|ヨーグルト|牛乳|バター|クリーム|fromage|フロマージュ|モッツァレラ|フェタ|パルミジャーノ|ペコリーノ|エメンタール|カッテージ/, '乳製品'],
  [/ビール|ワイン|チューハイ|ハイボール|ジュース|コーヒー|ラテ|紅茶|茶|スムージー|コーラ|サイダー|酒|ミルク|豆乳|飲料|水/, '飲料'],
  [/りんご|バナナ|みかん|オレンジ|いちご|苺|ぶどう|キウイ|アボカド|デーツ|ベリー|フルーツ|果物|もも|梨|柿|マンゴー|パイン|メロン|すいか|レモン|プルーン|レーズン/, '果物'],
  [/ご飯|ごはん|米|パン|pain|麺|パスタ|うどん|そば|ビリヤニ|オートミール|粉|餅|シリアル|グラノーラ|ナン|トルティーヤ|タコス|ライ麦|全粒/, '主食'],
  [/肉|鶏|豚|牛|ひき|ささみ|魚|さけ|鮭|サバ|さば|サメ|いわし|イワシ|鱈|たら|ツナ|エビ|海老|イカ|スルメ|卵|たまご|豆腐|納豆|ハム|ソーセージ|パテ|ベーコン|七面鳥|ランチョンミート|大豆ミート|ウラド|豆/, '主菜'],
  [/野菜|サラダ|ピクルス|キャベツ|トマト|小鉢|煮|和え|きのこ|ひじき|わかめ|海藻|漬物|キムチ|スープ|汁|ビーツ|ごぼう|にんじん|ほうれん草|ブロッコリー/, '副菜'],
];
function guessFoodCategory(name) { const n = String(name || ''); for (const [re, c] of FOOD_CAT_RULES) if (re.test(n)) return c; return ''; }
function sanitizeCategory(v) { return typeof v === 'string' ? v.trim().replace(/\s+/g, ' ').slice(0, 16) : ''; }
const FOOD_DB_SORTS = [['new','登録が新しい順'],['old','登録が古い順'],['name','名前順（あいうえお）'],['cat','カテゴリ順'],['usage','よく使う順（記録回数）'],
  ['cal','カロリー(100g)が高い順'],['cal_asc','カロリー(100g)が低い順'],['p','たんぱく質(100g)が多い順'],['fiber','食物繊維(100g)が多い順']];
let _foodDbPrefs = (() => { try { return JSON.parse(localStorage.getItem('pfcFoodDbView') || '{}') || {}; } catch (e) { return {}; } })();
const _foodDbQuery = { custom: '', combo: '' };
function foodDbPref(kind) { const v = _foodDbPrefs[kind] || {}; return { cat: v.cat || 'all', sort: v.sort || 'new' }; }
function setFoodDbPref(kind, patch) { _foodDbPrefs[kind] = { ...foodDbPref(kind), ...patch }; try { localStorage.setItem('pfcFoodDbView', JSON.stringify(_foodDbPrefs)); } catch (e) {} }
function foodDbList(kind) { return kind === 'combo' ? comboFoods : customFoods; }
function renderFoodDbList(kind) { if (kind === 'combo') renderComboFoodList(); else renderCustomFoodList(); }
function fdEsc(s) { return String(s == null ? '' : s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;'); }
function allFoodCategories() { const set = new Set(FOOD_CATEGORIES); [...customFoods, ...comboFoods].forEach(f => { if (f.category) set.add(f.category); }); return [...set]; }
function refreshFoodCatList() { const dl = document.getElementById('foodCatList'); if (dl) dl.innerHTML = allFoodCategories().map(c => `<option value="${fdEsc(c)}"></option>`).join(''); }
function foodUsageMap() { const m = new Map(); entries.forEach(e => { const k = normFoodName(e.name); m.set(k, (m.get(k) || 0) + 1); }); return m; }
function foodPer100(f, k) { return (f[k] || 0) / (f.per || 100) * 100; }
function foodDbMatches(f, q, qv) {
  if (!q) return true;
  if (searchScore(withSearchFields({ ...f }, 'x'), q, qv) > 0) return true; // 名前・読み・ローマ字・タグ（通常の食品検索と同じ照合）
  const nq = normalize(q);
  if (f.category && normalize(f.category).includes(nq)) return true;
  return Array.isArray(f.ingredients) && f.ingredients.some(i => normalize(i.name || '').includes(nq)); // 複合食品は材料名でも検索できる
}
function getFoodDbView(kind) {
  const all = foodDbList(kind), pref = foodDbPref(kind), q = (_foodDbQuery[kind] || '').trim();
  const qv = q ? queryVariants(q) : null, usage = foodUsageMap();
  const bySearch = all.map((f, i) => ({ f, i })).filter(x => foodDbMatches(x.f, q, qv));
  const catCounts = new Map(); bySearch.forEach(x => { const c = x.f.category || ''; catCounts.set(c, (catCounts.get(c) || 0) + 1); });
  const list = bySearch.filter(x => pref.cat === 'all' ? true : pref.cat === '__none__' ? !x.f.category : x.f.category === pref.cat);
  const nameKey = f => normalize(f.yomi || guessYomi(f.name) || f.name || '');
  const cmpName = (a, b) => nameKey(a.f).localeCompare(nameKey(b.f), 'ja');
  const catOrder = c => { if (!c) return 999; const k = FOOD_CATEGORIES.indexOf(c); return k >= 0 ? k : 100; };
  const byNum = (fn, dir) => (a, b) => dir * (fn(a.f) - fn(b.f)) || cmpName(a, b);
  const sorters = {
    new: (a, b) => (b.f.id || 0) - (a.f.id || 0) || b.i - a.i,
    old: (a, b) => (a.f.id || 0) - (b.f.id || 0) || a.i - b.i,
    name: cmpName,
    cat: (a, b) => catOrder(a.f.category) - catOrder(b.f.category) || (a.f.category || '').localeCompare(b.f.category || '', 'ja') || cmpName(a, b),
    usage: (a, b) => (usage.get(normFoodName(b.f.name)) || 0) - (usage.get(normFoodName(a.f.name)) || 0) || cmpName(a, b),
    cal: byNum(f => foodPer100(f, 'cal'), -1), cal_asc: byNum(f => foodPer100(f, 'cal'), 1),
    p: byNum(f => foodPer100(f, 'p'), -1), fiber: byNum(f => foodPer100(f, 'fiber'), -1),
  };
  list.sort(sorters[pref.sort] || sorters.new);
  return { list, total: all.length, matched: bySearch.length, catCounts, usage, pref, q };
}
function renderFoodDbChrome(kind, view) {
  const sel = document.getElementById('fdSort_' + kind);
  if (sel) { if (!sel.options.length) sel.innerHTML = FOOD_DB_SORTS.map(([v, l]) => `<option value="${v}">${l}</option>`).join(''); sel.value = view.pref.sort; }
  const chips = document.getElementById('fdChips_' + kind);
  if (chips) {
    const mk = (val, label, n) => `<button class="fd-chip${view.pref.cat === val ? ' on' : ''}" data-cat="${fdEsc(val)}" onclick="onFoodDbCat('${kind}', this.dataset.cat)">${fdEsc(label)}<span>${n}</span></button>`;
    const ordered = allFoodCategories().filter(c => view.catCounts.has(c) || view.pref.cat === c);
    chips.innerHTML = mk('all', 'すべて', view.matched)
      + ordered.map(c => mk(c, c, view.catCounts.get(c) || 0)).join('')
      + (view.catCounts.has('') || view.pref.cat === '__none__' ? mk('__none__', '未分類', view.catCounts.get('') || 0) : '');
  }
  const cnt = document.getElementById('fdCount_' + kind);
  if (cnt) cnt.textContent = view.total ? `${view.list.length}件を表示${view.list.length !== view.total ? `（全${view.total}件中）` : ''}` : '';
}
const _fdSelectMode = { custom: false, combo: false };
const _fdSel = { custom: new Set(), combo: new Set() };
let _fdCatMgrOpen = false;
function foodDbCheck(kind, f) { return `<input type="checkbox" class="fd-check" ${_fdSel[kind].has(f.id) ? 'checked' : ''} onchange="onFoodDbToggle('${kind}', ${f.id}, this.checked)">`; }
function onFoodDbToggle(kind, id, on) { if (on) _fdSel[kind].add(id); else _fdSel[kind].delete(id); updateFoodBulkCount(kind); }
function updateFoodBulkCount(kind) { const el = document.getElementById('fdBulkCount_' + kind); if (el) el.textContent = `${_fdSel[kind].size}件を選択中`; }
// 目安量（1食分のグラム数）の一括見直しモード: 全食品の1食分を一覧で見て、その場で直せる
const _fdServingMode = { custom: false, combo: false };
const _fdServUnsetOnly = { custom: false, combo: false };
function servingRowHtml(kind, f) {
  const sv = f.serving > 0 ? f.serving : f.per, per = f.per || 100;
  return `<div class="custom-item fd-servrow"><div style="flex:1;min-width:0"><div style="font-weight:500">${fdEsc(f.name)} ${foodDbBadge(f)}</div><div style="font-size:10px;color:var(--text-sub)" id="fdSvInfo_${kind}_${f.id}">${servingInfoText(f, sv)}</div></div>
    <div class="fd-sv"><input type="number" inputmode="decimal" min="0" step="1" value="${f.serving > 0 ? f.serving : ''}" placeholder="${per}" oninput="onFoodServingInput('${kind}', ${f.id}, this.value)" onchange="commitFoodServing('${kind}', ${f.id}, this.value)"><span>g</span></div>
    <div class="fd-units-row"><span>単位</span><input type="text" class="fd-units" value="${fdEsc(unitsToText(f.units))}" placeholder="例: 個=50, 切れ=30" onchange="commitFoodUnits('${kind}', ${f.id}, this.value)" autocomplete="off"></div></div>`;
}
function servingInfoText(f, sv) { const per = f.per || 100, r = sv / per; return `${f.serving > 0 ? '1食分' : '未設定（基準量'+per+'gで記録）'} ${r1(sv)}g = ${ri(f.cal * r)}kcal P${r1(f.p * r)} F${r1(f.f * r)} C${r1(f.c * r)}`; }
function onFoodServingInput(kind, id, v) { // 入力中は保存せず、表示だけ更新
  const f = foodDbList(kind).find(x => x.id === id), el = document.getElementById(`fdSvInfo_${kind}_${id}`); if (!f || !el) return;
  const n = parseFloat(v); const sv = n > 0 ? Math.min(n, 5000) : (f.per || 100);
  el.textContent = servingInfoText({ ...f, serving: n > 0 ? n : 0 }, sv);
}
function commitFoodServing(kind, id, v) {
  const f = foodDbList(kind).find(x => x.id === id); if (!f) return;
  const raw = String(v).trim(), n = parseFloat(raw);
  if (raw === '') delete f.serving; else if (n > 0) f.serving = Math.min(n, 5000); else { renderFoodDbList(kind); return; } // 0や不正値は無視して元に戻す
  saveCustom();
  const el = document.getElementById(`fdSvInfo_${kind}_${id}`); if (el) el.textContent = servingInfoText(f, f.serving > 0 ? f.serving : (f.per || 100));
  if (_fdServUnsetOnly[kind]) renderFoodDbList(kind);
}
// 単位（「個=50, 切れ=30」の形式）を保存する。数量シートの単位ボタンと、検索欄の「卵2個」で使われる
function commitFoodUnits(kind, id, v) {
  const f = foodDbList(kind).find(x => x.id === id); if (!f) return;
  const raw = String(v).trim();
  if (raw === '') delete f.units;
  else { const u = parseUnitsText(raw); if (!u.length) { showToast('単位は「個=50, 切れ=30」の形式で入力してください'); renderFoodDbList(kind); return; } f.units = u; }
  saveCustom(); renderFoodDbList(kind);
}
function toggleFoodServingMode(kind) {
  if (_fdSelectMode[kind]) toggleFoodSelectMode(kind); // 選択モードとは同時に使わない
  _fdServingMode[kind] = !_fdServingMode[kind]; if (kind === 'custom') editingCustomFoodId = null;
  const btn = document.getElementById('fdServBtn_' + kind), bar = document.getElementById('fdServBar_' + kind);
  if (btn) btn.textContent = _fdServingMode[kind] ? '目安量を終了' : '目安量';
  if (bar) bar.innerHTML = !_fdServingMode[kind] ? '' : `<div class="fd-bulk"><div style="font-size:11px;line-height:1.5;margin-bottom:6px">各食品の<b>1食分(g)</b>を入力します。記録タブで選んだときの初期量になります（空欄＝基準量）。</div>
    <label style="font-size:12px;display:flex;align-items:center;gap:6px"><input type="checkbox" class="fd-check" ${_fdServUnsetOnly[kind] ? 'checked' : ''} onchange="_fdServUnsetOnly['${kind}']=this.checked;renderFoodDbList('${kind}')">未設定のものだけ表示</label></div>`;
  renderFoodDbList(kind);
}
function toggleFoodSelectMode(kind) {
  if (_fdServingMode[kind]) toggleFoodServingMode(kind); // 目安量モードとは同時に使わない
  _fdSelectMode[kind] = !_fdSelectMode[kind]; _fdSel[kind].clear();
  if (_fdSelectMode[kind] && kind === 'custom') editingCustomFoodId = null;
  const box = document.getElementById('fdBulk_' + kind), btn = document.getElementById('fdSelBtn_' + kind);
  if (btn) btn.textContent = _fdSelectMode[kind] ? '選択を終了' : '選択';
  if (box) box.innerHTML = !_fdSelectMode[kind] ? '' : `<div class="fd-bulk">
      <div class="fd-bulk-row"><b id="fdBulkCount_${kind}">0件を選択中</b><span style="flex:1"></span><button class="btn btn-sm" onclick="fdSelectAll('${kind}')">表示中をすべて選択</button><button class="btn btn-sm" onclick="fdSelectNone('${kind}')">解除</button></div>
      <div class="fd-bulk-row"><input type="text" id="fdBulkCat_${kind}" list="foodCatList" placeholder="カテゴリ（空欄＝未分類にする）" autocomplete="off"><button class="btn btn-sm btn-primary" onclick="fdBulkCategory('${kind}')">カテゴリ変更</button><button class="btn btn-sm btn-danger" onclick="fdBulkDelete('${kind}')">削除</button></div>
      <div class="fd-bulk-row"><button class="btn btn-sm" onclick="fdBulkExport('${kind}')">選択した食品だけ書き出し（JSON）</button></div>
    </div>`;
  renderFoodDbList(kind);
}
function fdSelectAll(kind) { getFoodDbView(kind).list.forEach(x => _fdSel[kind].add(x.f.id)); renderFoodDbList(kind); updateFoodBulkCount(kind); }
function fdSelectNone(kind) { _fdSel[kind].clear(); renderFoodDbList(kind); updateFoodBulkCount(kind); }
function fdBulkCategory(kind) {
  const ids = _fdSel[kind]; if (!ids.size) { showToast('食品を選択してください'); return; }
  const cat = sanitizeCategory(document.getElementById('fdBulkCat_' + kind).value);
  const prev = [];
  foodDbList(kind).forEach(f => { if (ids.has(f.id)) { prev.push([f, f.category]); if (cat) f.category = cat; else delete f.category; } });
  saveCustom(); _fdSel[kind].clear(); renderFoodDbList(kind); updateFoodBulkCount(kind); renderFoodCatMgr();
  showUndoToast(`${prev.length}件のカテゴリを「${cat || '未分類'}」にしました`, () => {
    prev.forEach(([f, c]) => { if (c) f.category = c; else delete f.category; });
    saveCustom(); renderFoodDbList(kind); renderFoodCatMgr();
  });
}
function fdBulkExport(kind) {
  const ids = _fdSel[kind]; if (!ids.size) { showToast('食品を選択してください'); return; }
  exportFoodDb({ kind, ids }); showToast(`${ids.size}件を書き出しました`);
}
function fdBulkDelete(kind) {
  const ids = _fdSel[kind]; if (!ids.size) { showToast('食品を選択してください'); return; }
  if (!confirm(`選択した${ids.size}件を削除しますか？（直後なら「元に戻す」で復元できます）`)) return;
  const list = foodDbList(kind), removed = [];
  list.forEach((f, i) => { if (ids.has(f.id)) removed.push([i, f]); });
  const keep = list.filter(f => !ids.has(f.id));
  if (kind === 'combo') { comboFoods = keep; const btn = document.getElementById('comboSaveBtn'); if (btn && btn.dataset.editId && ids.has(Number(btn.dataset.editId))) resetComboForm(); }
  else customFoods = keep;
  _fdSel[kind].clear(); saveCustom(); renderFoodDbList(kind); updateFoodBulkCount(kind); renderFoodCatMgr();
  showUndoToast(`${removed.length}件を削除しました`, () => {
    const arr = foodDbList(kind); removed.forEach(([i, f]) => arr.splice(Math.min(i, arr.length), 0, f)); // 元の位置へ戻す（昇順で挿入）
    saveCustom(); renderFoodDbList(kind); renderFoodCatMgr();
  });
}
// カテゴリ管理: 名前変更（既存名にすると統合）・削除（未分類に戻す）。単品・複合の両方に反映する
function toggleFoodCatMgr() { _fdCatMgrOpen = !_fdCatMgrOpen; renderFoodCatMgr(); }
function renderFoodCatMgr() {
  const counts = new Map(); [...customFoods, ...comboFoods].forEach(f => { if (f.category) counts.set(f.category, (counts.get(f.category) || 0) + 1); });
  const html = !_fdCatMgrOpen ? '' : `<div class="fd-bulk"><div style="font-size:11px;font-weight:500;margin-bottom:6px">カテゴリ管理（単品・複合の全体に反映）</div>`
    + (counts.size ? [...counts.entries()].sort((a, b) => a[0].localeCompare(b[0], 'ja')).map(([c, n]) =>
        `<div class="fd-bulk-row" style="margin-bottom:4px"><span style="flex:1;font-size:12px">${fdEsc(c)} <span style="color:var(--text-sub);font-size:10px">${n}件</span></span><button class="btn btn-sm" data-cat="${fdEsc(c)}" onclick="renameFoodCategory(this.dataset.cat)">名前変更</button><button class="btn btn-sm btn-danger" data-cat="${fdEsc(c)}" onclick="deleteFoodCategory(this.dataset.cat)">削除</button></div>`).join('')
      : `<div style="font-size:11px;color:var(--text-sub)">カテゴリが付いた食品がありません</div>`) + `</div>`;
  ['custom', 'combo'].forEach(k => { const el = document.getElementById('fdCatMgr_' + k); if (el) el.innerHTML = html; });
}
function applyCategoryChange(oldC, newC) {
  const changed = [];
  [...customFoods, ...comboFoods].forEach(f => { if (f.category === oldC) { changed.push(f); if (newC) f.category = newC; else delete f.category; } });
  return changed;
}
function renameFoodCategory(oldC) {
  const input = typeof prompt === 'function' ? prompt(`カテゴリ「${oldC}」の新しい名前\n（既にあるカテゴリ名を入力すると統合されます）`, oldC) : null;
  const newC = sanitizeCategory(input || ''); if (!newC || newC === oldC) return;
  const changed = applyCategoryChange(oldC, newC);
  setFoodDbPrefFixAfterRename(oldC, newC);
  saveCustom(); renderCustomFoodList(); renderComboFoodList(); renderFoodCatMgr();
  showUndoToast(`カテゴリ「${oldC}」を「${newC}」に変更しました（${changed.length}件）`, () => {
    changed.forEach(f => { f.category = oldC; }); saveCustom(); renderCustomFoodList(); renderComboFoodList(); renderFoodCatMgr();
  });
}
function deleteFoodCategory(c) {
  if (!confirm(`カテゴリ「${c}」を削除しますか？（該当する食品は「未分類」になります。食品自体は消えません）`)) return;
  const changed = applyCategoryChange(c, '');
  setFoodDbPrefFixAfterRename(c, '__none__');
  saveCustom(); renderCustomFoodList(); renderComboFoodList(); renderFoodCatMgr();
  showUndoToast(`カテゴリ「${c}」を削除しました（${changed.length}件が未分類）`, () => {
    changed.forEach(f => { f.category = c; }); saveCustom(); renderCustomFoodList(); renderComboFoodList(); renderFoodCatMgr();
  });
}
function setFoodDbPrefFixAfterRename(oldC, newC) { ['custom', 'combo'].forEach(k => { if (foodDbPref(k).cat === oldC) setFoodDbPref(k, { cat: newC }); }); }
function foodDbBadge(f) { return f.category ? `<span class="fd-badge">${fdEsc(f.category)}</span>` : `<span class="fd-badge fd-none">未分類</span>`; }
function foodDbActions(kind, f) {
  const edit = kind === 'combo' ? 'editComboFood' : 'startEditCustomFood', dup = kind === 'combo' ? 'duplicateComboFood' : 'duplicateCustomFood', del = kind === 'combo' ? 'deleteComboFood' : 'deleteCustomFood';
  return `<div class="fd-actions"><button class="btn btn-sm fd-edit" onclick="${edit}(${f.id})">編集</button><button class="btn btn-sm" onclick="${dup}(${f.id})">複製</button><button class="btn btn-sm btn-danger" onclick="${del}(${f.id})">✕</button></div>`;
}
// 食品登録タブを開き、指定の食品を（名前で絞り込んで）一覧に表示する。nameが空なら新しい順で全件
function openFoodDbItem(kind, name) {
  switchTab('custom'); setCustomMode(kind === 'combo' ? 'combo' : 'single');
  if (kind !== 'combo') cancelEditCustomFood();
  setFoodDbPref(kind, { cat: 'all', sort: name ? foodDbPref(kind).sort : 'new' });
  _foodDbQuery[kind] = name || ''; const inp = document.getElementById('fdSearch_' + kind); if (inp) inp.value = name || '';
  renderFoodDbList(kind);
  const list = document.getElementById(kind === 'combo' ? 'comboFoodList' : 'customFoodList'); if (list) list.scrollIntoView({ behavior: 'smooth', block: 'start' });
}
function onFoodDbSearch(kind, v) { _foodDbQuery[kind] = v; renderFoodDbList(kind); }
function onFoodDbSort(kind, v) { setFoodDbPref(kind, { sort: v }); renderFoodDbList(kind); }
function onFoodDbCat(kind, v) { setFoodDbPref(kind, { cat: v }); renderFoodDbList(kind); }
function resetComboForm() {
  comboReplaceIdx = null; { const inp = document.getElementById('comboSearch'); if (inp) inp.placeholder = '食材を検索…'; }
  const btn = document.getElementById('comboSaveBtn'), msg = document.getElementById('comboSaveMsg');
  if (btn) { btn.textContent = '複合食品として登録'; delete btn.dataset.editId; }
  comboIngredients = [];
  ['comboName', 'comboYomi', 'comboCat'].forEach(id => { const el = document.getElementById(id); if (el) el.value = ''; });
  renderComboIngredients(); if (msg) msg.textContent = '';
}
function focusFoodForm(kind) {
  if (kind === 'combo') resetComboForm(); else cancelEditCustomFood();
  const el = document.getElementById(kind === 'combo' ? 'comboName' : 'csFoodName');
  if (el) { el.scrollIntoView({ behavior: 'smooth', block: 'center' }); el.focus(); }
}
function autoCategorizeFoods(kind) {
  const changed = [];
  foodDbList(kind).forEach(f => { if (!f.category) { const c = guessFoodCategory(f.name); if (c) { f.category = c; changed.push(f); } } });
  const left = foodDbList(kind).filter(f => !f.category).length;
  if (!changed.length) { showToast(left ? `名前から分類できる食品はありませんでした（未分類${left}件）` : 'すべて分類済みです'); return; }
  saveCustom(); renderFoodDbList(kind);
  showUndoToast(`${changed.length}件を自動分類しました${left ? `（未分類${left}件は手動で設定）` : ''}`, () => { changed.forEach(f => { delete f.category; }); saveCustom(); renderFoodDbList(kind); });
}
function uniqueFoodName(base) {
  const taken = n => [...customFoods, ...comboFoods].some(f => normFoodName(f.name) === normFoodName(n));
  let n = `${base}のコピー`, i = 2; while (taken(n)) n = `${base}のコピー(${i++})`;
  return n;
}
function duplicateCustomFood(id) {
  const idx = customFoods.findIndex(f => f.id === id); if (idx === -1) return;
  const copy = JSON.parse(JSON.stringify(customFoods[idx]));
  copy.id = Date.now() + Math.random(); copy.name = uniqueFoodName(copy.name); delete copy.yomi;
  customFoods.splice(idx + 1, 0, copy); saveCustom();
  editingCustomFoodId = copy.id; _foodDbQuery.custom = ''; { const el = document.getElementById('fdSearch_custom'); if (el) el.value = ''; }
  if (foodDbPref('custom').cat !== 'all' && foodDbPref('custom').cat !== (copy.category || '__none__')) setFoodDbPref('custom', { cat: 'all' });
  renderCustomFoodList();
  const nm = document.getElementById('ecfName' + copy.id); if (nm) { nm.scrollIntoView({ behavior: 'smooth', block: 'center' }); nm.focus(); nm.select && nm.select(); }
  showToast(`「${copy.name}」を複製しました。名前などを編集して保存してください`);
}
function duplicateComboFood(id) {
  const idx = comboFoods.findIndex(f => f.id === id); if (idx === -1) return;
  const copy = JSON.parse(JSON.stringify(comboFoods[idx]));
  copy.id = Date.now() + Math.random(); copy.name = uniqueFoodName(copy.name); delete copy.yomi;
  comboFoods.splice(idx + 1, 0, copy); saveCustom();
  _foodDbQuery.combo = ''; { const el = document.getElementById('fdSearch_combo'); if (el) el.value = ''; }
  if (foodDbPref('combo').cat !== 'all' && foodDbPref('combo').cat !== (copy.category || '__none__')) setFoodDbPref('combo', { cat: 'all' });
  renderComboFoodList();
  editComboFood(copy.id); // 複製した食品を編集フォームに読み込む（名前・分量を直して「更新」）
  showToast(`「${copy.name}」を複製しました。名前や分量を編集して更新してください`);
}

// ── Google Health API ──
// REST API (health.googleapis.com/v4/) + OAuth 2.0
// スコープ: activity_and_fitness, health_metrics_and_measurements, sleep
// 取得: 歩数・消費カロリー・安静時心拍数・体重

async function connectGoogleHealth() {
  try {
    const res = await fetch('/.netlify/functions/google-health-auth-start');
    if (!res.ok) throw new Error('auth start failed');
    const { authUrl } = await res.json();
    window.location.href = authUrl;
  } catch(e) {
    alert('Google Health連携の開始に失敗しました。\nNetlifyの環境変数（GOOGLE_HEALTH_CLIENT_ID）を確認してください。');
  }
}

(function checkGoogleHealthCallback() {
  const params = new URLSearchParams(window.location.hash.replace(/^#/, ''));
  const token = params.get('gh_token');
  const err   = params.get('gh_error');
  if (err) {
    console.warn('Google Health auth error:', err);
    history.replaceState({}, '', window.location.pathname + window.location.search);
    return;
  }
  if (token) {
    ghToken = token;
    localStorage.setItem('ghToken', token);
    history.replaceState({}, '', window.location.pathname + window.location.search);
    renderGhStatus();
    syncGoogleHealth();
  }
})();

async function syncGoogleHealth() {
  if (!ghToken) return;
  try {
    const res = await fetch(
      `/.netlify/functions/google-health-daily?date=${currentDate}`,
      { headers: { 'X-Gh-Token': ghToken } }
    );
    if (!res.ok) throw new Error('sync failed');
    const data = await res.json();
    if (data.updatedToken && data.updatedToken !== ghToken) {
      ghToken = data.updatedToken;
      localStorage.setItem('ghToken', ghToken);
    }
    ghData[currentDate] = sanitizeGhData({ [currentDate]: data })[currentDate];
    saveGhData();
    document.getElementById('garminSyncBtn').style.display = 'flex';
    renderRecord();
  } catch(e) { console.warn('Google Health sync:', e); }
}

function renderGhStatus() {
  const btn    = document.getElementById('garminConnectBtn');
  const status = document.getElementById('garminStatus');
  if (ghToken) {
    btn.textContent = '再接続';
    const lastDate = Object.keys(ghData).sort().pop();
    const d = lastDate ? ghData[lastDate] : null;
    status.innerHTML =
      `<span style="color:var(--green);font-weight:600">✓ 接続済み</span>` +
      (d ? `<br><span style="font-size:11px;margin-top:4px;display:block">
        最終同期: ${lastDate}　歩数: ${(d.steps||0).toLocaleString()}歩　
        消費: ${d.activeCalories||0} kcal
        ${d.restingHeartRate ? `　心拍: ${d.restingHeartRate} bpm` : ''}
        ${d.weight ? `　体重: ${d.weight} kg` : ''}
      </span>` : '');
    document.getElementById('garminSyncBtn').style.display = 'flex';
  } else {
    btn.textContent = '連携する';
    status.textContent = '未接続';
  }
}

// ── Firebase 初期化・認証・同期 ──
// Firebase設定は index.html の <script> で window.FIREBASE_CONFIG として注入
async function initFirebase() {
  try {
    const cfg = window.FIREBASE_CONFIG;
    if (!cfg || !cfg.apiKey) { markInitialSyncDone(); return; } // 未設定時はローカルのみ

    const { initializeApp }    = await import('https://www.gstatic.com/firebasejs/10.12.0/firebase-app.js');
    const { getAuth, GoogleAuthProvider, signInWithPopup, signOut, onAuthStateChanged }
                                = await import('https://www.gstatic.com/firebasejs/10.12.0/firebase-auth.js');
    const { getFirestore }     = await import('https://www.gstatic.com/firebasejs/10.12.0/firebase-firestore.js');

    const app = initializeApp(cfg);
    fbAuth = getAuth(app);
    fbDb   = getFirestore(app);

    // 認証状態の監視
    onAuthStateChanged(fbAuth, async user => {
      fbUser = user;
      renderAuthUI();
      if (user) {
        await pullFromCloud(); // ログイン時にクラウドからデータを取得
        renderRecord();
        renderCalendar();
      }
      markInitialSyncDone(); // ここでゲート解除（未ログインなら即解除、ログイン時はpull完了後に解除）
    });

    // Googleログインボタン
    window._fbSignIn = async () => {
      try {
        const provider = new GoogleAuthProvider();
        await signInWithPopup(fbAuth, provider);
      } catch(e) {
        console.error('Sign in failed:', e);
        if (e.code === 'auth/unauthorized-domain') {
          alert(
            'ログインエラー: このドメインがFirebaseに承認されていません。\n\n' +
            '【解決方法】\n' +
            'Firebase Console > Authentication > Settings >\n' +
            '「承認済みドメイン」に以下を追加してください：\n\n' +
            window.location.hostname
          );
        } else if (e.code === 'auth/popup-blocked') {
          alert('ポップアップがブロックされました。ブラウザのポップアップ許可設定を確認してください。');
        } else {
          alert('ログインに失敗しました: ' + (e.message || e.code));
        }
      }
    };

    // ログアウトボタン
    window._fbSignOut = async () => {
      await signOut(fbAuth);
      renderAuthUI();
    };

  } catch(e) {
    console.warn('Firebase init failed:', e);
    markInitialSyncDone();
  }
}

// Firestoreからデータを取得してローカルにマージ
// クラウドのデータを画面側へ反映する。配列系はクラウド優先、日別の歩数/Google Healthデータは日付ごとに統合（同じ日はクラウド優先、端末にだけある日は残す）
// 戻り値: 端末にだけあるデータが残った（＝クラウドへ送り直す必要がある）か
function applyCloudData(data) {
  let needUpload = false;
  if (data.entries)     { entries     = data.entries; }
  if (data.exercises)   { exercises   = data.exercises; }
  if (data.customFoods) { customFoods = data.customFoods; }
  if (data.comboFoods)  { comboFoods  = data.comboFoods; }
  saveLocal();
  if (data.quickSeasonings) { quickSeasonings = data.quickSeasonings; saveQuickSeasoningsLocal(); renderQuickSeasonings(); }
  if (data.profile)     { profile = migrateNeatTier({ ...profile, ...data.profile }); localStorage.setItem('pfcProfile', JSON.stringify(profile)); }
  const mergeDays = (local, cloud) => { const lk = Object.keys(local || {}); const merged = { ...(local || {}), ...(cloud || {}) }; if (lk.some(k => !cloud || !(k in cloud))) needUpload = true; return merged; };
  if (data.dailyActivity || Object.keys(dailyActivity).length) { dailyActivity = mergeDays(dailyActivity, data.dailyActivity); try { localStorage.setItem('pfcDailyActivity', JSON.stringify(dailyActivity)); } catch (e) {} }
  if (data.ghData || Object.keys(ghData).length) { ghData = sanitizeGhData(mergeDays(ghData, sanitizeGhData(data.ghData))); try { localStorage.setItem('ghData', JSON.stringify(ghData)); } catch (e) {} }
  { // AIプロンプトの雛形: クラウドにあればそれを使う。クラウドに無く、端末に保存済み（編集済み）の雛形があれば送り直す
    const cloudTpl = sanitizePromptTemplates(data.promptTemplates);
    if (cloudTpl) { promptTemplates = cloudTpl; try { localStorage.setItem('pfcPromptTemplates', JSON.stringify(promptTemplates)); } catch (e) {} if (typeof renderPromptTemplates === 'function') renderPromptTemplates(); }
    else if (localStorage.getItem('pfcPromptTemplates')) needUpload = true;
  }
  if (data.updatedAt) _lastCloudStamp = data.updatedAt;
  return needUpload;
}
function refreshViewsAfterCloud() {
  ['renderRecord', 'renderCalendar', 'renderExerciseItems', 'renderCustomFoodList', 'renderComboFoodList', 'renderBmrPreview', 'renderActivityCard'].forEach(fn => { try { if (typeof window[fn] === 'function') window[fn](); else if (typeof eval('typeof ' + fn) === 'string' && eval('typeof ' + fn) === 'function') eval(fn + '()'); } catch (e) { /* 表示の更新失敗は無視 */ } });
}
async function pullFromCloud() {
  if (!fbDb || !fbUser || fbSyncing) return;
  fbSyncing = true;
  try {
    const { doc, getDoc } = await fsApi();
    const snap = await getDoc(doc(fbDb, 'users', fbUser.uid));
    if (snap.exists()) {
      const needUpload = applyCloudData(snap.data());
      if (needUpload) queueCloudSave();   // 端末にだけあった歩数データなどをクラウドへ送る（ゲート解除後に送信される）
    } else {
      // 初回ログイン：ローカルデータをクラウドにアップロード
      await saveToCloud();
    }
  } catch(e) {
    console.warn('Cloud pull failed:', e);
    logCloudError(`クラウドからの読み込みに失敗しました（${(e && (e.code || e.message)) || e}）`, '');
  } finally {
    fbSyncing = false;
  }
}
// アプリが前面に戻ったとき、他の端末で更新されていれば読み込み直す。
// 起動時にしか読み込まないと、開きっぱなしの端末が古い内容のまま保存して、他の端末の変更を上書きしてしまうため。
// 未送信の変更・送信中・入力中のときは、手元の変更を守るため読み込まない
async function pullOnForeground() {
  if (!fbDb || !fbUser || !initialSyncDone || fbSyncing || cloudDirty || _cloudInFlight) return;
  if (Date.now() - _lastForegroundPull < 15000) return;
  const ae = document.activeElement; if (ae && /^(INPUT|TEXTAREA|SELECT)$/.test(ae.tagName) && ae.type !== 'checkbox') return;
  _lastForegroundPull = Date.now(); fbSyncing = true;
  try {
    const { doc, getDoc } = await fsApi();
    const snap = await getDoc(doc(fbDb, 'users', fbUser.uid));
    if (!snap.exists()) return;
    const data = snap.data();
    if (data.updatedAt && data.updatedAt === _lastCloudStamp) return;     // 変更なし
    if (cloudDirty || _cloudInFlight) return;                                // 取得している間に端末側で変更があった → 手元を優先
    const needUpload = applyCloudData(data);
    refreshViewsAfterCloud();
    if (typeof showToast === 'function') showToast('他の端末の変更を反映しました');
    if (needUpload) queueCloudSave();
  } catch (e) {
    console.warn('Foreground pull failed:', e);
    logCloudError(`クラウドからの読み込みに失敗しました（${(e && (e.code || e.message)) || e}）`, '');
  } finally { fbSyncing = false; }
}

// 認証UIを描画（ヘッダーのユーザー情報 & ログインボタン）
function renderAuthUI() {
  const el = document.getElementById('authArea');
  if (!el) return;
  if (fbUser) {
    const photo = fbUser.photoURL
      ? `<img src="${fbUser.photoURL}" style="width:28px;height:28px;border-radius:50%;border:2px solid rgba(255,255,255,.5)" alt="">`
      : `<span style="font-size:18px">👤</span>`;
    el.innerHTML = `
      <div style="display:flex;align-items:center;gap:8px">
        ${photo}
        <div>
          <div style="font-size:11px;font-weight:600;max-width:100px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap">${fbUser.displayName||fbUser.email}</div>
          <div style="font-size:9px;opacity:.7">クラウド同期中</div>
        </div>
        <button onclick="_fbSignOut()" style="background:rgba(255,255,255,.2);border:none;color:#fff;border-radius:6px;padding:4px 8px;font-size:10px;cursor:pointer">ログアウト</button>
      </div>`;
  } else if (window.FIREBASE_CONFIG && window.FIREBASE_CONFIG.apiKey) {
    el.innerHTML = `
      <button onclick="_fbSignIn()" style="display:flex;align-items:center;gap:6px;background:rgba(255,255,255,.9);border:none;color:#333;border-radius:8px;padding:6px 10px;font-size:11px;cursor:pointer;font-weight:500">
        <svg width="14" height="14" viewBox="0 0 24 24"><path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"/><path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"/><path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z"/><path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z"/></svg>
        Googleでログイン
      </button>`;
  } else {
    el.innerHTML = `<span style="font-size:10px;opacity:.6">ローカル保存モード</span>`;
  }
}

// ── Tab switch ──
function switchTab(t) {
  ['record','stats','custom','csv','profile','garmin','ai'].forEach(id => {
    document.getElementById('panel-'+id).classList.toggle('active', id===t);
    document.getElementById('nav-'+id).classList.toggle('active', id===t);
  });
  if (t==='record') { renderRecord(); renderCalendar(); }
  if (t==='stats') renderStats();
  if (t==='custom') setCustomMode('single');
  if (t==='csv') {
    const today=toDateStr(new Date()), month=today.slice(0,7)+'-01';
    document.getElementById('csvFrom').value=month;
    document.getElementById('csvTo').value=today;
  }
  if (t==='profile') { initProfile(); initGoalUI(); }
  if (t==='garmin')  renderGhStatus();
  if (t==='ai') initAiChat();
}

// ── AI Chat ──
let aiHistory = [];
let aiInitDone = false;

// ── AI バックアップ（最大10世代） ──
const AI_BACKUP_MAX = 10;
let aiBackups = []; // [{label, entries, timestamp}, ...]

function takeAiBackup(label) {
  aiBackups.push({
    label,
    entries: JSON.parse(JSON.stringify(entries)),
    customFoods: JSON.parse(JSON.stringify(customFoods)),
    comboFoods: JSON.parse(JSON.stringify(comboFoods)),
    quickSeasonings: JSON.parse(JSON.stringify(quickSeasonings)),
    timestamp: new Date().toISOString(),
  });
  if (aiBackups.length > AI_BACKUP_MAX) aiBackups.shift();
  renderAiBackupList();
}

function restoreAiBackup(idx) {
  const bk = aiBackups[idx];
  if (!bk) return;
  entries = JSON.parse(JSON.stringify(bk.entries));
  if (bk.customFoods) customFoods = JSON.parse(JSON.stringify(bk.customFoods));
  if (bk.comboFoods)  comboFoods  = JSON.parse(JSON.stringify(bk.comboFoods));
  if (bk.quickSeasonings) quickSeasonings = JSON.parse(JSON.stringify(bk.quickSeasonings));
  save(); saveCustom(); saveQuickSeasonings(); renderRecord(); renderCalendar();
  if (typeof renderCustomFoodList === 'function') renderCustomFoodList();
  if (typeof renderComboFoodList === 'function') renderComboFoodList();
  renderQuickSeasonings();
  appendAiMessage('ai', `♻️ バックアップを復元しました\n「${bk.label}」（${fmtBackupTime(bk.timestamp)}）`);
  renderAiBackupList();
}

function deleteAiBackup(idx) {
  aiBackups.splice(idx, 1);
  renderAiBackupList();
}

function fmtBackupTime(iso) {
  const d = new Date(iso);
  return `${d.getMonth()+1}/${d.getDate()} ${String(d.getHours()).padStart(2,'0')}:${String(d.getMinutes()).padStart(2,'0')}`;
}

function renderAiBackupList() {
  const cont = document.getElementById('aiBackupList');
  if (!cont) return;
  if (!aiBackups.length) {
    cont.innerHTML = '<div style="font-size:11px;color:var(--text-sub);padding:6px 0">バックアップはまだありません</div>';
    return;
  }
  cont.innerHTML = [...aiBackups].reverse().map((bk, ri) => {
    const idx = aiBackups.length - 1 - ri;
    return `<div style="display:flex;align-items:center;gap:6px;padding:5px 0;border-bottom:1px solid var(--border)">
      <div style="flex:1;min-width:0">
        <div style="font-size:12px;font-weight:500;overflow:hidden;text-overflow:ellipsis;white-space:nowrap">${bk.label}</div>
        <div style="font-size:10px;color:var(--text-sub)">${fmtBackupTime(bk.timestamp)}　${bk.entries.length}件</div>
      </div>
      <button onclick="restoreAiBackup(${idx})" style="background:#e8f0fe;color:#3266ad;border:none;border-radius:7px;padding:4px 9px;font-size:11px;cursor:pointer;white-space:nowrap">復元</button>
      <button onclick="deleteAiBackup(${idx})" style="background:none;border:none;color:var(--text-sub);font-size:14px;cursor:pointer;padding:2px 4px">✕</button>
    </div>`;
  }).join('');
}

function handleAiKey(e) {
  if (e.key !== 'Enter') return;
  // スマホ（ソフトキーボード）判定: pointerの細かさ or maxTouchPoints
  const isMobile = navigator.maxTouchPoints > 0 && window.matchMedia('(pointer: coarse)').matches;
  if (isMobile) {
    // スマホ: Enterは常に改行（送信はボタンのみ）
    return;
  }
  // PC: Shift+Enterで改行、Enterで送信
  if (!e.shiftKey) {
    e.preventDefault();
    sendAiMessage();
  }
}

function resetAiChat() {
  aiHistory = [];
  const box = document.getElementById('aiChatBox');
  if (box) box.innerHTML = '';
  appendAiMessage('ai', '会話をリセットしました。新たな質問や操作をどうぞ。');
}
function initAiChat() {
  if (aiInitDone) return;
  aiInitDone = true;
  renderAiBackupList();
  appendAiMessage('ai',
    'こんにちは！食事記録のアシスタントです🍽️\n\n' +
    '【できること】\n' +
    '・「朝食に卵とご飯を食べた」→ 自動で栄養計算＆登録\n' +
    '・「今週の昼食を全部サラダチキンで登録して」→ 複数日まとめて操作\n' +
    '・「昨日の夕食を削除して」→ 記録の削除\n' +
    '・「今週の記録を教えて」→ 記録の読み取り＆集計\n\n' +
    '操作前に自動でバックアップを保存します。\n' +
    '誤操作した場合は下のバックアップ一覧から復元できます。\n\n' +
    '⚠️ 栄養データはAI推定値です。目安としてご利用ください。'
  );
}

function appendAiMessage(role, text) {
  const box = document.getElementById('aiChatBox');
  if (!box) return;
  const isAi = role === 'ai';
  const div = document.createElement('div');
  div.style.cssText = `
    max-width: 88%;
    align-self: ${isAi ? 'flex-start' : 'flex-end'};
    background: ${isAi ? 'var(--surface)' : 'var(--accent)'};
    color: ${isAi ? 'var(--text)' : '#fff'};
    border-radius: ${isAi ? '4px 14px 14px 14px' : '14px 4px 14px 14px'};
    padding: 9px 12px;
    font-size: 13px;
    line-height: 1.6;
    white-space: pre-wrap;
    word-break: break-word;
    border: ${isAi ? '1px solid var(--border)' : 'none'};
  `;
  div.textContent = text;
  box.appendChild(div);
  box.scrollTop = box.scrollHeight;
  return div;
}

function appendAiThinking() {
  const box = document.getElementById('aiChatBox');
  if (!box) return null;
  const div = document.createElement('div');
  div.style.cssText = `
    align-self: flex-start;
    background: var(--surface);
    border: 1px solid var(--border);
    border-radius: 4px 14px 14px 14px;
    padding: 9px 14px;
    font-size: 18px;
    letter-spacing: 4px;
  `;
  div.textContent = '●○○';
  let frame = 0;
  div._timer = setInterval(() => {
    const dots = ['●○○','●●○','●●●','○●●','○○●','○○○'];
    div.textContent = dots[frame++ % dots.length];
  }, 300);
  box.appendChild(div);
  box.scrollTop = box.scrollHeight;
  return div;
}

// 日付ユーティリティ
function getWeekDates(baseDate) {
  // baseDate の週（月〜日）の日付リストを返す
  const d = new Date(baseDate + 'T00:00:00');
  const day = d.getDay(); // 0=日
  const monday = new Date(d); monday.setDate(d.getDate() - (day === 0 ? 6 : day - 1));
  return Array.from({length: 7}, (_, i) => {
    const dd = new Date(monday); dd.setDate(monday.getDate() + i); return toDateStr(dd);
  });
}
function getLastNDates(n, base) {
  const ref = new Date((base || currentDate) + 'T00:00:00');
  return Array.from({length: n}, (_, i) => {
    const d = new Date(ref); d.setDate(ref.getDate() - (n - 1 - i)); return toDateStr(d);
  });
}
function dateLabel(ds) {
  const d = new Date(ds + 'T00:00:00');
  const dow = ['日','月','火','水','木','金','土'][d.getDay()];
  return `${d.getMonth()+1}/${d.getDate()}(${dow})`;
}

// 全記録のサマリーをAIに渡す文字列を生成
function buildFullContext() {
  const lines = [];
  const TODAY = currentDate;
  const RECENT_DAYS = 14; // 詳細表示する直近日数
  const SUMMARY_DAYS = 44; // 日次サマリーで表示する直近日数（RECENT_DAYSを含む）。
  // これより古い記録は、使い続けるほど際限なく増えていって毎回のAI送信サイズを圧迫しないよう、
  // 個別の日を並べず1行の集計（件数・期間・平均）にまとめる

  // ── プロフィール ──
  const sexLabel = profile.sex === 'male' ? '男性' : '女性';
  const actLabel = ({1.2:'座位中心',1.375:'軽い運動',1.55:'中程度',1.725:'激しい運動',1.9:'非常に激しい'})[String(profile.activityFactor)] || String(profile.activityFactor);
  const actDesc = describeActivity(getTdeeBreakdown(TODAY));
  lines.push('【プロフィール】');
  lines.push(`性別:${sexLabel} 年齢:${profile.age} 身長:${profile.height}cm 体重:${profile.weight}kg 活動:${actDesc}`);

  // ── 目標値 ──
  const g = goals();
  lines.push(`【目標】cal:${g.cal} P:${g.p} F:${g.f} C:${g.c}`);

  // ── カスタム食品DB（名前のみ・トークン節約） ──
  // 件数が多くなってきた場合は直近登録分に絞り、それより古いものは search_food_db での
  // オンデマンド検索に任せる（一覧の目的は「重複登録の防止」なので、直近分だけでも大半のケースをカバーできる）
  const NAME_LIST_CAP = 150;
  const capNames = (list) => {
    const names = list.map(f => f.name);
    return names.length > NAME_LIST_CAP
      ? names.slice(-NAME_LIST_CAP).join('、') + `（他${names.length - NAME_LIST_CAP}件は表示省略。search_food_dbで検索可）`
      : names.join('、');
  };
  if (customFoods.length) lines.push('【カスタム食品】' + capNames(customFoods));
  // ── 複合食品DB（名前のみ・トークン節約） ──
  if (comboFoods.length) lines.push('【複合食品】' + capNames(comboFoods));
  // ── 調味料クイック登録（ラベルのみ・トークン節約） ──
  if (quickSeasonings.length) {
    lines.push('【調味料クイック登録】' + quickSeasonings.map(s => s.label).join('、'));
  }

  // ── 食事記録 ──
  // 直近14日：食品レベルの詳細（id付き）
  // それ以前：日次サマリーのみ
  const recentCutoff = (() => {
    const d = new Date(TODAY + 'T00:00:00');
    d.setDate(d.getDate() - RECENT_DAYS + 1);
    return toDateStr(d);
  })();

  const grouped = {};
  entries.forEach(e => {
    if (!grouped[e.date]) grouped[e.date] = {};
    if (!grouped[e.date][e.meal]) grouped[e.date][e.meal] = [];
    grouped[e.date][e.meal].push(e);
  });

  const allDates = Object.keys(grouped).sort();
  const recentDates = allDates.filter(d => d >= recentCutoff);
  const oldDates    = allDates.filter(d => d <  recentCutoff);

  if (recentDates.length) {
    lines.push(`【食事記録 直近${RECENT_DAYS}日（詳細）】`);
    recentDates.forEach(date => {
      const dayEntries = entries.filter(e => e.date === date);
      const s = sumEntries(dayEntries);
      lines.push(`${dateLabel(date)} [${Math.round(s.cal)}kcal P${r1(s.p)} F${r1(s.f)} C${r1(s.c)}]`);
      Object.entries(grouped[date]).forEach(([meal, foods]) => {
        lines.push(`  ${meal}: ${foods.map(e => `${e.name}(${e.amount}g,${Math.round(e.cal)}kcal,id:${e.id})`).join('、')}`);
      });
    });
  }

  if (oldDates.length) {
    const summaryCutoff = (() => {
      const d = new Date(TODAY + 'T00:00:00');
      d.setDate(d.getDate() - SUMMARY_DAYS + 1);
      return toDateStr(d);
    })();
    const summaryDates = oldDates.filter(d => d >= summaryCutoff);
    const archiveDates  = oldDates.filter(d => d <  summaryCutoff);

    if (summaryDates.length) {
      lines.push('【食事記録 過去分（日次サマリー）】');
      summaryDates.forEach(date => {
        const dayEntries = entries.filter(e => e.date === date);
        const s = sumEntries(dayEntries);
        lines.push(`${date} ${Math.round(s.cal)}kcal P${r1(s.p)} F${r1(s.f)} C${r1(s.c)}`);
      });
    }
    if (archiveDates.length) {
      const archEntries = entries.filter(e => archiveDates.includes(e.date));
      const s = sumEntries(archEntries);
      const n = archiveDates.length;
      lines.push(`【食事記録 それ以前（集計のみ）】${archiveDates[0]}〜${archiveDates[archiveDates.length-1]} 記録${n}日分・1日平均 ${Math.round(s.cal/n)}kcal P${r1(s.p/n)} F${r1(s.f/n)} C${r1(s.c/n)}`);
    }
  }

  if (!entries.length) lines.push('【食事記録】なし');

  // ── 運動記録 ──
  if (exercises.length) {
    const recentEx = exercises.filter(e => e.date >= recentCutoff);
    const oldEx    = exercises.filter(e => e.date <  recentCutoff);
    if (recentEx.length) {
      lines.push('【運動記録 直近】');
      const exGrouped = {};
      recentEx.forEach(e => { (exGrouped[e.date] = exGrouped[e.date]||[]).push(e); });
      Object.entries(exGrouped).sort().forEach(([d, exs]) => {
        lines.push(`${dateLabel(d)}: ${exs.map(e=>`${e.name}(${e.minutes||'?'}分,消費${Math.round(e.cal)}kcal,id:${e.id})`).join('、')}`);
      });
    }
    if (oldEx.length) {
      const totalOldCal = Math.round(oldEx.reduce((a,e)=>a+(e.cal||0),0));
      lines.push(`【運動記録 過去分】${oldEx.length}件 合計消費${totalOldCal}kcal`);
    }
  }

  return lines.join('\n');
}

// コマンド実行エンジン
function executeAiCommands(commands, backupLabel) {
  // 変更前にバックアップを保存
  takeAiBackup(backupLabel || 'AI操作');
  const log = [];
  let changed = false;

  commands.forEach(cmd => {
   try {
    // ── ADD ──
    if (cmd.type === 'add') {
      const dates = cmd.dates || [cmd.date || currentDate];
      const meal  = ['朝食','昼食','夕食','間食'].includes(cmd.meal) ? cmd.meal : '間食';
      dates.forEach(date => {
        let addedCount = 0, skippedCount = 0;
        (cmd.items || [cmd]).forEach(item => {
          if (!item.name) { skippedCount++; return; }
          const aiEntry = {
            id: Date.now() + Math.random(),
            date, meal,
            time:    item.time || nowTimeStr(),
            name:    item.name,
            amount:  parseFloat(item.amount)  || 100,
            cal:     parseFloat(item.cal)     || 0,
            p:       parseFloat(item.p)       || 0,
            f:       parseFloat(item.f)       || 0,
            c:       parseFloat(item.c)       || 0,
            fiber:   parseFloat(item.fiber)   || 0,
            ...aiFiberSplit(item),
            iron:    parseFloat(item.iron)    || 0,
            calcium: parseFloat(item.calcium) || 0,
            vitc:    parseFloat(item.vitc)    || 0,
            vitd:    parseFloat(item.vitd)    || 0,
            vita:    parseFloat(item.vita)    || 0,
            vite:    parseFloat(item.vite)    || 0,
            vitk:    parseFloat(item.vitk)    || 0,
            iodine:  parseFloat(item.iodine)  || 0,
            salt:    parseFloat(item.salt)    || 0,
          };
          enrichFoodProfile(aiEntry);
          addOrMergeEntry(aiEntry);
          addedCount++;
        });
        if (addedCount > 0) {
          log.push(`✅ ${dateLabel(date)} ${meal}に${addedCount}件登録${skippedCount ? `（名前の無い品目${skippedCount}件をスキップ）` : ''}`);
        } else {
          const msg = `${dateLabel(date)} ${meal}: 有効な品目が無く、何も登録されませんでした`;
          log.push(`⚠️ ${msg}`);
          logError('AI操作', msg, JSON.stringify(cmd).slice(0, 500));
        }
      });
      changed = true;
    }

    // ── DELETE_BY_ID ──
    else if (cmd.type === 'delete_by_id') {
      const ids = Array.isArray(cmd.ids) ? cmd.ids : [cmd.id];
      const before = entries.length;
      entries = entries.filter(e => !ids.includes(e.id));
      log.push(`🗑️ ${before - entries.length}件削除`);
      changed = true;
    }

    // ── DELETE_BY_DATE_MEAL ──
    else if (cmd.type === 'delete_by_date_meal') {
      const dates = cmd.dates || [cmd.date];
      const meal  = cmd.meal || null;
      const before = entries.length;
      entries = entries.filter(e => {
        if (!dates.includes(e.date)) return true;
        if (meal && e.meal !== meal) return true;
        return false;
      });
      log.push(`🗑️ ${before - entries.length}件削除（${dates.map(dateLabel).join('、')} ${meal||'全食事'}）`);
      changed = true;
    }

    // ── REPLACE ──（指定日時のmealを全削除→新規追加）
    else if (cmd.type === 'replace') {
      const dates = cmd.dates || [cmd.date || currentDate];
      const meal  = ['朝食','昼食','夕食','間食'].includes(cmd.meal) ? cmd.meal : '間食';
      dates.forEach(date => {
        const before = entries.length;
        entries = entries.filter(e => !(e.date === date && e.meal === meal));
        const removed = before - entries.length;
        let addedCount = 0, skippedCount = 0;
        (cmd.items || []).forEach(item => {
          if (!item.name) { skippedCount++; return; }
          const aiEntry = {
            id: Date.now() + Math.random(),
            date, meal,
            time:    item.time || nowTimeStr(),
            name:    item.name,
            amount:  parseFloat(item.amount)  || 100,
            cal:     parseFloat(item.cal)     || 0,
            p:       parseFloat(item.p)       || 0,
            f:       parseFloat(item.f)       || 0,
            c:       parseFloat(item.c)       || 0,
            fiber:   parseFloat(item.fiber)   || 0,
            ...aiFiberSplit(item),
            iron:    parseFloat(item.iron)    || 0,
            calcium: parseFloat(item.calcium) || 0,
            vitc:    parseFloat(item.vitc)    || 0,
            vitd:    parseFloat(item.vitd)    || 0,
            vita:    parseFloat(item.vita)    || 0,
            vite:    parseFloat(item.vite)    || 0,
            vitk:    parseFloat(item.vitk)    || 0,
            iodine:  parseFloat(item.iodine)  || 0,
            salt:    parseFloat(item.salt)    || 0,
          };
          enrichFoodProfile(aiEntry);
          addOrMergeEntry(aiEntry);
          addedCount++;
        });
        log.push(`🔄 ${dateLabel(date)} ${meal}を置き換え（旧${removed}件→新${addedCount}件${skippedCount ? `・名前の無い品目${skippedCount}件をスキップ` : ''}）`);
        if (addedCount === 0 && (cmd.items || []).length > 0) {
          const msg = `${dateLabel(date)} ${meal}: 置き換え後、有効な品目が無く空になりました`;
          logError('AI操作', msg, JSON.stringify(cmd).slice(0, 500));
        }
      });
      changed = true;
    }
    // ── ADD_CUSTOM_FOOD ──（カスタム食品DBへの登録）
    else if (cmd.type === 'add_custom_food') {
      // AIが foods 以外の形（food:{...} / items:[...] / custom_foods:[...]）で返しても受け付ける
      const foods = Array.isArray(cmd.foods) ? cmd.foods
        : Array.isArray(cmd.custom_foods) ? cmd.custom_foods
        : Array.isArray(cmd.items) ? cmd.items
        : (cmd.food && typeof cmd.food === 'object') ? [cmd.food] : [cmd];
      foods.forEach(food => {
        if (!food.name) { log.push('⚠️ 食品名(name)が指定されていない項目があり、登録できませんでした（コマンドの形式が不正）'); return; }
        if (customFoods.some(f => normFoodName(f.name) === normFoodName(food.name))) {
          log.push(`ℹ️ 「${food.name}」は既にカスタム食品DBに登録済みです（重複登録をスキップしました）`);
          return;
        }
        if (hasNoNutritionValues(food)) {
          log.push(`⚠️ 「${food.name}」は栄養値(cal/p/f/c)が指定されていないため登録しませんでした（0kcalの食品がDBに残るのを防ぐため）。もう一度、値を推定して登録を依頼してください`);
          return;
        }
        const per = parseFloat(food.per) || 100;
        const aiYomi = sanitizeYomi(food.yomi);
        const aiFa = sanitizeFa(food.fa), aiAa = sanitizeAa(food.aa);
        const aiServing = parseFloat(food.serving);
        const newFood = {
          id:      Date.now() + Math.random(),
          name:    food.name,
          ...(aiYomi ? { yomi: aiYomi } : {}),
          ...(typeof food.en === 'string' && food.en.trim() ? { en: food.en.trim().slice(0, 120) } : {}),
          ...(typeof food.tags === 'string' && food.tags.trim() ? { tags: food.tags.trim().slice(0, 200) } : {}),
          ...(() => { const c = sanitizeCategory(food.category) || guessFoodCategory(food.name); return c ? { category: c } : {}; })(),
          ...(sanitizeUnits(food.units).length ? { units: sanitizeUnits(food.units) } : {}),
          per,
          ...(aiServing > 0 ? { serving: aiServing } : {}),
          cal:     parseFloat(food.cal)     || 0,
          p:       parseFloat(food.p)       || 0,
          f:       parseFloat(food.f)       || 0,
          c:       parseFloat(food.c)       || 0,
          ...pickMicros(food),
          ...aiFiberSplit(food),
          ...(aiFa ? { fa: aiFa } : {}),
          ...(aiAa ? { aa: aiAa } : {}),
          digest:  classifyDigestCategory(food.name, parseFloat(food.p) || 0),
          _src:    'ai',
        };
        customFoods.push(newFood);
        log.push(`📦 カスタム食品「${food.name}」を登録（${per}gあたり ${Math.round(newFood.cal)}kcal）`);
      });
      saveCustom();
      changed = true;
    }

    // ── REGISTER_LOGGED_FOOD ──（既に記録済みの食事エントリを、その記録値そのままカスタム食品DBに登録）
    else if (cmd.type === 'register_logged_food') {
      const items = Array.isArray(cmd.items) ? cmd.items
        : (cmd.entry_ids || cmd.ids || []).map(id => ({ entry_id: id }));
      items.forEach(item => {
        const entryId = item.entry_id ?? item.id;
        const src = entries.find(e => e.id === entryId);
        if (!src) { log.push(`⚠️ id:${entryId} の記録が見つかりません`); return; }
        const name = (item.as_name || src.name || '').trim();
        if (!name) { log.push(`⚠️ id:${entryId} の記録に名前が無いため登録できませんでした`); return; }
        // 既に同名のカスタム食品があれば重複登録しない
        if (customFoods.some(f => normFoodName(f.name) === normFoodName(name))) {
          log.push(`ℹ️ 「${name}」は既にカスタム食品DBに登録済みです`);
          return;
        }
        const scale = 100 / (src.amount || 100);
        const srcM = { ...src }; materializeFiberSplit(srcM); // 内訳なしの過去記録も、名前からの推定で内訳を確定させてから登録
        const logCat = sanitizeCategory(cmd.category) || guessFoodCategory(name);
        customFoods.push({
          id:      Date.now() + Math.random(),
          name,
          ...(logCat ? { category: logCat } : {}),
          per:     100,
          cal:     r1((src.cal     || 0) * scale),
          p:       r1((src.p       || 0) * scale),
          f:       r1((src.f       || 0) * scale),
          c:       r1((src.c       || 0) * scale),
          ...Object.fromEntries(MICRO_KEYS.map(k => [k, microRound(k, (srcM[k] || 0) * scale)])),
          fa:      src.fa || null,
          aa:      src.aa || null,
          digest:  src.digest || classifyDigestCategory(name, src.p || 0),
          _src:    'log',
        });
        log.push(`📦 「${name}」を記録済みデータ(100gあたり ${r1((src.cal||0)*scale)}kcal)からDBに登録`);
      });
      saveCustom();
      changed = true;
    }

    // ── REGISTER_COMBO_FROM_LOG ──（複数の記録済みエントリを合算して1つのカスタム食品として登録）
    // 例:「今日の夕食のお好み焼きの材料をまとめてカスタム食品登録して」のような、
    //     どのエントリが対象かをAI自身の食品知識で判断する曖昧な依頼に対応する。
    else if (cmd.type === 'register_combo_from_log') {
      const ids = Array.isArray(cmd.entry_ids) ? cmd.entry_ids : (Array.isArray(cmd.ids) ? cmd.ids : []);
      const name = (cmd.name || '').trim();
      if (!name) { log.push('⚠️ カスタム食品名が指定されていません'); }
      else if (customFoods.some(f => normFoodName(f.name) === normFoodName(name))) {
        log.push(`ℹ️ 「${name}」は既にカスタム食品DBに登録済みです。別の名前を指定してください`);
      } else {
        const srcs = ids.map(id => entries.find(e => e.id === id)).filter(Boolean);
        const totalAmount = srcs.reduce((a, e) => a + Math.max(0, e.amount || 0), 0);
        if (!srcs.length || totalAmount <= 0) {
          log.push('⚠️ 対象の記録が見つからないため、合算登録できませんでした');
        } else {
          const sum = { cal:0, p:0, f:0, c:0, fiber:0, fibS:0, fibI:0, iron:0, calcium:0, vitc:0, vitd:0, vita:0, vite:0, vitk:0, iodine:0, salt:0 };
          srcs.forEach(e => { Object.keys(sum).forEach(k => { if (k === 'fibS' || k === 'fibI') return; sum[k] += Math.max(0, e[k] || 0); });
            const sp = getFiberSplit(e); sum.fibS += sp.s; sum.fibI += sp.i; });
          const scale = 100 / totalAmount;
          const sumCat = sanitizeCategory(cmd.category) || guessFoodCategory(name);
          customFoods.push({
            id:      Date.now() + Math.random(),
            name,
            ...(sumCat ? { category: sumCat } : {}),
            per:     100,
            cal:     r1(sum.cal*scale),     p:       r1(sum.p*scale),
            f:       r1(sum.f*scale),       c:       r1(sum.c*scale),
            fiber:   r1(sum.fiber*scale),   fibS:    r1(sum.fibS*scale),   fibI:    r1(sum.fibI*scale),   iron:    r2(sum.iron*scale),
            calcium: r1(sum.calcium*scale), vitc:    r1(sum.vitc*scale),
            vitd:    r2(sum.vitd*scale),    vita:    r1(sum.vita*scale),
            vite:    r2(sum.vite*scale),    vitk:    r1(sum.vitk*scale),
            iodine:  r1(sum.iodine*scale),  salt:    r2(sum.salt*scale),
            digest:  'mixed',
            _src:    'combo_log',
          });
          log.push(`📦 「${name}」を${srcs.length}件の記録（合計${r1(totalAmount)}g）から合算してDBに登録`);
        }
      }
      saveCustom();
      changed = true;
    }

    // ── COMBO_FOOD_FROM_LOG ──（既に記録済みの複数エントリを、材料の内訳を保持したまま複合食品として登録する。
    //     register_combo_from_logとの違い：あちらは内訳を持たない1件のカスタム食品に合算するだけだが、
    //     こちらは各エントリをそのまま「材料」として複合食品(comboFoods)に保存するため、後から複合食品タブで内訳を編集できる）
    else if (cmd.type === 'combo_food_from_log') {
      const ids = Array.isArray(cmd.entry_ids) ? cmd.entry_ids : (Array.isArray(cmd.ids) ? cmd.ids : []);
      const name = (cmd.name || '').trim();
      const deleteOriginals = !!cmd.delete_originals;
      if (!name) { log.push('⚠️ 複合食品名が指定されていません'); }
      else if (comboFoods.some(f => normFoodName(f.name) === normFoodName(name))) {
        log.push(`ℹ️ 「${name}」は既に複合食品として登録済みです`);
      } else {
        const srcs = ids.map(id => entries.find(e => e.id === id)).filter(Boolean);
        const totalAmt = srcs.reduce((a, e) => a + Math.max(0, e.amount || 0), 0);
        if (!srcs.length || totalAmt <= 0) {
          log.push('⚠️ 対象の記録が見つからないため、複合食品として登録できませんでした');
        } else {
          comboFoods.push(buildComboFromEntries(srcs, name, cmd.category));
          log.push(`📦 「${name}」を${srcs.length}件の記録（合計${r1(totalAmt)}g）から複合食品として登録`);
          if (deleteOriginals) {
            const srcIds = new Set(srcs.map(e => e.id));
            entries = entries.filter(e => !srcIds.has(e.id));
            log.push(`🗑️ 元になった記録 ${srcs.length}件を食事記録から削除`);
          }
        }
      }
      save();
      saveCustom();
      renderComboFoodList();
      changed = true;
    }

    // ── ADD_COMBO_FOOD ──（まだ記録していないレシピを、材料リストから複合食品として新規登録。手動の「複合食品登録」タブと同じデータ構造）
    else if (cmd.type === 'add_combo_food') {
      const combos = Array.isArray(cmd.combos) ? cmd.combos : [cmd];
      combos.forEach(combo => {
        const name = (combo.name || '').trim();
        if (!name) { log.push('⚠️ 複合食品名が指定されていません'); return; }
        if (comboFoods.some(f => normFoodName(f.name) === normFoodName(name))) {
          log.push(`ℹ️ 「${name}」は既に複合食品として登録済みです`);
          return;
        }
        const rawIngredients = Array.isArray(combo.ingredients) ? combo.ingredients : [];
        if (!rawIngredients.length) { log.push(`⚠️ 「${name}」の材料が指定されていません`); return; }

        // 栄養値(cal/p/f/c)が全く指定されていない材料は、食品DB（内蔵/カスタム/複合）の同名食品の値で補う。
        // DBにも無ければ0kcalのまま黙って登録せず、警告を出す（AIが値の指定を忘れた場合の保険）
        const filledFromDb = [], unresolved = [];
        const ingredients = rawIngredients.map(ing0 => {
          let ing = ing0;
          if (['cal','p','f','c'].every(k => ing0[k] == null || ing0[k] === '')) {
            const dbf = getAllFoods().find(x => normFoodName(x.name) === normFoodName(ing0.name));
            if (dbf) { ing = { ...dbf, name: ing0.name || dbf.name, per: dbf.per || 100, amount: ing0.amount }; filledFromDb.push(ing.name); }
            else unresolved.push(ing0.name || '材料');
          }
          const per    = parseFloat(ing.per) || 100;
          const amount = parseFloat(ing.amount) || per;
          const r      = amount / per;
          const cal = parseFloat(ing.cal) || 0, p = parseFloat(ing.p) || 0, f = parseFloat(ing.f) || 0, c = parseFloat(ing.c) || 0;
          const mic = { ...pickMicros(ing), ...aiFiberSplit(ing) };
          const o = { name: ing.name || '材料', amount, per, cal, p, f, c, ...mic,
            _cal: r1(cal*r), _p: r1(p*r), _f: r1(f*r), _c: r1(c*r) };
          MICRO_KEYS.forEach(k => { o['_'+k] = microRound(k, mic[k]*r); });
          return o;
        });
        const totalAmt = ingredients.reduce((a,f) => a + f.amount, 0);
        if (totalAmt <= 0) { log.push(`⚠️ 「${name}」の材料の量が不正です`); return; }
        if (filledFromDb.length) log.push(`ℹ️ 「${name}」: 栄養値の指定が無かった材料（${filledFromDb.join('、')}）は食品DBの登録値を使用しました`);
        if (unresolved.length) log.push(`⚠️ 「${name}」: 材料（${unresolved.join('、')}）は栄養値の指定もDB登録も無いため0kcalで登録されています。値を指定して登録し直してください`);
        const tot = comboTotals(ingredients);

        // 100gあたりに正規化せず、材料の総重量を基準量(per)にする
        // → 記録タブで選ぶ際のデフォルト量が「作った分そのまま」になる
        const aiComboYomi = sanitizeYomi(combo.yomi);
        comboFoods.push({
          id: Date.now() + Math.random(),
          name, ...(aiComboYomi ? { yomi: aiComboYomi } : {}),
          ...(() => { const c = sanitizeCategory(combo.category) || guessFoodCategory(name); return c ? { category: c } : {}; })(),
          per: r1(totalAmt), serving: r1(totalAmt),
          cal: r1(tot.cal), p: r1(tot.p), f: r1(tot.f), c: r1(tot.c),
          ...Object.fromEntries(MICRO_KEYS.map(k => [k, microRound(k, tot[k])])),
          ingredients: ingredients.map(f => ({
            name: f.name, amount: f.amount, per: f.per,
            cal: f.cal, p: f.p, f: f.f, c: f.c,
            ...Object.fromEntries(MICRO_KEYS.map(k => [k, f[k]])),
          })),
          digest: 'mixed',
          _src: 'combo',
        });
        log.push(`📦 複合食品「${name}」を${ingredients.length}品目・合計${r1(totalAmt)}gで登録`);
      });
      saveCustom();
      renderComboFoodList();
      changed = true;
    }

    // ── DELETE_COMBO_FOOD ──（複合食品DBから削除）
    else if (cmd.type === 'delete_combo_food') {
      const names = Array.isArray(cmd.names) ? cmd.names : [cmd.name];
      const before = comboFoods.length;
      comboFoods = comboFoods.filter(f => !names.some(n => normFoodName(n) === normFoodName(f.name)));
      saveCustom();
      renderComboFoodList();
      log.push(`🗑️ 複合食品 ${before - comboFoods.length}件削除`);
      changed = true;
    }

    // ── ADD_QUICK_SEASONING ──（記録タブの「調味料クイック登録」ボタンを新規追加。食品DBの1件を指定量で登録する）
    else if (cmd.type === 'add_quick_seasoning') {
      const items = Array.isArray(cmd.items) ? cmd.items : [cmd];
      items.forEach(item => {
        const foodName = (item.food_name || item.name || '').trim();
        if (!foodName) { log.push('⚠️ 対象の食品名が指定されていません'); return; }
        const f = getAllFoods().find(x => normFoodName(x.name) === normFoodName(foodName));
        if (!f) { log.push(`⚠️ 「${foodName}」が食品DBに見つかりません（先にsearch_food_dbで確認してください）`); return; }
        const label = (item.label || f.name).trim().slice(0, 8);
        if (quickSeasonings.some(s => s.label === label)) {
          log.push(`ℹ️ 「${label}」は既にクイック登録済みです`);
          return;
        }
        const per = f.per || 100;
        const amt = parseFloat(item.amount) || f.serving || per;
        const r = amt / per;
        quickSeasonings.push({
          id: Date.now() + Math.random(),
          label, name: f.name, amount: r1(amt),
          cal: r1(f.cal*r), p: r1(f.p*r), f: r1(f.f*r), c: r1(f.c*r),
          fiber: r1((f.fiber||0)*r), ...fibSplitScaled(f, r, r1((f.fiber||0)*r)), iron: r1((f.iron||0)*r), calcium: r1((f.calcium||0)*r),
          vitc: r1((f.vitc||0)*r), vitd: r1((f.vitd||0)*r), salt: r2((f.salt||0)*r),
          fa: f.fa || null, aa: f.aa || null,
          digest: f.digest || classifyDigestCategory(f.name, r1(f.p*r)),
        });
        log.push(`🧂 「${label}」（${f.name} ${r1(amt)}g）をクイック登録に追加`);
      });
      saveQuickSeasonings();
      renderQuickSeasonings();
      changed = true;
    }

    // ── DELETE_QUICK_SEASONING ──（調味料クイック登録から削除。ラベル名で指定）
    else if (cmd.type === 'delete_quick_seasoning') {
      const labels = Array.isArray(cmd.labels) ? cmd.labels : [cmd.label];
      const before = quickSeasonings.length;
      quickSeasonings = quickSeasonings.filter(s => !labels.includes(s.label));
      saveQuickSeasonings();
      renderQuickSeasonings();
      log.push(`🗑️ クイック登録 ${before - quickSeasonings.length}件削除`);
      changed = true;
    }

    // ── DELETE_CUSTOM_FOOD ──（カスタム食品DBからの削除）
    else if (cmd.type === 'delete_custom_food') {
      const names = Array.isArray(cmd.names) ? cmd.names : [cmd.name];
      const before = customFoods.length;
      customFoods = customFoods.filter(f => !names.includes(f.name));
      saveCustom();
      log.push(`🗑️ カスタム食品 ${before - customFoods.length}件削除`);
      changed = true;
    }

    // ── EDIT_CUSTOM_FOOD ──（カスタム食品DBの既存項目を編集）
    else if (cmd.type === 'edit_custom_food') {
      const targetName = (cmd.name || '').trim();
      const idx = customFoods.findIndex(f => normFoodName(f.name) === normFoodName(targetName));
      if (idx === -1) {
        log.push(`⚠️ 「${targetName}」がカスタム食品DBに見つかりません`);
      } else {
        const updates = cmd.updates || {};
        const newName = updates.name != null ? String(updates.name).trim() : '';
        const nameCollides = newName && normFoodName(newName) !== normFoodName(customFoods[idx].name) &&
          customFoods.some((f, i) => i !== idx && normFoodName(f.name) === normFoodName(newName));
        if (nameCollides) {
          log.push(`⚠️ 「${newName}」という名前は既に別のカスタム食品で使われています`);
        } else {
          const numericKeys = ['per','serving','cal','p','f','c','fiber','fibS','fibI','iron','calcium','vitc','vitd','vita','vite','vitk','iodine','salt'];
          numericKeys.forEach(k => {
            if (updates[k] === undefined || updates[k] === null || updates[k] === '') return;
            const v = parseFloat(updates[k]);
            if (!isNaN(v)) customFoods[idx][k] = Math.max(0, v);
          });
          if (newName) customFoods[idx].name = newName;
          // 食物繊維や内訳が更新された場合は、合計と整合させる（内訳が無ければ名前から推定）
          if (['fiber','fibS','fibI'].some(k => updates[k] != null && updates[k] !== '')) reconcileFiberSplit(customFoods[idx]);
          ['en','tags','category'].forEach(k => { if (typeof updates[k] === 'string') { const v = updates[k].trim().slice(0, 200); if (v) customFoods[idx][k] = v; else delete customFoods[idx][k]; } });
          if (Array.isArray(updates.units)) { const u = sanitizeUnits(updates.units); if (u.length) customFoods[idx].units = u; else delete customFoods[idx].units; }
          // 読み: 指定があれば更新、名前だけ変えた場合は古い読みが残らないよう自動推定に戻す
          if (updates.yomi != null) {
            const y = sanitizeYomi(updates.yomi);
            if (y) customFoods[idx].yomi = y; else delete customFoods[idx].yomi;
          } else if (newName) delete customFoods[idx].yomi;
          saveCustom();
          log.push(`✏️ 「${customFoods[idx].name}」を更新しました`);
        }
      }
      changed = true;
    }
    // ── 未対応のコマンド種別 ──
    // 以前はここに何も無く、AIがタイプミスしたコマンドや未実装のコマンド種別を送ってきた場合、
    // 何のエラーも出さずに黙って無視していた（「AIに依頼したのに理由も無く失敗する」不具合の主因の一つ）。
    else {
      const msg = `未対応のコマンド種別です: ${cmd.type}`;
      log.push(`❌ ${msg}`);
      logError('AI操作', msg, JSON.stringify(cmd).slice(0, 500));
    }
   } catch (err) {
     // 1つのコマンドで想定外のエラーが起きても、バッチ内の他のコマンドの実行は継続する
     const msg = `コマンド実行中にエラーが発生しました（種別: ${cmd.type || '不明'}）: ${err.message}`;
     log.push(`❌ ${msg}`);
     logError('AI操作', msg, JSON.stringify(cmd).slice(0, 500) + '\n' + (err.stack || ''));
   }
  });
  // 記録(entries)を変更するコマンド（add / delete_by_id / delete_by_date_meal / replace）は、以前は保存処理を呼んでおらず、
  // 次に別の操作で保存されるまで localStorage にもクラウドにも反映されなかった（アプリを閉じると消える・クラウドに上がらない不具合の主因）
  if (changed) save();
  return log;
}

// ══ AIプロンプトの雛形 ══
// 押すと送信せずにチャット欄へコピーする（【…】の部分は最初の1つが選択状態になり、そのまま打ち込める）。複数登録でき、編集・並べ替え・削除ができる
const DEFAULT_PROMPT_TEMPLATES = [
  { id: 'd-food', title: '🍱 食品を登録', text: '次の食品をカスタム食品DBに登録して。栄養成分は推定で構いません（食物繊維は水溶性・不溶性も）。\n食品名：【食品名】\n基準量：【100】g\n分かる栄養成分：【エネルギー・たんぱく質・脂質・炭水化物など、分かる範囲で】' },
  { id: 'd-label', title: '🏷 成分表示から登録', text: '次の栄養成分表示から食品を登録して。表示にない栄養素は推定で補ってください。\n商品名：【商品名】\n【100g／1食分○g】あたり：エネルギー【　】kcal、たんぱく質【　】g、脂質【　】g、炭水化物【　】g、食物繊維【　】g、食塩相当量【　】g' },
  { id: 'd-recipe', title: '🍲 レシピを複合食品に', text: '次のレシピを複合食品として登録して。各材料の栄養値は推定で構いません。\n料理名：【料理名】\n材料：\n・【食材1】【量】g\n・【食材2】【量】g\n・【食材3】【量】g' },
  { id: 'd-log', title: '🍽 食事を記録', text: '【朝食／昼食／夕食／間食】に【食品名と量（例：卵2個）】を食べました' },
  { id: 'd-eatout', title: '🏪 外食・市販品を記録', text: '【店名・商品名】を【昼食】に食べました。栄養値が分からなければ推定して記録し、カスタム食品としても登録してください。' },
  { id: 'd-yesterday', title: '🔁 昨日と同じ', text: '昨日の【朝食】と同じものを、今日の【朝食】に記録して' },
  { id: 'd-fromlog', title: '🧾 記録をまとめて登録', text: '今日の【昼食】の記録を1つの複合食品「【名前】」としてまとめて登録して（元の記録は【残す／消す】）' },
  { id: 'd-edit', title: '✏️ 食品の値を修正', text: 'カスタム食品「【食品名】」の【項目（例：たんぱく質）】を【値】に修正して' },
  { id: 'd-search', title: '🔍 DBにあるか確認', text: '「【食品名】」は食品DBに登録されている？似た名前の食品があれば教えて' },
];
const PROMPT_TPL_MAX = 50, PROMPT_TITLE_MAX = 24, PROMPT_TEXT_MAX = 2000;
function sanitizePromptTemplates(arr) {
  if (!Array.isArray(arr)) return null;
  const out = [], seen = new Set();
  arr.forEach(t => {
    if (!t || typeof t !== 'object') return;
    const title = String(t.title == null ? '' : t.title).trim().slice(0, PROMPT_TITLE_MAX), text = String(t.text == null ? '' : t.text).slice(0, PROMPT_TEXT_MAX);
    if (!title || !text.trim()) return;
    let id = String(t.id || '').slice(0, 40) || newPromptTplId(); if (seen.has(id)) id = newPromptTplId(); seen.add(id);
    out.push({ id, title, text });
  });
  return out.slice(0, PROMPT_TPL_MAX);
}
function newPromptTplId() { return 't' + Date.now().toString(36) + Math.random().toString(36).slice(2, 6); }
function loadPromptTemplates() {
  try { const raw = localStorage.getItem('pfcPromptTemplates'); if (raw) { const a = sanitizePromptTemplates(JSON.parse(raw)); if (a) return a; } } catch (e) {}
  return DEFAULT_PROMPT_TEMPLATES.map(t => ({ ...t }));
}
let promptTemplates = loadPromptTemplates();
function savePromptTemplates() { try { localStorage.setItem('pfcPromptTemplates', JSON.stringify(promptTemplates)); } catch (e) {} queueCloudSaveSoon(); }
let _promptMgrOpen = false, _promptEditId = null;   // _promptEditId: 編集中の雛形のid（'new' は新規）
function renderPromptTemplates() {
  const chips = document.getElementById('promptChips');
  if (chips) chips.innerHTML = promptTemplates.length
    ? promptTemplates.map(t => `<button class="btn btn-sm prompt-chip" data-tpl="${fdEsc(t.id)}" onclick="usePromptTemplate(this.dataset.tpl)" title="${fdEsc(t.text.slice(0, 120))}">${fdEsc(t.title)}</button>`).join('')
    : `<span style="font-size:11px;color:var(--text-sub)">雛形がありません。「⚙️ 雛形」から追加できます</span>`;
  const mgr = document.getElementById('promptMgr'); if (!mgr) return;
  if (!_promptMgrOpen) { mgr.innerHTML = ''; return; }
  const editForm = (t) => `<div class="fd-bulk" style="margin:6px 0">
      <div class="field" style="margin-bottom:6px"><input type="text" id="ptTitle" maxlength="${PROMPT_TITLE_MAX}" placeholder="名前（例：🍱 食品を登録）" value="${fdEsc(t.title)}" autocomplete="off"></div>
      <div class="field" style="margin-bottom:6px"><textarea id="ptText" rows="6" maxlength="${PROMPT_TEXT_MAX}" placeholder="AIに送る文章。【…】で囲んだ部分は、使うときに最初の1つが選択されます" style="width:100%;box-sizing:border-box;resize:vertical;border:1px solid var(--border);border-radius:8px;padding:8px 10px;font-size:13px;background:var(--surface);color:var(--text);font-family:inherit;line-height:1.5">${fdEsc(t.text)}</textarea></div>
      <div id="ptMsg" class="status-msg status-err" style="margin-bottom:6px"></div>
      <div style="display:flex;gap:6px"><button class="btn btn-primary btn-sm" style="flex:1" onclick="savePromptTemplateForm()">保存</button><button class="btn btn-sm" style="flex:1" onclick="cancelPromptEdit()">キャンセル</button></div></div>`;
  mgr.innerHTML = `<div class="fd-bulk" style="margin:0 0 10px">
    <div style="font-size:12px;font-weight:500;margin-bottom:6px">プロンプトの雛形（タップでチャット欄にコピー）</div>
    ${promptTemplates.map((t, i) => _promptEditId === t.id ? editForm(t) : `<div class="fd-bulk-row" style="margin-bottom:4px"><div style="flex:1;min-width:0"><div style="font-size:12px;font-weight:500">${fdEsc(t.title)}</div><div style="font-size:10px;color:var(--text-sub);white-space:nowrap;overflow:hidden;text-overflow:ellipsis">${fdEsc(t.text.replace(/\s+/g, ' '))}</div></div>
        <button class="btn btn-sm" ${i === 0 ? 'disabled' : ''} onclick="movePromptTemplate('${fdEsc(t.id)}',-1)" aria-label="上へ">↑</button><button class="btn btn-sm" ${i === promptTemplates.length - 1 ? 'disabled' : ''} onclick="movePromptTemplate('${fdEsc(t.id)}',1)" aria-label="下へ">↓</button>
        <button class="btn btn-sm" onclick="editPromptTemplate('${fdEsc(t.id)}')">編集</button><button class="btn btn-sm btn-danger" onclick="deletePromptTemplate('${fdEsc(t.id)}')">✕</button></div>`).join('')}
    ${_promptEditId === 'new' ? editForm({ title: '', text: '' }) : ''}
    <div style="display:flex;gap:6px;flex-wrap:wrap;margin-top:8px">
      <button class="btn btn-sm" onclick="editPromptTemplate('new')" ${promptTemplates.length >= PROMPT_TPL_MAX ? 'disabled' : ''}>＋ 新しい雛形</button>
      <button class="btn btn-sm" onclick="savePromptFromInput()">入力欄の内容を雛形に保存</button>
      <button class="btn btn-sm" onclick="resetPromptTemplates()">初期の雛形に戻す</button>
    </div></div>`;
}
function togglePromptMgr() { _promptMgrOpen = !_promptMgrOpen; _promptEditId = null; renderPromptTemplates(); }
// 雛形をチャット欄にコピーする（送信はしない）。入力済みなら改行して続けて追加し、最初の【…】を選択状態にする
function usePromptTemplate(id) {
  const tpl = promptTemplates.find(t => t.id === id), input = document.getElementById('aiInput'); if (!tpl || !input) return;
  const cur = input.value, prefix = cur.trim() ? cur.replace(/\s+$/, '') + '\n' : '';
  input.value = prefix + tpl.text;
  input.style.height = 'auto'; if (input.scrollHeight > 0) input.style.height = Math.min(input.scrollHeight, 200) + 'px';   // 複数行の雛形が見えるように広げる（高さが取れない場合は自動のまま）
  input.focus();
  try {
    const m = /【[^】]*】/.exec(tpl.text);
    if (m) input.setSelectionRange(prefix.length + m.index, prefix.length + m.index + m[0].length); else input.setSelectionRange(input.value.length, input.value.length);
  } catch (e) {}
}
function editPromptTemplate(id) { _promptEditId = id; renderPromptTemplates(); const el = document.getElementById('ptTitle'); if (el) { el.focus(); el.scrollIntoView({ behavior: 'smooth', block: 'center' }); } }
function cancelPromptEdit() { _promptEditId = null; renderPromptTemplates(); }
function savePromptTemplateForm() {
  const title = (document.getElementById('ptTitle').value || '').trim(), text = document.getElementById('ptText').value || '', msg = document.getElementById('ptMsg');
  const fail = t => { if (msg) msg.textContent = t; };
  if (!title) { fail('名前を入力してください'); return; } if (!text.trim()) { fail('文章を入力してください'); return; }
  if (_promptEditId === 'new') {
    if (promptTemplates.length >= PROMPT_TPL_MAX) { fail(`雛形は最大${PROMPT_TPL_MAX}個までです`); return; }
    promptTemplates.push({ id: newPromptTplId(), title: title.slice(0, PROMPT_TITLE_MAX), text: text.slice(0, PROMPT_TEXT_MAX) });
  } else {
    const t = promptTemplates.find(x => x.id === _promptEditId); if (!t) { _promptEditId = null; renderPromptTemplates(); return; }
    t.title = title.slice(0, PROMPT_TITLE_MAX); t.text = text.slice(0, PROMPT_TEXT_MAX);
  }
  _promptEditId = null; savePromptTemplates(); renderPromptTemplates();
}
function movePromptTemplate(id, dir) {
  const i = promptTemplates.findIndex(t => t.id === id), j = i + dir; if (i < 0 || j < 0 || j >= promptTemplates.length) return;
  [promptTemplates[i], promptTemplates[j]] = [promptTemplates[j], promptTemplates[i]]; savePromptTemplates(); renderPromptTemplates();
}
function deletePromptTemplate(id) {
  const snap = promptTemplates.map(t => ({ ...t })), t = promptTemplates.find(x => x.id === id); if (!t) return;
  promptTemplates = promptTemplates.filter(x => x.id !== id); if (_promptEditId === id) _promptEditId = null; savePromptTemplates(); renderPromptTemplates();
  showUndoToast(`雛形「${t.title}」を削除しました`, () => { promptTemplates = snap; savePromptTemplates(); renderPromptTemplates(); });
}
function resetPromptTemplates() {
  if (!confirm('雛形を初期の内容に戻しますか？（追加・編集した雛形は消えます。直後なら「元に戻す」で復元できます）')) return;
  const snap = promptTemplates.map(t => ({ ...t })); promptTemplates = DEFAULT_PROMPT_TEMPLATES.map(t => ({ ...t })); _promptEditId = null; savePromptTemplates(); renderPromptTemplates();
  showUndoToast('雛形を初期の内容に戻しました', () => { promptTemplates = snap; savePromptTemplates(); renderPromptTemplates(); });
}
function savePromptFromInput() {   // いまチャット欄に書いてある文章を、新しい雛形として保存する入力を開く
  const input = document.getElementById('aiInput'), text = input ? input.value : '';
  if (!text.trim()) { showToast('チャット欄に雛形にしたい文章を入力してから押してください'); return; }
  _promptMgrOpen = true; _promptEditId = 'new'; renderPromptTemplates();
  const t = document.getElementById('ptText'); if (t) t.value = text.slice(0, PROMPT_TEXT_MAX);
  const ti = document.getElementById('ptTitle'); if (ti) { ti.focus(); ti.scrollIntoView({ behavior: 'smooth', block: 'center' }); }
}
// AIのsearch_food_db関数呼び出しを実際に実行する（ユーザーの検索と同じデータソースを使う）
function searchFoodDbForAi(query) {
  const q = normalize(String(query || '').trim());
  if (!q) return '検索キーワードが空です';
  const qv = queryVariants(query);
  const matches = getAllFoods().filter(f => (f._search || normalize(f.name)).includes(q) || kanaScore(f, qv) > 0).slice(0, 10);
  if (!matches.length) return `「${query}」に一致する食品は見つかりませんでした`;
  const srcLabel = { local: '内蔵DB', custom: 'カスタムDB', combo: '複合食品' };
  return matches.map(f => {
    const src = srcLabel[f._src] || f._src || '';
    const extras = [];
    MICRO_KEYS.forEach(k => { if (f[k] && MICRO_GOALS[k]) extras.push(`${MICRO_GOALS[k].label}${f[k]}${MICRO_GOALS[k].unit}`); });
    return `${f.name}（${src}・${f.per}gあたり ${f.cal}kcal P${f.p} F${f.f} C${f.c}${extras.length ? ' ' + extras.join(' ') : ''}）`;
  }).join('\n');
}
// AI応答テキストから操作コマンドのJSONを取り出す（Geminiは```json以外の形式でも返すことがある）
function parseAiResponse(rawText) {
  let parsed      = null;
  let displayText = rawText;

  // 複数のパターンを試みる
  const jsonPatterns = [
    /```json\s*([\s\S]*?)```/,   // 標準: ```json ... ```
    /```\s*(\{[\s\S]*?\})\s*```/, // ``` { ... } ```
    /(\{[\s\S]*"commands"[\s\S]*?\})\s*$/m, // 末尾のJSONオブジェクト
    /(\{[\s\S]*"items"[\s\S]*?\})\s*$/m,    // itemsキーを含むJSON
  ];

  let jsonParseAttemptFailed = false;
  for (const pat of jsonPatterns) {
    const m = rawText.match(pat);
    if (m) {
      try {
        parsed = JSON.parse(m[1].trim());
        displayText = parsed.message || rawText.replace(pat, '').trim();
        break;
      } catch(e) { jsonParseAttemptFailed = true; /* 次のパターンを試す */ }
    }
  }
  // ```json のフェンスは見つかったのに、どのパターンでも解析できなかった場合。
  // 以前はここで何も起きず、AIの返信文だけが表示されて操作が実行されない
  // （かつ理由も分からない）ことがあった。
  if (!parsed && jsonParseAttemptFailed) {
    const warnMsg = '⚠️ AIの応答内に操作コマンドが含まれていましたが、解析に失敗したため実行されませんでした。もう一度お試しください。';
    displayText = (displayText ? displayText + '\n\n' : '') + warnMsg;
    logError('AI応答解析', 'JSONコマンドブロックの解析に失敗しました', rawText.slice(0, 800));
  }

  // 旧形式（items配列）のフォールバック対応
  if (parsed && !parsed.commands && Array.isArray(parsed.items)) {
    // 旧itemsフォーマットをcommands形式に変換
    parsed = {
      commands: [{
        type: 'add',
        dates: [currentDate],
        meal: parsed.items[0]?.meal || '昼食',
        items: parsed.items,
      }],
      message: parsed.message || '',
      backup_label: '食品追加',
    };
  }
  return { parsed, displayText, jsonParseAttemptFailed };
}
// AIが返答の末尾のJSONで出す「操作コマンド」の種別（関数呼び出し(function call)ではない）
const AI_COMMAND_TYPES = ['add','add_combo_food','add_custom_food','add_quick_seasoning','combo_food_from_log','delete_by_date_meal','delete_by_id',
  'delete_combo_food','delete_custom_food','delete_quick_seasoning','edit_custom_food','register_combo_from_log','register_logged_food','replace'];
// AIが「未対応」「できない」「システムエラー」などを理由に実行を断っているか（実際には対応済みの操作でこう言われることがある）
function claimsCannot(text) {
  return /未対応|対応していません|対応しておりません|サポートしていません|サポートされていません|利用できません|使用できません|使えません|システムエラー|エラーが発生|失敗しました|登録できません|実行できません|(削除|更新|追加|記録|保存|置き換え|変更|修正|反映)(することが)?できません/.test(String(text || ''));
}
// ユーザーの依頼が「何かを実行してほしい」内容か（質問・雑談は除く）
function looksLikeActionRequest(text) {
  const t = String(text || '').trim();
  if (/[?？]\s*$|教えて|ですか$|でしょうか$/.test(t)) return false;
  return /登録|追加|記録|食べた|飲んだ|保存|入れて|いれて|削除|消して|置き換え|置換|変更|修正|直して|更新|反映/.test(t);
}
// AIの返答が「実行しました」と完了を主張しているか
function claimActionDoneGuard(text) { return claimsActionDone(text); }
function claimsActionDone(text) {
  return /(登録|追加|記録|保存|削除|更新|置き換え|変更|修正|反映)(し|いた)ました|完了しました|しておきました|済みです/.test(String(text || ''));
}
// データ全体の簡易シグネチャ（AI操作の前後で比較し、実際に何か変わったかを判定する）
function aiStateSig() {
  try { return JSON.stringify([entries, customFoods, comboFoods, quickSeasonings]); } catch (e) { return String(Math.random()); }
}
// 記録・登録の依頼か（削除・置換・変更の依頼は対象外：そちらは確認の聞き返しが正当な場合がある）
function looksLikeRegistrationRequest(text) {
  const t = String(text || '');
  if (/削除|消して|消去|置き換え|置換|変更|修正|直して|リセット/.test(t)) return false;
  return /登録|追加|記録|食べた|飲んだ|保存|入れて|いれて/.test(t);
}
// AIの返答が、量・値・目安などの数値を聞き返す内容か
function looksLikeAskBack(text) {
  const t = String(text || '');
  if (!/[?？]|ください|教えて|お知らせ|ご指定|お聞かせ|ご提示/.test(t)) return false;
  return /目安|何g|何グラム|グラム数|どのくらい|どれくらい|いくつ|何個|何人前|分量|量を|カロリーを|栄養成分|成分表示|数値|PFC|値を|サイズ/.test(t);
}
// 栄養値(cal/p/f/c)が全く指定されていない（=このままでは0kcalで登録される）か
const hasNoNutritionValues = o => ['cal','p','f','c'].every(k => o[k] == null || o[k] === '');
// 登録系コマンドのうち、栄養値の指定が無く補う手段も無いもの:
//  ・add_combo_food の材料（食品DBに同名があればDB値で補えるので対象外）
//  ・add_custom_food の食品（単品は補う元が無い）
function findUnvaluedItems(parsed) {
  const out = [];
  (parsed && Array.isArray(parsed.commands) ? parsed.commands : []).forEach(cmd => {
    if (cmd.type === 'add_combo_food') {
      (Array.isArray(cmd.combos) ? cmd.combos : [cmd]).forEach(combo => {
        (Array.isArray(combo.ingredients) ? combo.ingredients : []).forEach(ing => {
          if (hasNoNutritionValues(ing) && !getAllFoods().some(x => normFoodName(x.name) === normFoodName(ing.name))) out.push(ing.name || '材料');
        });
      });
    } else if (cmd.type === 'add_custom_food') {
      (Array.isArray(cmd.foods) ? cmd.foods : [cmd]).forEach(food => {
        if (food && food.name && hasNoNutritionValues(food)) out.push(food.name);
      });
    }
  });
  return out;
}

async function sendAiMessage() {
  const inp = document.getElementById('aiInput');
  const btn = document.getElementById('aiSendBtn');
  const text = inp ? inp.value.trim() : '';
  if (!text) return;

  inp.value = ''; inp.style.height = '';
  inp.disabled = true;
  btn.disabled = true;

  appendAiMessage('user', text);
  aiHistory.push({ role: 'user', content: text });

  const thinking = appendAiThinking();

  // コンテキスト構築（送信のたびに最新データを全件渡す）
  const today = currentDate;
  const weekDates = getWeekDates(today);
  const dbSample  = LOCAL_DB.slice(0, 30).map(f => f.name).join('、'); // 内蔵DBは検索関数で引けるので、例示は最小限に
  const fullCtx = buildFullContext();

  const systemPrompt = `あなたは日本語の栄養管理アプリの操作AIです。
ユーザーの指示を解釈し、必要に応じて記録の追加・削除・置き換えを行います。
以下は送信時点の最新内部データです。質問・操作・アドバイスの判断に必ず活用してください。

【現在日時】今日: ${today}（${dateLabel(today)}）
【今週の日付】${weekDates.map(d => `${dateLabel(d)} ${d}`).join(' / ')}

${fullCtx}

【標準食品DB例】${dbSample} など（これは一部のサンプルです。全件を確認したい場合や、特定の食品がDBに登録済みか確認したい場合は search_food_db 関数で検索してください）

【食事タイミング】朝食 / 昼食 / 夕食 / 間食

━━━━━━━━━━━━━━━━━━━━━━
【search_food_db 関数について】
内蔵食品DB・カスタム食品DBを実際に検索できる関数です。以下のような場面で積極的に使ってください：
- 「〇〇は登録されている？」「〇〇の栄養価教えて」など、DBの内容そのものを聞かれたとき
- add / add_custom_food 等のコマンドを出す前に、同じ食品や紛らわしい名前の食品が既にDBに無いか確認したいとき（検索はあくまで確認用。登録そのものは関数ではなくJSONコマンドで行う）
- 一般的な食品名で構わないので、まず検索してみて、見つかればその実測値を使う。見つからなければ通常通りあなたの知識で推定する
検索結果が0件でも構いません。無理に何度も検索し直さないでください。
ただし、ユーザーが登録・記録を依頼している場合、0件だったことを理由に処理を諦めたり、
「システムエラー」「登録に失敗しました」のような、実際には起きていない技術的な失敗をでっち上げて
謝るのは絶対禁止です。その場合は必ずあなたの知識から栄養価を推定し、通常通りコマンドを実行して完了させてください。
0件である旨を伝えて終えてよいのは、ユーザーが「〇〇は登録されている？」のように検索結果そのものを尋ねている場合だけです。
【分析の依頼について】
「今週どうだった？」「分析して」「気になる点ある？」のような、記録の操作を伴わない分析・振り返りの依頼には、JSONコマンド無しで、コンテキストのデータから読み取れる具体的な内容を答えてください。以下のような観点が有用です（全て機械的に網羅する必要はなく、実際にデータから読み取れて意味のあるものだけ触れる）：
- 目標（cal/P/F/C）に対して継続的に過不足がある栄養素
- 曜日や特定の日によるパターン（例: 週末に外食が増える、特定の曜日にタンパク質が不足しがち）
- 直近の傾向の変化（増減が続いている、急に変わった日があるなど）
- 記録の異常値・欠食が多い日
数値は具体的に引用し、根拠のない一般論や医学的な助言（診断・治療に類する話）は避けてください。気になる点が特に無ければ、その旨を素直に伝えて構いません。

━━━━━━━━━━━━━━━━━━━━━━
【操作コマンド仕様】
【関数とコマンドの区別（重要）】あなたが関数として呼び出せるのは search_food_db だけです。add / add_custom_food / add_combo_food などは「関数」ではなく、
返答の末尾に \`\`\`json ブロックで書く【操作コマンド】です。これらを関数として呼び出そうとしてはいけません。
また「add_custom_food関数は未対応」「関数が用意されていない」などを理由に登録を断ってはいけません（すべて対応済みで、JSONブロックを出力すれば実行されます）。
操作が必要な場合は必ず末尾に \`\`\`json ブロックを出力してください。
JSONブロックは必ず \`\`\`json で始め \`\`\` で終わること。他の形式は使用不可。

【重要】JSONブロックを出力すると、その場で即座に実行されます。「確認してから実行する」という仕組みは存在しません。
そのため：
- 実行してよいと判断したら、JSONブロックを出力し、message は「登録しました」のように完了形で書く。「よろしいでしょうか？」のような確認を求める文言をJSONブロックと同時に出すことは絶対に禁止（実行済みなのに未実行であるかのように見え、ユーザーが「はい」と答えると重複実行してしまう）
- 本当にユーザーの確認を先に得たい場合（対象の特定に自信が無い、破壊的な操作で念のため確認したい等）は、その回ではJSONブロックを一切出力せず、確認の質問だけを返す。ユーザーが同意する返答をした次のやりとりで、初めてJSONブロックを出力する

コマンド種別:

1. add — 今日または指定日の食事記録に食品を追加
{
  "commands": [{
    "type": "add",
    "dates": ["${today}"],
    "meal": "昼食",
    "items": [{"name": "食品名", "amount": 100, "cal": 168, "p": 2.5, "f": 0.3, "c": 37.1, "fiber": 0.3, "fibS": 0.1, "fibI": 0.2, "iron": 0.1, "calcium": 3, "vitc": 0, "vitd": 0, "salt": 0}]
  }],
  "backup_label": "朝食追加",
  "message": "ユーザーへの返答"
}

2. delete_by_id — IDを指定して削除（コンテキストのidフィールドを使用）
{
  "commands": [{"type": "delete_by_id", "ids": [1234567890]}],
  "backup_label": "夕食削除",
  "message": "削除しました"
}

3. delete_by_date_meal — 日付×食事タイミングで一括削除
{
  "commands": [{"type": "delete_by_date_meal", "dates": ["${today}"], "meal": "昼食"}],
  "backup_label": "昼食一括削除",
  "message": "削除しました"
}

4. replace — 指定日時の既存記録を全削除して新内容で置き換え
{
  "commands": [{"type": "replace", "dates": ["${today}"], "meal": "昼食", "items": [...]}],
  "backup_label": "昼食を置き換え",
  "message": "置き換えました"
}

5. add_custom_food — カスタム食品DBに食品を登録（食事記録への追加とは別・検索DBに保存。栄養成分は推定または表示値を使用）
    【重要】cal/p/f/c だけでなく、可能な範囲で以下も必ず埋めること。ユーザーに数値を聞き返すのは禁止（パッケージの栄養成分表示に無い項目は、
    同カテゴリの一般的な食品を参考に自分で推定する。本当に無視できる量（0扱いで妥当）ならそのフィールド自体を省略してよい）：
    - fiber/iron/calcium/vitc/vitd/salt（MICRO_GOALSにある食物繊維・鉄・カルシウム・VitC・VitD・塩分。可能なら vita/vite/vitk/iodine も）
    - fiberが0より大きい場合は fibS（水溶性食物繊維g）と fibI（不溶性食物繊維g）を【必ず】付ける（省略禁止）。fibS+fibI は fiber と一致させること。
      日本食品標準成分表(八訂)の水溶性/不溶性の値が分かればそれを使い、分からなければ下の目安比率で推定して必ず入れる（海藻類・加工品・外食も推定でよい）。
      水溶性の割合の目安: 白米・餅 0〜3% / 小麦粉・パン・麺 25〜45% / 玄米・雑穀 20〜25% / オーツ 30〜35% / 野菜 20〜30%（ごぼう40%・にんにく60%）/
      果物 25〜50%（バナナ10%） / 芋類 30〜35% / 大豆・豆類 10%（納豆34%）/ きのこ 5〜10% / ナッツ・種子 10〜15% / 海藻 35〜70% / 混合料理 25〜30%
    - fa・aa は原則省略してよい（記録時に食品名から自動推定される）。値に確信がある場合のみ、
      fa: {sat,mufa,n3,n6,trans}（脂質に対する比率、合計0.8〜1.0）/ aa: {leu,ile,val,lys,met,thr,trp,his,score} を付ける
    - yomi（カタカナの読み）は任意だが、名前に漢字を含む場合は必ず付ける（ひらがな・ローマ字での検索に使われる。数字や記号は含めない）
    - serving（よくある1食分の目安量g）、en（英語名）、tags（検索用キーワード、スペース区切り）も分かれば付ける
    - units（1個・1枚などの単位。数えて食べる食品だけ）: [{"label":"個","g":50}] のように、単位名と1単位あたりのグラム数
    - category（食品DBの分類）は次のいずれか1つを付ける: 主食 / 主菜 / 副菜 / 果物 / 乳製品 / 間食・菓子 / 飲料 / 調味料 / 外食・惣菜 / サプリ・プロテイン / その他（add_combo_food も同様）
{
  "commands": [{
    "type": "add_custom_food",
    "foods": [{
      "name": "サントリー角ハイボール缶350ml",
      "yomi": "サントリーカクハイボールカン",
      "per": 350, "serving": 350,
      "cal": 154, "p": 0, "f": 0, "c": 10.5,
      "fiber": 0, "fibS": 0, "fibI": 0, "iron": 0, "calcium": 0, "vitc": 0, "vitd": 0, "salt": 0
    }]
  }],
  "backup_label": "カスタム食品登録",
  "message": "「（実際の食品名）」をカスタム食品DBに登録しました（100gあたり（実際のkcal）kcal）。記録タブの食品検索から追加できます"
}

6. register_logged_food — 【現在日時】以下のコンテキストに既にある食事記録（id付き）を、その記録済みの栄養値そのまま100gあたりに換算してカスタム食品DBに登録（栄養値を推定し直さない・改めてお願いされた食品名と一致するidをコンテキストから探して使う）
{
  "commands": [{
    "type": "register_logged_food",
    "items": [{"entry_id": 1234567890, "as_name": "省略可・DB登録名を変えたい場合のみ指定"}]
  }],
  "backup_label": "記録済み食品をDB登録",
  "message": "登録しました"
}

7. register_combo_from_log — 複数の記録済みエントリを合算して1つのカスタム食品として登録する（材料の内訳は残らず、合計値のみの1件になる）。
   「〇〇（料理名）の材料をまとめてカスタム食品登録して」のように、対象が個別に指定されず
   曖昧な依頼の場合、コンテキストの食事記録一覧から対象となる品目をあなたの食品知識で判断し、
   その entry_id を全て entry_ids に列挙する。name は既存のカスタム食品と重複しない、
   内容が一目でわかる名前を自分で考えて付ける（コンテキストの【カスタム食品】一覧を必ず確認すること）。
{
  "commands": [{
    "type": "register_combo_from_log",
    "entry_ids": [1234567890, 1234567891, 1234567892],
    "name": "お好み焼き（自家製・キャベツ豚玉）"
  }],
  "backup_label": "合算カスタム食品登録",
  "message": "3件の記録を合算して登録しました"
}

7.5. combo_food_from_log — 複数の記録済みエントリを「複合食品」（comboFoods。材料の内訳を保持し、後から複合食品タブで編集できる）として登録する。
    「さっき記録した〇〇の材料を複合食品として登録して」のように、既に記録した食事を複合食品にしたい依頼はこちらを使う
    （register_combo_from_logと違い、各記録が「材料」としてそのまま保持される）。
    delete_originals: true を指定すると、複合食品として登録すると同時に、元になった記録済みエントリ(entry_ids)を食事記録から削除する
    （二重計上を避けたい場合。ユーザーが削除を望まない場合は false のままでよい）。
{
  "commands": [{
    "type": "combo_food_from_log",
    "entry_ids": [1234567890, 1234567891, 1234567892],
    "name": "豆スープ（自家製）",
    "delete_originals": false
  }],
  "backup_label": "複合食品登録（記録から）",
  "message": "「豆スープ（自家製）」を複合食品として登録しました"
}

8. edit_custom_food — カスタム食品DBの既存項目の値を修正する（栄養価の間違い修正、名前変更など）。
   name で対象を特定し、updates に変更したいフィールドだけを指定する（指定しなかったフィールドは変更されない）。
   updates.name を指定すると名前も変更できる（他の既存カスタム食品と重複する名前には変更できない）。
{
  "commands": [{
    "type": "edit_custom_food",
    "name": "対象の既存カスタム食品名（コンテキストの【カスタム食品】一覧から一致するものを探す）",
    "updates": {"cal": 250, "p": 12, "f": 8, "c": 30}
  }],
  "backup_label": "カスタム食品編集",
  "message": "更新しました"
}

9. delete_custom_food — カスタム食品DBから削除
{
  "commands": [{"type": "delete_custom_food", "names": ["食品名"]}],
  "backup_label": "カスタム食品削除",
  "message": "削除しました"
}

10. add_combo_food — まだ記録していないレシピ・料理を、複数の材料から「複合食品」として新規登録する（「記録」タブの複合食品登録と同じデータ構造。材料の内訳を保持したまま複合食品リストに保存される）。
    ingredients の各要素は「その食材のamount(g)における実量」ではなく、per(基準量。省略時100g)あたりの値を指定する（=食品DBの1件と同じ形式）。
    各材料について、add_custom_food と同様に fiber（>0なら fibS 水溶性・fibI 不溶性も）/iron/calcium/vitc/vitd/salt（可能ならvita/vite/vitk/iodineも）を、
    search_food_dbの結果があればその値を、無ければあなたの知識で推定して極力埋めること（cal/p/f/cだけにしない）。
    yomi（カタカナの読み）は任意だが、名前に漢字を含む場合は付ける（ひらがな・ローマ字検索用）。
    登録後は100gあたりに正規化されず、材料の総重量そのものが基準量になる（例: 材料合計550gなら「550gあたり」として保存され、記録タブで選ぶ際のデフォルト量も550gになる）。
{
  "commands": [{
    "type": "add_combo_food",
    "name": "自家製プロテインオートミール",
    "yomi": "ジカセイプロテインオートミール",
    "ingredients": [
      {"name": "オートミール", "amount": 50, "per": 100, "cal": 380, "p": 13.7, "f": 5.7, "c": 69.1, "fiber": 9.4, "fibS": 3.2, "fibI": 6.2},
      {"name": "ホエイプロテイン", "amount": 30, "per": 100, "cal": 400, "p": 80, "f": 5, "c": 8},
      {"name": "無調整豆乳", "amount": 200, "per": 100, "cal": 46, "p": 3.6, "f": 2, "c": 3.1}
    ]
  }],
  "backup_label": "複合食品登録",
  "message": "「自家製プロテインオートミール」を複合食品として登録しました"
}

11. delete_combo_food — 複合食品DBから削除（名前で指定）
{
  "commands": [{"type": "delete_combo_food", "names": ["自家製プロテインオートミール"]}],
  "backup_label": "複合食品削除",
  "message": "削除しました"
}

12. add_quick_seasoning — 記録タブの「調味料クイック登録」に、既存の食品DB(内蔵/カスタム/複合いずれか)の1件をワンタップ登録ボタンとして追加する。
    food_name はコンテキストの食品DB・カスタム食品・複合食品のいずれかに実在する名前と完全一致させる必要がある（存在が不確かなら先にsearch_food_dbで確認する）。
    amountを省略すると、その食品自体のserving（無ければper）がそのまま使われる。
{
  "commands": [{
    "type": "add_quick_seasoning",
    "items": [{"food_name": "オリーブオイル", "label": "オリーブ油", "amount": 12}]
  }],
  "backup_label": "調味料クイック登録追加",
  "message": "「オリーブ油」をクイック登録に追加しました"
}

13. delete_quick_seasoning — 調味料クイック登録から削除（表示ラベルで指定。コンテキストの【調味料クイック登録】一覧を参照）
{
  "commands": [{"type": "delete_quick_seasoning", "labels": ["オリーブ油"]}],
  "backup_label": "調味料クイック登録削除",
  "message": "削除しました"
}

【コマンド選択の判断基準（重要）】
- 「〇〇を食べた」「〇〇を追加して」→ add（食事記録に追加）
- 「〇〇をクイック登録に追加して」「〇〇をワンタップで登録できるようにして」など、食品DBの何かをボタン化したい依頼 → add_quick_seasoning（対象の食品がコンテキストの食品DBに実在するか不確かならsearch_food_dbで先に確認する）
- 「（今日/昨日/〇月〇日の）朝食/昼食/夕食の〇〇を食品DBに登録して」「さっき記録した〇〇を保存して」など、既に記録済みの食品を指す依頼 → register_logged_food（コンテキストの食事記録からid付きで該当項目を探し、その id を entry_id に使う。栄養値は絶対に自分で計算し直さない）
- 「〇〇（料理名）の材料をまとめて登録して」など、複数の記録済み品目をひとまとめにしたい・
  かつどの品目が対象か曖昧な依頼 → register_combo_from_log（対象の特定はあなたの食品知識で行い、
  該当しそうにない品目まで巻き込まない。判断に自信が持てない場合は無理に実行せず、
  message で対象候補を確認する質問を返す）
  ※ただし依頼の中で明示的に「複合食品として登録して」「材料の内訳を残して」と言われた場合は、
  register_combo_from_logではなく combo_food_from_log を使う（内訳を保持したまま複合食品タブに登録される）
- まだ記録されていない食品を新しくDBに登録したい依頼（「〇〇という商品をDBに登録して」等）→ add_custom_food（栄養値を推定して入力）
- 「〇〇（オートミール・プロテイン・豆乳など複数の材料）を混ぜたものを複合食品として登録して」のように、
  まだ記録していないレシピを材料の内訳を保持したまま登録したい依頼 → add_combo_food（各材料のper・amountを指定し、
  材料ごとの内訳がDB上でも残る。単に合計の栄養値だけでよく内訳が不要なら add_custom_food で十分）
- 「〇〇を削除して」→ 対象がid特定できれば delete_by_id、できなければ delete_by_date_meal（ただし対象がコンテキストの【複合食品】一覧にある名前なら delete_combo_food、【カスタム食品】一覧にある名前なら delete_custom_food）
- 「カスタム食品の〇〇のカロリーを△△に直して」「〇〇の名前を△△に変更して」など、既存のカスタム食品の内容を修正したい依頼 → edit_custom_food（updatesには変更したいフィールドだけを入れる。対象がコンテキストの【カスタム食品】一覧に見当たらない場合は無理に実行せず確認する）
- 「〇〇に変えて」「〇〇で置き換えて」→ replace
- 「今週の〇〇を全部〇〇にして」→ replace を dates に全日付列挙して1コマンドで

【必須ルール・よくある誤りの防止】
- 1回の応答で出力するJSONが非常に大きくなりそうな場合（一度に大量の日付・大量の品目を扱う依頼など）は、無理に1回で全て出力しようとせず、まず一部だけを実行してmessageで「残りは分けて実行しましょうか？」と提案する。出力途中で切れて壊れたJSONを返すより、確実に完了する範囲に絞ること
- dates は必ず配列で指定。「今日」でも ["${today}"] と明示する
- meal は必ず「朝食」「昼食」「夕食」「間食」のいずれか。省略・空文字・null 禁止
- 【完了報告のルール】message は、実際に出力したコマンドの内容（食品名・件数・主な値）を具体的に書く。例文の message をそのままコピーしてはいけない。
  JSONブロック（commands）を出力していないのに「登録しました」「追加しました」などと書くのは厳禁（コマンドを出さなければ、実際には何も実行されない）。実行するなら必ずその回に \`\`\`json でコマンドを出力すること
- 【聞き返し禁止（登録・記録系）】食品の記録・登録の依頼で、量・カロリー・PFC・栄養成分・per・serving・材料の分量・「目安」などの数値の指定が無くても、ユーザーに聞き返してはいけない。
  一般的な標準値（標準的な1人前・1個・1食分のグラム数、市販品の一般的な内容量、レシピの一般的な分量、同カテゴリの一般的な栄養値）であなたが推定し、その回のうちにJSONコマンドで実行する。
  前提にした量や値は message に「〜gと仮定して登録しました。違っていれば教えてください」のように【事後報告】として1〜2行で添える（確認は実行後）。
  聞き返してよいのは次の場合だけ: ①削除・置換など破壊的操作で対象を特定できない ②食品名・料理名がまったく判別できない ③同名のカスタム食品が既にあり上書きか別名か判断できない。「数値・量・目安が分からない」は聞き返す理由にならない
- items の栄養素（cal/p/f/c）は必ず推定値を入れる。全て0はNG
- 「〇〇を食べた」に対して、カロリーやPFCが分からないという理由でユーザーに聞き返すことは禁止。あなたの知識で一般的な値を推定するか、銘柄が特定できる市販品・チェーン店メニューなど確度を上げたい場合は検索ツールを使って調べ、必ず自分で数値を確定させて登録すること。ユーザーへの質問は、量や食事区分など、あなたの知識や検索では埋められない情報が本当に無い場合のみに限る
- amount は必ず正の数値。単位はg（人前ではなくg換算で記入）
- 複数の食品を同じ meal に追加する場合は items 配列を使い、コマンドは1つにまとめる
- add と add_custom_food を混同しない。食べた記録は add、DBへの保存は add_custom_food
- register_logged_food / register_combo_from_log / combo_food_from_log の entry_id は必ずコンテキストの食事記録に実在する id を使う。id が見つからない・該当日が直近14日の詳細範囲外の場合は無理に実行せず、message で「id特定できないため対応できません」と案内する
- register_combo_from_log の name は必ずコンテキストの【カスタム食品】一覧と重複しないこと。似た名前になりそうな場合は「（自家製）」「（〇月〇日）」等を付けて区別する
- カスタム食品DBへの登録・編集・削除系コマンド（add_custom_food / register_logged_food / register_combo_from_log / edit_custom_food / delete_custom_food）は、ユーザーの明示的な依頼がある場合のみ実行する。他の会話の流れから先回りして実行しない
- "今週" は ${weekDates[0]}〜${weekDates[6]}（${weekDates.length}日間）
- "昨日" は ${getLastNDates(2)[0]}、"一昨日" は ${getLastNDates(3)[0]}
- 記録の読み取り・質問・雑談のみの場合は commands 不要、message だけ返す
- 未来の日付には操作しない（予定記録はユーザーに確認する）

【backup_labelルール】
- 操作内容を10文字以内で端的に表す日本語ラベルを必ず付ける
- 例）「朝食に卵追加」「昨日夕食削除」「今週昼食を置換」

【対応範囲外の操作について】
以下はこのアプリで対応できない操作です。該当する場合は操作を行わず、
できない理由と代替手段をmessageのみで返してください（JSONブロック不要）:
- 体重・プロフィール情報の変更（→「設定」タブで手動変更を案内）
- グラフや統計の操作（表示のみで変更不可）
- 15日以上前の記録（コンテキスト外のため参照・操作不可）
- 運動記録の追加・削除（→「記録」タブの運動ブロックで手動操作を案内）
- アプリの設定変更・外部サービス連携操作

【カスタム食品登録のルール】
- 既に記録した食事から登録したい場合は register_logged_food（記録値そのまま使う・最も正確）
- 複数の記録済み品目を1つにまとめたい場合は register_combo_from_log（対象の判断はあなたの食品知識で行う）
- まだ記録していない新しい商品を登録したい場合は add_custom_food（per は商品1個・1食分・100g など最も使いやすい単位を選ぶ。栄養成分表示がある場合はその数値を使用、なければ標準的な値を推定）
- まだ記録していないレシピを、材料の内訳を残したまま登録したい場合は add_combo_food（各材料の栄養値は search_food_db で確認するか、あなたの知識で推定。分量の指定が無ければ一般的なレシピの分量で決め、聞き返さない）
- 登録後は「記録タブの食品検索から追加できます」と案内する
━━━━━━━━━━━━━━━━━━━━━━`;

  try {
    let workingMessages = [...aiHistory]; // ツール呼び出しのやりとり用のローカル作業コピー（aiHistory本体には最終応答だけ残す）
    let rawText = '';
    const MAX_TOOL_LOOPS = 3;

    for (let loop = 0; loop <= MAX_TOOL_LOOPS; loop++) {
      const res = await fetch('/.netlify/functions/ai-chat', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          ...(localStorage.getItem('appAccessToken') ? { 'X-App-Token': localStorage.getItem('appAccessToken') } : {}),
        },
        body: JSON.stringify({
          system: systemPrompt,
          messages: workingMessages,
        }),
      });

      const data = await res.json();
      if (!res.ok) {
        throw new Error(data.error || `サーバーエラー (${res.status})`);
      }

      if (data.functionCall) {
        const { name, args } = data.functionCall;
        let toolResult;
        if (name === 'search_food_db') {
          toolResult = searchFoodDbForAi(args && args.query);
        } else {
          // 操作コマンド(add_custom_food等)を「関数」として呼んでしまった場合。以前は「未対応の関数です」とだけ返しており、
          // AIがそれを真に受けて「add_custom_food関数は未対応のため登録できません」とユーザーに答えていた
          const isCmd = AI_COMMAND_TYPES.includes(name);
          toolResult = isCmd
            ? `「${name}」は関数ではなく【操作コマンド】です。関数としては呼び出せませんが、アプリは「${name}」に対応済みです。` +
              `最終返答の末尾に \`\`\`json ブロックで {"commands":[{"type":"${name}", ...}], "message":"..."} の形で出力すれば実行されます。` +
              `ユーザーに「未対応」「できない」と伝えてはいけません。今すぐコマンドとして出力してください。`
            : `「${name}」という関数はありません。使える関数は search_food_db のみです。記録・登録などの操作は、最終返答の末尾に \`\`\`json ブロックのコマンドとして出力してください。`;
          logError('AI関数呼び出し', `AIが関数として「${name}」を呼び出しました（使える関数は search_food_db のみ。${isCmd ? '操作コマンド名を関数として呼んだ' : '存在しない関数'}）`,
            JSON.stringify(args || {}).slice(0, 500));
        }
        workingMessages.push({ role: 'assistant', parts: [{ functionCall: { name, args } }] });
        workingMessages.push({ role: 'function',  parts: [{ functionResponse: { name, response: { result: toolResult } } }] });
        continue; // 検索結果を渡してもう一度Geminiに問い合わせる
      }

      rawText = (data.content || []).map(b => b.text || '').join('');
      if (loop === MAX_TOOL_LOOPS && data.functionCall) {
        // 関数呼び出しを繰り返した末に上限に達し、最終的なテキスト応答を一度も受け取れなかった
        rawText = '';
      }
      if (data.finishReason === 'MAX_TOKENS') {
        const u = data.usage || {};
        logError('AI応答', '出力上限に達して応答が途中で切れました',
          `入力${u.promptTokenCount ?? '?'} / 出力${u.candidatesTokenCount ?? '?'} / 思考${u.thoughtsTokenCount ?? '?'} トークン`);
      }
      break;
    }

    if (!rawText.trim()) {
      // 応答本文が完全に空（関数呼び出しの繰り返しで上限に達した等）。
      // 以前はここで何も表示されず、エラーログにも残らなかった。
      const msg = 'AIから有効な応答が得られませんでした（検索を繰り返した末に時間切れになった可能性があります）';
      if (thinking) { clearInterval(thinking._timer); thinking.remove(); }
      appendAiMessage('ai', `⚠️ ${msg}。もう一度お試しください。`);
      logError('AI応答', msg, '');
      aiHistory.pop();
      inp.disabled = false; btn.disabled = false; inp.focus();
      return;
    }

    let { parsed, displayText, jsonParseAttemptFailed } = parseAiResponse(rawText);

    // 自動の再依頼（最大1回）: AIに「推定して出し直して」と頼み、良くなった場合だけ採用する
    const retryAi = async (userNote, accept) => {
      try {
        const retryMessages = [...workingMessages, { role: 'assistant', content: rawText }, { role: 'user', content: userNote }];
        const res2 = await fetch('/.netlify/functions/ai-chat', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json', ...(localStorage.getItem('appAccessToken') ? { 'X-App-Token': localStorage.getItem('appAccessToken') } : {}) },
          body: JSON.stringify({ system: systemPrompt, messages: retryMessages }),
        });
        const data2 = await res2.json();
        if (!res2.ok || data2.functionCall) return false;
        const rawText2 = (data2.content || []).map(b => b.text || '').join('');
        const pr2 = parseAiResponse(rawText2);
        if (!accept(pr2)) return false;
        rawText = rawText2; ({ parsed, displayText, jsonParseAttemptFailed } = pr2);
        return true;
      } catch (e) { logError('AI再確認', 'AIへの再依頼に失敗しました', String(e && e.message || e)); return false; }
    };

    // (1) 未登録の材料/食品に栄養値が付いていない登録コマンドは、そのまま実行すると0kcalで登録されてしまうため
    const unvalued = parsed ? findUnvaluedItems(parsed) : [];
    if (unvalued.length) {
      await retryAi(`【システムからの自動確認】登録コマンドの「${[...new Set(unvalued)].join('」「')}」に栄養値(cal/p/f/c など)が指定されておらず、食品DBにも登録がありません（このままでは0kcalになります）。` +
        `それぞれに per あたりの cal/p/f/c と fiber/fibS/fibI/iron/calcium/vitc/vitd/salt を search_food_db の結果またはあなたの知識で推定して必ず入れ、同じ内容のコマンドをもう一度JSONで出力してください（他の食品・名前・量は変えない。分からなくても一般的な値で推定すること）。`,
        pr2 => pr2.parsed && findUnvaluedItems(pr2.parsed).length < unvalued.length);
    }
    // (2) 記録・登録の依頼なのに、コマンドを出さず量や値を聞き返してきた場合は、聞き返さず推定して実行するよう促す
    else if (!(parsed && Array.isArray(parsed.commands) && parsed.commands.length) && looksLikeRegistrationRequest(text) && looksLikeAskBack(displayText)) {
      await retryAi('【システムからの自動確認】記録・登録の依頼では、量・カロリー・栄養値・目安などの数値の指定が無くても聞き返さないでください。' +
        '一般的な標準値（標準的な1人前・1個・1食分の量、一般的なレシピ分量、同カテゴリの一般的な栄養値）であなたが推定し、今すぐJSONコマンドで実行してください。' +
        '前提にした量や値は message に事後報告として1〜2行で添えてください。',
        pr2 => pr2.parsed && Array.isArray(pr2.parsed.commands) && pr2.parsed.commands.length > 0);
    }

    // (3) 登録・記録の依頼なのに「登録しました」と言うだけでコマンドを出していない → 実行されていないので一度だけ出し直させる
    const _claim3 = [displayText, parsed && parsed.message].filter(Boolean).join(' ');
    if (!(parsed && Array.isArray(parsed.commands) && parsed.commands.length) && looksLikeRegistrationRequest(text)
        && (claimsActionDone(_claim3) || claimsCannot(_claim3))) {
      await retryAi('【システムからの自動確認】返答では「登録しました」または「未対応・できない・エラー」などと書かれていますが、操作コマンド（```json ブロックの commands）が出力されていないため、実際には何も実行されていません。' +
        'add_custom_food などは関数ではなく、返答末尾のJSONブロックに書く操作コマンドで、すべて対応済みです。「未対応」「システムエラー」を理由に断らず、今すぐ依頼内容を実行する commands を ```json ブロックで出力してください（栄養値などは一般的な値で推定してよい）。',
        pr2 => pr2.parsed && Array.isArray(pr2.parsed.commands) && pr2.parsed.commands.length > 0);
    }

    if (thinking) { clearInterval(thinking._timer); thinking.remove(); }
    const historyContent = rawText.replace(/```json[\s\S]*?```/g, '[操作コマンド実行済み]').trim();
    aiHistory.push({ role: 'assistant', content: historyContent });
    if (aiHistory.length > 20) aiHistory = aiHistory.slice(aiHistory.length - 20);

    // コマンド実行
    const claimText = [displayText, parsed && parsed.message].filter(Boolean).join(' ');
    if (parsed && Array.isArray(parsed.commands) && parsed.commands.length > 0) {
      const backupLabel = parsed.backup_label || 'AI操作';
      const sigBefore = aiStateSig();
      const foodIdsBefore = new Set([...customFoods, ...comboFoods].map(f => f.id));
      const opLog = executeAiCommands(parsed.commands, backupLabel);
      const newFoods = [...customFoods.map(f => ({ f, kind: 'custom' })), ...comboFoods.map(f => ({ f, kind: 'combo' }))].filter(x => !foodIdsBefore.has(x.f.id));
      const changedAnything = aiStateSig() !== sigBefore;
      // ⚠️/❌ の結果は画面に出すだけでなくエラーログにも残す（個別のlogErrorと重複しないよう同文は除外）
      opLog.filter(l => /^(⚠️|❌)/.test(l)).forEach(l => {
        const m = l.replace(/^(⚠️|❌)\s*/, '');
        if (!errorLog.slice(-40).some(e => e.message === m)) logError('AI操作', m, `依頼: ${text.slice(0, 200)}`);
      });
      let notice = '';
      if (!changedAnything) {
        // コマンドは受理されたが、データが一切変わらなかった（重複登録のスキップ・対象なし・不正な形式など）
        const types = parsed.commands.map(c => c && c.type).join(', ');
        logError('AI操作', 'コマンドは実行されましたが、データは何も変更されませんでした' + (claimActionDoneGuard(claimText) ? '（返答は完了を報告している）' : ''),
          `依頼: ${text.slice(0, 200)}\nコマンド種別: ${types}\nAI返答: ${claimText.slice(0, 300)}\n実行結果: ${opLog.join(' / ').slice(0, 400)}`);
        if (claimActionDoneGuard(claimText)) notice = '\n\n⚠️ 実際にはデータは変更されていません（詳細はエラーログを確認してください）。';
      }
      const replyText = (displayText ? displayText + '\n\n' : '') + opLog.join('\n') + notice;
      const msgDiv = appendAiMessage('ai', replyText);
      if (msgDiv && newFoods.length) {
        // 登録した食品を食品登録タブで確認・編集できるボタン（最大3件。それ以上はまとめて1つ）
        const bar = document.createElement('div'); bar.style.cssText = 'display:flex;gap:6px;flex-wrap:wrap;margin-top:8px;white-space:normal';
        const mk = (label, fn) => { const b = document.createElement('button'); b.className = 'btn btn-sm'; b.textContent = label; b.onclick = fn; bar.appendChild(b); };
        if (newFoods.length <= 3) newFoods.forEach(({ f, kind }) => mk(`📂 「${f.name.length > 14 ? f.name.slice(0, 14) + '…' : f.name}」を食品登録タブで開く`, () => openFoodDbItem(kind, f.name)));
        else { const k = newFoods[0].kind; mk(`📂 登録した${newFoods.length}件を食品登録タブで開く`, () => openFoodDbItem(k, '')); }
        msgDiv.appendChild(bar);
      }
    } else {
      // コマンドが無いのに「登録しました」等と完了を報告している場合: 実際には何も実行されていない
      let finalText = displayText || '応答を取得できませんでした。';
      if (claimsCannot(claimText) && !claimActionDoneGuard(claimText) && looksLikeActionRequest(text)) {
        // 「未対応」「できない」「システムエラー」等で断られた（コマンド未出力）。実際には対応済みの操作であることが多いので記録しておく
        logError('AI応答', 'AIが「実行できない／未対応」と返答しました（操作コマンドは出力されていません）',
          `依頼: ${text.slice(0, 200)}\nAI返答: ${claimText.slice(0, 400)}`);
      } else if (claimActionDoneGuard(claimText) && looksLikeActionRequest(text)) {
        logError('AI応答', 'AIは完了を報告しましたが、操作コマンドが出力されていないため何も実行されていません',
          `依頼: ${text.slice(0, 200)}\nAI返答: ${claimText.slice(0, 400)}\nJSONブロック有無: ${/\`\`\`/.test(rawText) ? 'あり（commandsが空/不正）' : 'なし'}`);
        finalText += '\n\n⚠️ 実際には何も実行されていません（AIが操作コマンドを出力しませんでした）。もう一度依頼してください。';
      }
      appendAiMessage('ai', finalText);
    }

  } catch(err) {
    if (thinking) { clearInterval(thinking._timer); thinking.remove(); }
    const msg = err.message || String(err);
    const hint = msg.includes('GEMINI_API_KEY')
      ? msg
      : `通信エラーが発生しました。\n${msg}`;
    appendAiMessage('ai', hint);
    logError('AI通信', msg, err.stack || '');
    aiHistory.pop();
  }

  inp.disabled = false;
  btn.disabled = false;
  inp.focus();
}

// 「外側クリックで閉じる」判定。box.contains(e.target) だと、複合食品の分量調整パネルのように
// クリックされた要素自身をその場で innerHTML 差し替えで消してしまうケースで、クリック直後に
// e.target がDOMから外れて「外側」と誤判定され、開いたばかりのパネルを同じクリックで
// 閉じてしまう不具合があった。composedPath() はディスパッチ時点の経路を保持するため、
// 要素が後から入れ替わっても正しく「内側からのクリックだったか」を判定できる。
function clickWasInside(e, el) {
  if (!el) return false;
  if (e.composedPath) return e.composedPath().includes(el);
  return el.contains(e.target);
}
document.addEventListener('click', e => {
  const cb = document.getElementById('comboResultsBox');
  if (cb && !clickWasInside(e, cb) && e.target !== document.getElementById('comboSearch')) cb.style.display = 'none';
  MEALS_ORDER.forEach(meal => {
    const box=document.getElementById('addResultsBox_'+meal);
    const inp=document.getElementById('addSearch_'+meal);
    if (box && !clickWasInside(e, box) && e.target !== inp) box.style.display = 'none';
  });
});

// ── Init ──
bindEntryDrag();
bindEntrySwipe();
renderPromptTemplates();
try { if (localStorage.getItem('pfcDragHint') === '1') { const h = document.getElementById('dragHint'); if (h) h.style.display = 'none'; } } catch (e) {}
updateDateHeader();
renderCalendar();
renderRecord();
renderQuickSeasonings();
renderExerciseItems();
renderErrorLogPanel();
renderAuthUI();
initFirebase(); // Firebase設定がある場合に認証・同期を開始
